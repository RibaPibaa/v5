package com.geko.garageauction.structure;

import com.geko.garageauction.loot.LootScanner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.MapColor;

import java.util.*;

/** Procedural abandoned scrapyard. All generated geometry is deliberately irregular. */
public final class MarketplaceBuilder {
    private MarketplaceBuilder() {}

    public static void generate(ServerLevel level, BlockPos playerPos, float yaw, String ignoredSize) {
        RandomSource r = RandomSource.create(level.getRandom().nextLong());
        Direction forward = Direction.fromYRot(yaw).getOpposite();
        Direction right = forward.getClockWise();
        BlockPos origin = playerPos.relative(forward, 9);
        // A broad, uneven 92x78 scrapyard; no arena structures are generated.
        clear(level, origin, 52);
        buildScrapyardTerrain(level, origin, r);
        buildPerimeterRubble(level, origin, r);
        buildRoadsAndDebris(level, origin, forward, right, r);
        buildEntrance(level, origin, forward, right, r);

        int garageCount = 12;
        int garageIndex = 1;
        // Three narrow lanes, garages facing the central service alleys.
        for (int lane = -1; lane <= 1; lane++) {
            for (int row = 0; row < 4; row++) {
                BlockPos p = offset(origin, right, forward, lane * 17 + (r.nextInt(3)-1), 8 + row * 13);
                buildGarage(level, p, garageIndex++, forward, right, r);
            }
        }
        scatterLargeJunk(level, origin, r);
    }

    private static BlockPos offset(BlockPos o, Direction right, Direction forward, int x, int z) {
        return o.relative(right, x).relative(forward, z);
    }

    private static void buildScrapyardTerrain(ServerLevel level, BlockPos o, RandomSource r) {
        for (int x=-48;x<=48;x++) for(int z=-40;z<=48;z++) {
            int noise = (int)(Math.sin(x*.19)*1.4 + Math.cos(z*.16)*1.2);
            BlockPos p=o.offset(x,-1+noise,z);
            Block b = r.nextInt(10) < 5 ? Blocks.COARSE_DIRT : r.nextInt(3)==0 ? Blocks.GRAVEL : Blocks.MUD;
            level.setBlock(p,b.defaultBlockState(),3);
            if(r.nextFloat()<.035f) level.setBlock(p.above(), Blocks.MOSS_CARPET.defaultBlockState(),3);
            if(r.nextFloat()<.018f) level.setBlock(p.above(), Blocks.PODZOL.defaultBlockState(),3);
        }
    }

    private static void buildPerimeterRubble(ServerLevel level, BlockPos o, RandomSource r) {
        for(int side=-1;side<=1;side+=2) for(int z=-34;z<=42;z+=2+r.nextInt(3)) {
            int x=side*(35+r.nextInt(10));
            rubbleMound(level,o.offset(x,0,z),2+r.nextInt(5),1+r.nextInt(5),r);
        }
        for(int x=-42;x<=42;x+=3+r.nextInt(3)) {
            rubbleMound(level,o.offset(x,0,-32-r.nextInt(8)),2+r.nextInt(4),1+r.nextInt(4),r);
        }
    }

    private static void buildRoadsAndDebris(ServerLevel level, BlockPos o, Direction f, Direction right, RandomSource r) {
        for(int lane=-1;lane<=1;lane++) {
            for(int z=-2;z<=51;z++) for(int x=-3;x<=3;x++) {
                BlockPos p=offset(o,right,f,lane*17+x, z);
                if(r.nextFloat()<.09f) level.setBlock(p, Blocks.GRAVEL.defaultBlockState(),3);
                else if(r.nextFloat()<.08f) level.setBlock(p, Blocks.COARSE_DIRT.defaultBlockState(),3);
            }
        }
        // Broken concrete slabs, puddle-like dark patches and random trash along alleys.
        for(int i=0;i<150;i++) {
            int x=r.nextInt(76)-38, z=r.nextInt(76)-25;
            BlockPos p=o.offset(x,0,z);
            if(r.nextBoolean()) level.setBlock(p, r.nextBoolean()?Blocks.CRACKED_STONE_BRICKS.defaultBlockState():Blocks.MOSSY_COBBLESTONE.defaultBlockState(),3);
            if(r.nextFloat()<.3f) level.setBlock(p.above(), randomTrashBlock(r).defaultBlockState(),3);
        }
    }

    private static void buildEntrance(ServerLevel level, BlockPos o, Direction f, Direction right, RandomSource r) {
        BlockPos base=offset(o,right,f,0,-5);
        BlockState pillar=Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        for(int y=0;y<8;y++) for(int x=-6;x<=6;x++) {
            if(Math.abs(x)>=5 || (y>=6 && Math.abs(x)<=5 && y+Math.abs(x)>=10))
                level.setBlock(base.relative(right,x).above(y), y<2?Blocks.COBBLESTONE.defaultBlockState():pillar,3);
        }
        for(int x=-4;x<=4;x++) if(r.nextBoolean()) level.setBlock(base.relative(right,x).above(1),Blocks.CRACKED_STONE_BRICKS.defaultBlockState(),3);
        level.setBlock(base.above(8),Blocks.CHAIN.defaultBlockState(),3);
        level.setBlock(base.relative(right,0).above(4),Blocks.REDSTONE_LAMP.defaultBlockState(),3);
        rubbleMound(level,base.relative(right,-9),4,4,r); rubbleMound(level,base.relative(right,9),4,5,r);
    }

    private static void buildGarage(ServerLevel level, BlockPos p, int index, Direction forward, Direction right, RandomSource r) {
        int w=9+r.nextInt(3), d=10+r.nextInt(3), h=4+r.nextInt(2);
        boolean tidy=r.nextFloat()<.22f;
        BlockState[] walls = tidy
            ? new BlockState[]{Blocks.BRICKS.defaultBlockState(),Blocks.STONE_BRICKS.defaultBlockState()}
            : new BlockState[]{Blocks.MOSSY_COBBLESTONE.defaultBlockState(),Blocks.COBBLESTONE.defaultBlockState(),Blocks.MOSSY_STONE_BRICKS.defaultBlockState(),Blocks.ANDESITE.defaultBlockState()};
        BlockState wall=walls[r.nextInt(walls.length)];
        BlockState roof=tidy?Blocks.DEEPSLATE_TILES.defaultBlockState():Blocks.OAK_PLANKS.defaultBlockState();
        // local X is width, local Z is depth; front faces toward the alley.
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            BlockPos q=offset(p,right,forward,x,z);
            level.setBlock(q, tidy?Blocks.POLISHED_ANDESITE.defaultBlockState():Blocks.GRAY_CONCRETE.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) {
                for(int y=1;y<=h;y++) if(!(z==0 && x>=2 && x<=w-3 && y<=3)) {
                    if(!tidy && r.nextFloat()<.08f) continue;
                    level.setBlock(q.above(y), wall,3);
                }
            }
            if(z==d-1 || r.nextFloat()<.15f) level.setBlock(q.above(h+1),roof,3);
        }
        // Solid, opaque rolling shutter made from blocks, never iron bars.
        Block doorBlock = tidy ? Blocks.IRON_BLOCK : (r.nextBoolean()?Blocks.GRAY_CONCRETE:Blocks.CUT_COPPER);
        for(int x=2;x<=w-3;x++) for(int y=1;y<=3;y++) level.setBlock(offset(p,right,forward,x,0).above(y),doorBlock.defaultBlockState(),3);
        // Distinctive wall sign centered above the shutter.
        BlockPos signPos=offset(p,right,forward,w/2,0).above(4);
        level.setBlock(signPos, Blocks.OAK_WALL_SIGN.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING,forward.getOpposite()),3);
        BlockEntity signBe=level.getBlockEntity(signPos);
        if(signBe instanceof SignBlockEntity sign) {
            sign.setText(sign.getText(true).setMessage(0,Component.literal("GARAGE " + String.format(Locale.ROOT,"%02d",index))).setMessage(1,Component.literal("")).setColor(DyeColor.BLACK), true);
            sign.setChanged();
        }
        level.setBlock(offset(p,right,forward,1,d-2),Blocks.COBWEB.defaultBlockState(),3);
        if(!tidy) {
            rubbleMound(level,offset(p,right,forward,1,2),2+r.nextInt(2),1+r.nextInt(3),r);
            rubbleMound(level,offset(p,right,forward,w-2,d-3),2+r.nextInt(3),1+r.nextInt(3),r);
            for(int i=0;i<8;i++) {
                BlockPos q=offset(p,right,forward,r.nextInt(w-2)+1,r.nextInt(d-2)+1);
                if(r.nextBoolean()) level.setBlock(q,Blocks.COARSE_DIRT.defaultBlockState(),3);
                else if(r.nextBoolean()) level.setBlock(q,Blocks.MOSS_CARPET.defaultBlockState(),3);
            }
        } else {
            level.setBlock(offset(p,right,forward,1,d-2),Blocks.LANTERN.defaultBlockState(),3);
            level.setBlock(offset(p,right,forward,w-2,1),Blocks.BARREL.defaultBlockState(),3);
        }
        // Three to five containers, scattered rather than placed in a neat line.
        int chestCount=3+r.nextInt(3);
        Set<Long> used=new HashSet<>();
        boolean armorSetUsed=false;
        for(int c=0;c<chestCount;c++) {
            BlockPos cp=null;
            for(int tries=0;tries<30;tries++) {
                int x=1+r.nextInt(w-2), z=1+r.nextInt(d-2);
                BlockPos candidate=offset(p,right,forward,x,z);
                if(used.add(candidate.asLong())) {cp=candidate;break;}
            }
            if(cp==null) continue;
            boolean barrel=r.nextFloat()<.28f;
            level.setBlock(cp,barrel?Blocks.BARREL.defaultBlockState():Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING,Direction.NORTH),3);
            BlockEntity be=level.getBlockEntity(cp);
            List<ItemStack> containerLoot = LootScanner.generateContainerLoot(new Random(r.nextLong()), 13+r.nextInt(9), !armorSetUsed);
            if(containerLoot.stream().anyMatch(st -> st.getItem() instanceof net.minecraft.world.item.ArmorItem)) armorSetUsed=true;
            if(be instanceof ChestBlockEntity chest) fillRandomSlots(chest,containerLoot,r);
            if(be instanceof net.minecraft.world.level.block.entity.BarrelBlockEntity barrelEntity) fillRandomSlots(barrelEntity,containerLoot,r);
        }
        if(r.nextFloat()<.65f) level.setBlock(offset(p,right,forward,w/2,d-2),Blocks.COBWEB.defaultBlockState(),3);
        if(r.nextFloat()<.45f) level.setBlock(offset(p,right,forward,1,1),Blocks.FLOWER_POT.defaultBlockState(),3);
        if(r.nextFloat()<.35f) level.setBlock(offset(p,right,forward,w-2,d-2),Blocks.CRAFTING_TABLE.defaultBlockState(),3);
    }

    private static void fillRandomSlots(net.minecraft.world.Container container, List<ItemStack> loot, RandomSource r) {
        int size=container.getContainerSize();
        List<ItemStack> all=new ArrayList<>();
        // A small amount of atmosphere clutter mixed into otherwise useful containers.
        if(r.nextFloat()<.55f) all.add(new ItemStack(Items.STRING,1+r.nextInt(4)));
        if(r.nextFloat()<.35f) all.add(new ItemStack(Items.BONE,1+r.nextInt(3)));
        if(r.nextFloat()<.30f) all.add(new ItemStack(Items.COBWEB));
        if(r.nextFloat()<.35f) all.add(new ItemStack(Items.ROTTEN_FLESH));
        List<ItemStack> suit=new ArrayList<>();
        for(ItemStack stack:loot) {
            if(stack.getItem() instanceof net.minecraft.world.item.ArmorItem) suit.add(stack);
            else all.add(stack);
        }
        Collections.shuffle(all,new Random(r.nextLong()));
        List<Integer> slots=new ArrayList<>(); for(int i=0;i<size;i++) slots.add(i);
        Collections.shuffle(slots,new Random(r.nextLong()));
        int slot=0;
        // If a rare set was rolled, preserve every piece together in this one container.
        for(ItemStack piece:suit) if(slot<size) container.setItem(slots.get(slot++),piece);
        int count=Math.min(Math.min(all.size(),size-slot), Math.max(10, 12+r.nextInt(10)));
        for(int i=0;i<count;i++) container.setItem(slots.get(slot++),all.get(i));
        container.setChanged();
    }

    /** Separate clean, circular park map with a stone monument and colourful wooden cottages. */
    public static void generatePark(ServerLevel level, BlockPos playerPos, float yaw) {
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        Direction f=Direction.fromYRot(yaw).getOpposite(), right=f.getClockWise();
        BlockPos o=playerPos.relative(f,12);
        clear(level,o,50);
        // Circular lawn and pale stone walking ring.
        for(int x=-43;x<=43;x++) for(int z=-43;z<=43;z++) {
            double d=Math.sqrt(x*x+z*z);
            if(d>42) continue;
            BlockPos q=o.offset(x,-1,z);
            level.setBlock(q, d>38?Blocks.STONE_BRICKS.defaultBlockState():Blocks.GRASS_BLOCK.defaultBlockState(),3);
            if(d>37 && d<40 && r.nextFloat()<.22f) level.setBlock(q,Blocks.MOSSY_STONE_BRICKS.defaultBlockState(),3);
        }
        // Thick hedge border, punctuated by mature trees.
        for(int a=0;a<144;a++) {
            double ang=a*Math.PI/72.0; int x=(int)(40*Math.cos(ang)), z=(int)(40*Math.sin(ang));
            BlockPos q=o.offset(x,0,z);
            for(int y=0;y<2;y++) for(int dx=-1;dx<=1;dx++) for(int dz=-1;dz<=1;dz++)
                level.setBlock(q.offset(dx,y,dz),Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
            if(a%12==0) parkTree(level,q,r);
        }
        // Monument: stepped plinth, tall abstract grey sculpture.
        for(int y=0;y<3;y++) for(int x=-5+y;x<=5-y;x++) for(int z=-5+y;z<=5-y;z++)
            level.setBlock(o.offset(x,y-1,z),Blocks.POLISHED_ANDESITE.defaultBlockState(),3);
        for(int y=2;y<12;y++) {
            int radius=y<7?2:1;
            for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++)
                if(Math.abs(x)+Math.abs(z)<=radius+1) level.setBlock(o.offset(x,y,z), (y%3==0?Blocks.GRAY_CONCRETE:Blocks.STONE_BRICKS).defaultBlockState(),3);
        }
        // Wide stair/bench terraces around the monument.
        for(int side=-1;side<=1;side+=2) for(int n=0;n<3;n++) for(int x=-8;x<=8;x++)
            level.setBlock(o.relative(right,x).relative(f,side*(7+n)).above(n-1),Blocks.STONE_BRICK_SLAB.defaultBlockState(),3);
        // Twelve small timber cottages with different bright roofs, arranged around the central green.
        Block[] roofs={Blocks.RED_WOOL,Blocks.BLUE_WOOL,Blocks.GREEN_WOOL,Blocks.YELLOW_WOOL,Blocks.ORANGE_WOOL,Blocks.PURPLE_WOOL,Blocks.CYAN_WOOL,Blocks.MAGENTA_WOOL};
        int idx=0;
        for(int ring=0;ring<2;ring++) for(int i=0;i<6;i++) {
            double ang=(i*Math.PI/3)+(ring==0?0:Math.PI/6); int rad=ring==0?23:32;
            BlockPos h=o.offset((int)(rad*Math.cos(ang)),0,(int)(rad*Math.sin(ang)));
            buildParkCottage(level,h,idx++,roofs[r.nextInt(roofs.length)],r);
        }
    }

    private static void parkTree(ServerLevel level,BlockPos p,RandomSource r) {
        int h=4+r.nextInt(3);
        for(int y=0;y<h;y++) level.setBlock(p.above(y),Blocks.OAK_LOG.defaultBlockState(),3);
        for(int x=-2;x<=2;x++) for(int y=h-2;y<=h+1;y++) for(int z=-2;z<=2;z++)
            if(x*x+z*z+(y-h)*(y-h)<=7 && r.nextFloat()<.88f)
                level.setBlock(p.offset(x,y,z),Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
    }

    private static void buildParkCottage(ServerLevel level,BlockPos p,int index,Block roof,RandomSource r) {
        int w=7,d=8; Block[] woods={Blocks.OAK_PLANKS,Blocks.SPRUCE_PLANKS,Blocks.BIRCH_PLANKS,Blocks.DARK_OAK_PLANKS};
        Block wall=woods[r.nextInt(woods.length)];
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            BlockPos q=p.offset(x,0,z); level.setBlock(q,Blocks.OAK_PLANKS.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) for(int y=1;y<=3;y++)
                if(!(z==0&&x==3&&y<=2)) level.setBlock(q.above(y),wall.defaultBlockState(),3);
            if((x==0||x==w-1||z==0||z==d-1) && r.nextFloat()<.06f) level.setBlock(q.above(2),Blocks.BARREL.defaultBlockState(),3);
        }
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) level.setBlock(p.offset(x,4,z),roof.defaultBlockState(),3);
        level.setBlock(p.offset(3,1,0),Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH),3);
        // 4-6 chests/barrels; every container is generously stocked.
        int n=4+r.nextInt(3); Set<Long> used=new HashSet<>();
        for(int i=0;i<n;i++) {
            BlockPos c=null;
            for(int tries=0;tries<25;tries++) { BlockPos t=p.offset(1+r.nextInt(5),0,1+r.nextInt(6)); if(used.add(t.asLong())) {c=t;break;} }
            if(c==null) continue;
            boolean barrel=r.nextFloat()<.35f; level.setBlock(c,barrel?Blocks.BARREL.defaultBlockState():Blocks.CHEST.defaultBlockState(),3);
            BlockEntity be=level.getBlockEntity(c);
            List<ItemStack> loot=LootScanner.generateContainerLoot(new Random(r.nextLong()),15+r.nextInt(8),false);
            if(be instanceof net.minecraft.world.Container inv) fillRandomSlots(inv,loot,r);
        }
        level.setBlock(p.offset(1,1,2),Blocks.CRAFTING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(5,1,2),Blocks.CARTOGRAPHY_TABLE.defaultBlockState(),3);
        if (r.nextBoolean()) {
            ArmorStand stand = EntityType.ARMOR_STAND.create(level);
            if (stand != null) {
                stand.moveTo(
                    p.getX() + 1.5,
                    p.getY() + 1.0,
                    p.getZ() + 5.5,
                    r.nextFloat() * 360.0F,
                    0.0F
                );
                level.addFreshEntity(stand);
            }
        }
        level.setBlock(p.offset(5,1,5),Blocks.BOOKSHELF.defaultBlockState(),3);
    }

    private static void rubbleMound(ServerLevel level, BlockPos center, int radius, int height, RandomSource r) {
        for(int y=0;y<height;y++) for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            double limit=radius-(y*.55); if(x*x+z*z>limit*limit) continue;
            if(r.nextFloat()<.18f) continue;
            level.setBlock(center.offset(x,y,z),randomTrashBlock(r).defaultBlockState(),3);
        }
        if(r.nextFloat()<.55f) {
            BlockPos stash=center.offset(r.nextInt(radius*2+1)-radius,0,r.nextInt(radius*2+1)-radius);
            level.setBlock(stash, r.nextBoolean()?Blocks.BARREL.defaultBlockState():Blocks.CHEST.defaultBlockState(),3);
        }
    }

    private static void scatterLargeJunk(ServerLevel level, BlockPos o, RandomSource r) {
        for(int i=0;i<28;i++) {
            BlockPos p=o.offset(r.nextInt(78)-39,0,r.nextInt(70)-20);
            if(r.nextBoolean()) rubbleMound(level,p,2+r.nextInt(3),1+r.nextInt(4),r);
            else {
                level.setBlock(p,Blocks.COBBLESTONE_WALL.defaultBlockState(),3);
                if(r.nextBoolean()) level.setBlock(p.above(),Blocks.CHAIN.defaultBlockState(),3);
            }
        }
    }

    private static Block randomTrashBlock(RandomSource r) {
        Block[] palette={Blocks.COBBLESTONE,Blocks.MOSSY_COBBLESTONE,Blocks.GRAVEL,Blocks.ANDESITE,Blocks.DIORITE,
            Blocks.COBBLED_DEEPSLATE,Blocks.BRICKS,Blocks.MOSSY_STONE_BRICKS,Blocks.OAK_PLANKS,Blocks.SPRUCE_PLANKS,
            Blocks.IRON_BLOCK,Blocks.WEATHERED_COPPER,Blocks.CUT_COPPER,Blocks.BARREL,Blocks.TNT,Blocks.DIRT,Blocks.ROOTED_DIRT};
        return palette[r.nextInt(palette.length)];
    }

    /** Clears the old generated footprint; use with care, it clears a volume around the command position. */
    public static int clear(ServerLevel level, BlockPos center, int radius) {
        int removed=0; BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        int minY=Math.max(level.getMinBuildHeight(),center.getY()-8), maxY=Math.min(level.getMaxBuildHeight()-1,center.getY()+24);
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) for(int y=minY;y<=maxY;y++) {
            p.set(center.getX()+x,y,center.getZ()+z);
            if(!level.getBlockState(p).isAir()) { level.removeBlock(p,false); removed++; }
        }
        return removed;
    }
}
