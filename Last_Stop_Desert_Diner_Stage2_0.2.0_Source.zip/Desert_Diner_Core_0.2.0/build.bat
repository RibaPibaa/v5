@echo off
gradle build
if errorlevel 1 exit /b 1
echo Built JAR: build\libs\desert-diner-core-0.2.0.jar
