#!/usr/bin/env bash
set -euo pipefail
gradle build
echo "Built JAR: build/libs/desert-diner-core-0.2.0.jar"
