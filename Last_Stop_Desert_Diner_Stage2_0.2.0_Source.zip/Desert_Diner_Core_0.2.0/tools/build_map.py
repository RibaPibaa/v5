import os, struct, gzip, json, math, random
from collections import OrderedDict

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'src/main/resources/data/desertdiner/structures/desert_diner_site.nbt')
os.makedirs(os.path.dirname(OUT), exist_ok=True)

SIZE_X=660; SIZE_Y=40; SIZE_Z=660
CENTER=330
rng=random.Random(20261114)

palette=OrderedDict()
blocks={}

def state_key(name, props=None):
    props=props or {}
    return (name, tuple(sorted((str(k),str(v)) for k,v in props.items())))

def add(x,y,z,name,props=None,replace=True):
    if not (0 <= x < SIZE_X and 0 <= y < SIZE_Y and 0 <= z < SIZE_Z):
        return
    key=state_key(name,props)
    if key not in palette:
        palette[key]=len(palette)
    p=(int(x),int(y),int(z))
    if replace or p not in blocks:
        blocks[p]=palette[key]

def p(dx,dz): return CENTER+dx, CENTER+dz

def put(dx,y,dz,name,props=None,replace=True):
    x,z=p(dx,dz); add(x,y,z,name,props,replace)

def fill(dx1,dx2,y1,y2,dz1,dz2,name,props=None):
    for y in range(y1,y2+1):
        for dx in range(dx1,dx2+1):
            for dz in range(dz1,dz2+1): put(dx,y,dz,name,props)

def line_x(dx1,dx2,y,dz,name,props=None):
    for dx in range(dx1,dx2+1): put(dx,y,dz,name,props)

def line_z(dx,y,dz1,dz2,name,props=None):
    for dz in range(dz1,dz2+1): put(dx,y,dz,name,props)

def pillar(dx,dz,y1,y2,name,props=None):
    for y in range(y1,y2+1): put(dx,y,dz,name,props)

def slab(dx,y,dz,typ='bottom',wood='spruce'):
    put(dx,y,dz,f'minecraft:{wood}_slab',{'type':typ,'waterlogged':'false'})

def stair(dx,y,dz,facing='north',half='bottom',wood='spruce'):
    put(dx,y,dz,f'minecraft:{wood}_stairs',{'facing':facing,'half':half,'shape':'straight','waterlogged':'false'})

def pane(dx,y,dz, name='minecraft:glass_pane'):
    put(dx,y,dz,name,{'east':'true','north':'true','south':'true','west':'true','waterlogged':'false'})

def fence(dx,y,dz,name='minecraft:spruce_fence'):
    put(dx,y,dz,name,{'east':'false','north':'false','south':'false','west':'false','waterlogged':'false'})

def trapdoor(dx,y,dz,facing='north',half='top',open_='false',material='iron'):
    put(dx,y,dz,f'minecraft:{material}_trapdoor',{'facing':facing,'half':half,'open':open_,'powered':'false','waterlogged':'false'})

def lantern(dx,y,dz,hanging=False):
    put(dx,y,dz,'minecraft:lantern',{'hanging':str(hanging).lower(),'waterlogged':'false'})

def door(dx,y,dz,facing='south',half='lower',hinge='left'):
    put(dx,y,dz,'minecraft:dark_oak_door',{'facing':facing,'half':half,'hinge':hinge,'open':'false','powered':'false'})

# --- Main kiosk: 25 x 20 post-apocalyptic roadside diner ---
# Local offsets relative to map center; facade faces +Z.
KX=-40; KZ=-15
kx0,kx1=KX-12,KX+12
kz0,kz1=KZ-11,KZ+9
# Foundation and interior floor
for dx in range(kx0-1,kx1+2):
    for dz in range(kz0-1,kz1+2):
        edge=dx in (kx0-1,kx1+1) or dz in (kz0-1,kz1+1)
        put(dx,0,dz,'minecraft:cobblestone' if edge else 'minecraft:spruce_planks')
# Outer walls, mixed sandstone and timber
for y in range(1,7):
    for dx in range(kx0,kx1+1):
        for dz in (kz0,kz1):
            # service opening on front facade
            if dz==kz1 and -46 <= dx <= -34 and 3 <= y <= 5: continue
            material='minecraft:cut_sandstone' if y<=2 else 'minecraft:dark_oak_planks'
            put(dx,y,dz,material)
    for dz in range(kz0,kz1+1):
        for dx in (kx0,kx1):
            # side window openings
            if dx==kx0 and -20<=dz<=-17 and 3<=y<=5: continue
            material='minecraft:cut_sandstone' if y<=2 else 'minecraft:dark_oak_planks'
            put(dx,y,dz,material)
# Timber frame posts
for dx,dz in [(kx0,kz0),(kx0,kz1),(kx1,kz0),(kx1,kz1),(-46,-15),(-34,-15)]:
    pillar(dx,dz,1,7,'minecraft:stripped_spruce_log',{'axis':'y'})
# Front service counter and sill
for dx in range(-47,-33):
    put(dx,1,kz1+1,'minecraft:dark_oak_slab',{'type':'top','waterlogged':'false'})
    put(dx,2,kz1+1,'minecraft:dark_oak_planks')
# Counter inside
for dx in range(-47,-33): put(dx,1,kz1-1,'minecraft:spruce_slab',{'type':'top','waterlogged':'false'})
# Glass windows left and right of serving opening
for dx in list(range(-51,-47))+list(range(-33,-28)):
    for y in range(3,6): pane(dx,y,kz1)
for dz in range(-20,-16):
    for y in range(3,6): pane(kx0,y,dz)
# Side door on east wall
for y,half in [(1,'lower'),(2,'upper')]: door(kx1,y,-12,'east',half,'left')
# Back door
for y,half in [(1,'lower'),(2,'upper')]: door(-41,y,kz0,'north',half,'right')
# Roof beams and patchwork roof
for dx in range(kx0-1,kx1+2):
    put(dx,7,kz0-1,'minecraft:stripped_spruce_log',{'axis':'x'})
    put(dx,7,kz1+1,'minecraft:stripped_spruce_log',{'axis':'x'})
for dz in range(kz0,kz1+1):
    put(kx0-1,7,dz,'minecraft:stripped_spruce_log',{'axis':'z'})
    put(kx1+1,7,dz,'minecraft:stripped_spruce_log',{'axis':'z'})
for dx in range(kx0-1,kx1+2):
    for dz in range(kz0-1,kz1+2):
        material='minecraft:dark_oak_slab' if rng.random()<0.55 else 'minecraft:gray_concrete'
        if rng.random()<0.08: material='minecraft:iron_trapdoor'
        if material=='minecraft:dark_oak_slab': slab(dx,8,dz,'top','dark_oak')
        elif material=='minecraft:iron_trapdoor': trapdoor(dx,8,dz,'north','top','false','iron')
        else: put(dx,8,dz,material)
# Roof repair patches and vents
for dx,dz in [(-49,-22),(-31,-10),(-35,-24),(-44,-8)]:
    put(dx,9,dz,'minecraft:iron_trapdoor',{'facing':'north','half':'top','open':'false','powered':'false','waterlogged':'false'})
put(-31,9,-23,'minecraft:iron_bars',{'east':'true','north':'false','south':'false','west':'true','waterlogged':'false'})
put(-31,10,-23,'minecraft:iron_bars',{'east':'true','north':'false','south':'false','west':'true','waterlogged':'false'})
# Service awning: striped canvas, supported by timber posts
for dx in range(-52,-27):
    for dz in range(-6,-1):
        color='minecraft:red_wool' if (dx//2)%2==0 else 'minecraft:white_wool'
        if (dx+dz)%11==0: color='minecraft:gray_wool'
        put(dx,6,dz,color)
for dx in (-51,-28):
    for dz in (-5,-2): pillar(dx,dz,1,5,'minecraft:spruce_fence')
# Awning front trim
for dx in range(-52,-27): put(dx,5,-1,'minecraft:dark_oak_fence')
# Sign board above service window, with block lettering
fill(-49,-31,9,12,-8,-8,'minecraft:birch_planks')
# Pixel letters DINER, red and dark accents
letters={
'D':['110','101','101','101','110'],
'I':['111','010','010','010','111'],
'N':['101','111','111','111','101'],
'E':['111','100','110','100','111'],
'R':['110','101','110','101','101']}
# fit 5 letters, each 3x5 with 1 gap
for li,ch in enumerate('DINER'):
    pattern=letters[ch]
    xstart=-48+li*4
    for ry,row in enumerate(pattern):
        for cx,val in enumerate(row):
            if val=='1': put(xstart+cx,12-ry,-7,'minecraft:red_concrete')
# Interior kitchen: stations, cabinets and storage
# Floor mat and work zone
for dx in range(-49,-31):
    for dz in range(-22,-13):
        if (dx+dz)%7==0: put(dx,0,dz,'minecraft:polished_andesite')
# Cabinets against rear wall
for dx in range(-50,-30,3):
    put(dx,1,-24,'farmersdelight:oak_cabinet',{'facing':'south'})
# Hands-On Delight stations
put(-48,1,-18,'farmersdelight:cooking_pot',{'facing':'north','support':'none'})
put(-45,1,-18,'farmersdelight:cutting_board',{'facing':'north'})
put(-42,1,-18,'farmersdelight:stove',{'facing':'north','lit':'false'})
put(-39,1,-18,'farmersdelight:skillet',{'facing':'north','support':'false'})
# Extra prep/storage
put(-35,1,-18,'minecraft:smoker',{'facing':'north','lit':'false'})
put(-33,1,-18,'minecraft:barrel',{'facing':'north','open':'false'})
put(-49,1,-21,'minecraft:crafting_table')
put(-46,1,-21,'minecraft:chest',{'facing':'north','type':'single','waterlogged':'false'})
put(-36,1,-21,'minecraft:barrel',{'facing':'north','open':'false'})
# Interior lights
for dx in (-48,-40,-32):
    put(dx,6,-17,'minecraft:chain',{'axis':'y'})
    lantern(dx,5,-17,True)
# Dining porch: tables and benches
for dx in (-50,-31):
    put(dx,1,4,'minecraft:oak_fence')
    put(dx,2,4,'minecraft:oak_pressure_plate',{'powered':'false'})
    put(dx+1,1,4,'minecraft:oak_stairs',{'facing':'west','half':'bottom','shape':'straight','waterlogged':'false'})
# Water tank and side generator
for dx in (-28,-27):
    for dz in (-25,-24):
        for y in (8,9): put(dx,y,dz,'minecraft:iron_block')
for dx in (-28,-27):
    for dz in (-25,-24): put(dx,10,dz,'minecraft:iron_bars',{'east':'true','north':'true','south':'true','west':'true','waterlogged':'false'})
put(-27,1,-23,'minecraft:furnace',{'facing':'west','lit':'false'})
put(-27,2,-23,'minecraft:lightning_rod',{'facing':'up','waterlogged':'false'})
# Kiosk exterior debris and crates
for dx,dz in [(-56,-24),(-55,-23),(-25,-25),(-25,-23),(-55,5)]:
    put(dx,1,dz,'minecraft:barrel',{'facing':'up','open':'false'})
for dx,dz in [(-56,-21),(-25,-20),(-54,8)]:
    put(dx,1,dz,'minecraft:hay_block')
put(-54,-0 if False else 1,7,'minecraft:dead_bush')

# --- Gas station: shop + canopy + pumps ---
GX=60; GZ=17
gx0,gx1=GX-14,GX+14
gz0,gz1=GZ-12,GZ+12
# Concrete forecourt patch
for dx in range(GX-20,GX+21):
    for dz in range(GZ-22,GZ+17):
        if (dx+dz)%17==0: put(dx,0,dz,'minecraft:gravel')
        elif (dx*3+dz)%23==0: put(dx,0,dz,'minecraft:light_gray_concrete')
# Shop foundation/floor
for dx in range(gx0-1,gx1+2):
    for dz in range(gz0-1,gz1+2):
        edge=dx in (gx0-1,gx1+1) or dz in (gz0-1,gz1+1)
        put(dx,0,dz,'minecraft:stone_bricks' if edge else 'minecraft:smooth_sandstone')
# walls with industrial red band
for y in range(1,6):
    for dx in range(gx0,gx1+1):
        for dz in (gz0,gz1):
            # Front windows on north wall (z=gz0)
            if dz==gz0 and 48<=dx<=70 and 2<=y<=4: continue
            # Shop entrance
            if dz==gz0 and dx in (57,58) and y in (1,2): continue
            material='minecraft:stone_bricks' if y<=2 else ('minecraft:light_gray_concrete' if y<5 else 'minecraft:red_concrete')
            put(dx,y,dz,material)
    for dz in range(gz0,gz1+1):
        for dx in (gx0,gx1):
            if dx==gx1 and 20<=dz<=24 and 2<=y<=4: continue
            material='minecraft:stone_bricks' if y<=2 else ('minecraft:light_gray_concrete' if y<5 else 'minecraft:red_concrete')
            put(dx,y,dz,material)
# Windows and door
for dx in range(48,71):
    for y in range(2,5): pane(dx,y,gz0)
for y,half in [(1,'lower'),(2,'upper')]:
    put(57,y,gz0,'minecraft:iron_door',{'facing':'north','half':half,'hinge':'left','open':'false','powered':'false'})
# side service window
for dz in range(20,25):
    for y in range(2,5): pane(gx1,y,dz)
# roof
for dx in range(gx0-1,gx1+2):
    for dz in range(gz0-1,gz1+2):
        if dx in (gx0-1,gx1+1) or dz in (gz0-1,gz1+1): put(dx,6,dz,'minecraft:dark_oak_slab',{'type':'top','waterlogged':'false'})
        else: put(dx,6,dz,'minecraft:gray_concrete')
# red fascia and broken roof patches
for dx in range(gx0-1,gx1+2): put(dx,7,gz0-1,'minecraft:red_concrete')
for dx,dz in [(46,27),(70,28),(49,7),(73,15)]:
    put(dx,7,dz,'minecraft:iron_trapdoor',{'facing':'north','half':'top','open':'false','powered':'false','waterlogged':'false'})
# Shop interior shelving and counter
for dx in range(46,74,4):
    put(dx,1,26,'minecraft:barrel',{'facing':'north','open':'false'})
    put(dx,2,26,'minecraft:barrel',{'facing':'north','open':'false'})
for dx in range(50,70): put(dx,1,8,'minecraft:dark_oak_slab',{'type':'top','waterlogged':'false'})
put(53,1,11,'minecraft:smoker',{'facing':'east','lit':'false'})
put(65,1,11,'minecraft:chest',{'facing':'south','type':'single','waterlogged':'false'})
put(69,1,11,'minecraft:crafting_table')
# Shop lights
for dx in (48,60,72):
    put(dx,5,17,'minecraft:chain',{'axis':'y'}); lantern(dx,4,17,True)
# Canopy over pumps, facing road (-Z)
for dx in range(39,82):
    for dz in range(-12,8):
        if dz in (-12,7) or dx in (39,81):
            put(dx,9,dz,'minecraft:dark_oak_slab',{'type':'top','waterlogged':'false'})
        else:
            color='minecraft:red_concrete' if (dx//3)%2==0 else 'minecraft:white_concrete'
            if rng.random()<0.05: color='minecraft:gray_concrete'
            put(dx,9,dz,color)
# Canopy columns
for dx,dz in [(41,-10),(79,-10),(41,5),(79,5)]:
    pillar(dx,dz,1,8,'minecraft:polished_blackstone_bricks')
    put(dx,8,dz,'minecraft:iron_block')
# Pumps
for px in (49,69):
    put(px,0,-2,'minecraft:polished_blackstone')
    put(px,1,-2,'minecraft:iron_block')
    put(px,2,-2,'minecraft:red_concrete')
    put(px,3,-2,'minecraft:light_gray_concrete')
    pane(px,3,-1,'minecraft:glass_pane')
    put(px,4,-2,'minecraft:stone_button',{'face':'wall','facing':'south','powered':'false'})
    put(px,1,-3,'minecraft:iron_trapdoor',{'facing':'north','half':'top','open':'false','powered':'false','waterlogged':'false'})
    put(px,5,-2,'minecraft:chain',{'axis':'y'})
# GAS lettering on fascia
fill(47,74,10,12,-12,-12,'minecraft:white_concrete')
for li,ch in enumerate('GAS'):
    patterns={'G':['111','100','101','101','111'],'A':['010','101','111','101','101'],'S':['111','100','111','001','111']}[ch]
    xstart=50+li*7
    for ry,row in enumerate(patterns):
        for cx,val in enumerate(row):
            if val=='1': put(xstart+cx,14-ry,-11,'minecraft:red_concrete')
# Fuel drums, junk and a small utility shed
for dx,dz in [(75,28),(77,28),(78,28),(75,30)]:
    put(dx,1,dz,'minecraft:barrel',{'facing':'up','open':'false'})
    if rng.random()<0.5: put(dx,2,dz,'minecraft:iron_bars',{'east':'true','north':'true','south':'true','west':'true','waterlogged':'false'})
# Gas station wall light
for dx in (45,75):
    put(dx,5,5,'minecraft:chain',{'axis':'y'}); lantern(dx,4,5,True)

# --- Abandoned car near the road, deliberately half-buried ---
def build_wreck(cx,cz,angle='east'):
    # Compact 7x11 wreck with body and four exposed wheels.
    # Long axis Z.
    for dz in range(-5,6):
        for dx in range(-3,4):
            if abs(dx)==3 and dz in (-4,-1,2,5):
                put(cx+dx,1,cz+dz,'minecraft:black_concrete')
            elif abs(dx)<=2:
                mat='minecraft:light_gray_concrete' if rng.random()<0.55 else 'minecraft:gray_concrete'
                if dz in (-5,5): mat='minecraft:iron_block'
                put(cx+dx,1,cz+dz,mat)
    for dz in (-3,0,3):
        for dx in (-2,2): put(cx+dx,2,cz+dz,'minecraft:black_concrete')
    for dx in (-1,0,1):
        put(cx+dx,2,cz-2,'minecraft:blue_stained_glass')
        put(cx+dx,2,cz+2,'minecraft:blue_stained_glass')
    for dx in (-2,2):
        put(cx+dx,2,cz,'minecraft:iron_trapdoor',{'facing':'north','half':'top','open':'false','powered':'false','waterlogged':'false'})
    for dx in (-2,-1,0,1,2):
        put(cx+dx,3,cz,'minecraft:gray_concrete')
    # Missing body panels and exposed frame
    for dx,dz in [(3,-3),(-3,3),(3,4),(-2,-5),(2,5)]: put(cx+dx,1,cz+dz,'minecraft:iron_bars',{'east':'true','north':'true','south':'true','west':'true','waterlogged':'false'})
    put(cx,4,cz-4,'minecraft:dead_bush')

build_wreck(20,-7)

# --- Road: broken, irregular asphalt that dissolves into sand ---
road_pts=[(-27,-3),(-14,-9),(2,-8),(17,-2),(29,6),(43,5)]
# Interpolate polyline by dense linear samples, then use nearest segment distance.
segments=list(zip(road_pts[:-1],road_pts[1:]))
for dx in range(-35,52):
    for dz in range(-22,20):
        best=1e9; tbest=0
        for (ax,az),(bx,bz) in segments:
            vx=bx-ax; vz=bz-az
            den=vx*vx+vz*vz
            t=max(0,min(1,((dx-ax)*vx+(dz-az)*vz)/den))
            qx=ax+t*vx; qz=az+t*vz
            d=math.hypot(dx-qx,dz-qz)
            if d<best: best=d; tbest=t
        # irregular shoulder and drift edges
        noise=math.sin(dx*0.71+dz*0.23)*0.55+math.sin(dz*0.53-dx*0.17)*0.35
        width=3.1+noise
        if best < width:
            r=rng.random()
            if best > width-0.7:
                mats=['minecraft:sand','minecraft:gravel','minecraft:coarse_dirt','minecraft:gray_concrete']
                weights=[0.46,0.28,0.18,0.08]
                mat=rng.choices(mats,weights)[0]
            elif r<0.12: mat='minecraft:sand'
            elif r<0.27: mat='minecraft:gravel'
            elif r<0.37: mat='minecraft:cracked_stone_bricks'
            elif r<0.47: mat='minecraft:light_gray_concrete'
            elif r<0.54: mat='minecraft:blackstone'
            else: mat='minecraft:gray_concrete'
            put(dx,0,dz,mat)
            # broken crack lines and loose gravel at random edges
            if best<2.0 and rng.random()<0.07:
                put(dx,0,dz,'minecraft:cracked_stone_bricks')
        elif best < width+2.8 and rng.random()<0.58:
            mat=rng.choice(['minecraft:gravel','minecraft:coarse_dirt','minecraft:sand','minecraft:sandstone'])
            put(dx,0,dz,mat)
# Scattered sand drifts crossing the asphalt, making the road look old
for cx,cz,rx,rz in [(-8,-7,4,2),(10,-3,3,2),(26,4,4,2),(37,5,3,2)]:
    for dx in range(cx-rx,cx+rx+1):
        for dz in range(cz-rz,cz+rz+1):
            if ((dx-cx)**2/(rx*rx+0.1)+(dz-cz)**2/(rz*rz+0.1))<1 and rng.random()<0.68:
                put(dx,0,dz,'minecraft:sand')

# --- Roadside rubble, scrub and low dunes ---
for cx,cz in [(-63,25),(-8,36),(21,-34),(80,-16),(89,39),(-76,-38),(8,62),(-90,4)]:
    # low uneven sand/gravel rubble mounds
    radius=rng.randint(2,4)
    for dx in range(-radius,radius+1):
        for dz in range(-radius,radius+1):
            if dx*dx+dz*dz<=radius*radius and rng.random()<0.78:
                h=1 if abs(dx)+abs(dz)>radius-1 else rng.choice([1,2,2,3])
                for y in range(0,h):
                    mat='minecraft:sand' if rng.random()<0.75 else 'minecraft:sandstone'
                    put(cx+dx,y,cz+dz,mat)
# Sparse scrub around the cleared pad, excluding buildings/road footprints.
for _ in range(110):
    dx=rng.randint(-112,112); dz=rng.randint(-112,112)
    if dx*dx+dz*dz>108*108: continue
    # avoid the buildings and road core
    if -58<=dx<=-22 and -31<=dz<=14: continue
    if 36<=dx<=83 and -15<=dz<=43: continue
    if -35<=dx<=48 and -18<=dz<=18: continue
    if rng.random()<0.72:
        put(dx,1,dz,'minecraft:dead_bush')
    else:
        put(dx,1,dz,'minecraft:cactus')
# Occasional bone piles and rusted fence fragments
for cx,cz in [(-78,47),(14,-68),(87,-42),(-95,-15),(95,62)]:
    for i in range(4):
        put(cx+i,1,cz,'minecraft:bone_block',{'axis':'y'})
    for i in range(3):
        put(cx+i,2,cz+1,'minecraft:iron_bars',{'east':'true','north':'true','south':'true','west':'true','waterlogged':'false'})

# --- Invisible boundary ring at 300 blocks, with visual buffer beyond it ---
B=300; H=34
for off in range(-B,B+1):
    for y in range(0,H+1):
        put(-B,y,off,'minecraft:barrier')
        put(B,y,off,'minecraft:barrier')
        put(off,y,-B,'minecraft:barrier')
        put(off,y,B,'minecraft:barrier')
# Reinforce four corners
for dx in (-B,B):
    for dz in (-B,B):
        for y in range(H+1):
            for ox in (-1,0,1):
                for oz in (-1,0,1): put(dx+ox,y,dz+oz,'minecraft:barrier')

# Outer buffer: broken billboards, poles, distant wrecks and collapsed shacks.
# North billboard beyond barrier, visible from the diner.
for dx in range(-8,9,8): pillar(dx,-316,0,12,'minecraft:dark_oak_fence')
fill(-10,10,8,13,-316,-316,'minecraft:gray_concrete')
for dx in range(-8,9):
    if dx%3!=0: put(dx,10,-315,'minecraft:red_concrete')
for dx in (-8,8):
    for y in range(14,18): put(dx,y,-316,'minecraft:iron_bars',{'east':'true','north':'false','south':'false','west':'true','waterlogged':'false'})
# Fallen billboard panel on ground
for dx in range(-6,7):
    for dz in range(-2,1): put(dx,1,-322+dz,'minecraft:light_gray_concrete')
# East-side abandoned vehicle outside the wall
build_wreck(316,65)
# South telephone pole and sagging line
for dx,dz in [(-92,315),(-30,319),(38,316)]:
    pillar(dx,dz,0,15,'minecraft:stripped_spruce_log',{'axis':'y'})
    for ox in (-2,-1,0,1,2): put(dx+ox,14,dz,'minecraft:dark_oak_fence')
for dx in range(-92,-29):
    if dx%2==0: put(dx,13,317,'minecraft:chain',{'axis':'x'})
# West-side ruined shed silhouette
for dx in range(-326,-316):
    for dz in range(-142,-132):
        if dx in (-326,-316) or dz in (-142,-132):
            put(dx,1,dz,'minecraft:cobblestone')
            put(dx,2,dz,'minecraft:cracked_stone_bricks')
for dx in range(-326,-316):
    put(dx,5,-142,'minecraft:dark_oak_slab',{'type':'top','waterlogged':'false'})
# Distant scrub and rubble on the buffer ring
for _ in range(70):
    side=rng.choice(['n','s','e','w'])
    if side=='n': dx=rng.randint(-325,325); dz=rng.randint(-328,-306)
    elif side=='s': dx=rng.randint(-325,325); dz=rng.randint(306,328)
    elif side=='e': dx=rng.randint(306,328); dz=rng.randint(-325,325)
    else: dx=rng.randint(-328,-306); dz=rng.randint(-325,325)
    if rng.random()<0.55: put(dx,1,dz,'minecraft:dead_bush')
    else:
        put(dx,1,dz,'minecraft:gravel')
        if rng.random()<0.4: put(dx,2,dz,'minecraft:dead_bush')

# NBT helpers
def nbt_string(s):
    b=s.encode('utf-8'); return struct.pack('>H',len(b))+b

def tag_byte(name,val): return b'\x01'+nbt_string(name)+struct.pack('>b',int(val))
def tag_int(name,val): return b'\x03'+nbt_string(name)+struct.pack('>i',int(val))
def tag_string(name,val): return b'\x08'+nbt_string(name)+nbt_string(val)
def tag_int_array(name,vals):
    return b'\x0b'+nbt_string(name)+struct.pack('>i',len(vals))+b''.join(struct.pack('>i',int(v)) for v in vals)
def tag_compound_payload(entries):
    return b''.join(entries)+b'\x00'
def tag_compound(name,entries): return b'\x0a'+nbt_string(name)+tag_compound_payload(entries)
def tag_list(name,elem_type,items):
    return b'\x09'+nbt_string(name)+bytes([elem_type])+struct.pack('>i',len(items))+b''.join(items)

# Palette compounds
palette_tags=[]
for (name, props), idx in palette.items():
    ent=[tag_string('Name',name)]
    if props:
        pent=[tag_string(k,v) for k,v in props]
        ent.append(tag_compound('Properties',pent))
    palette_tags.append(tag_compound_payload(ent))

# Block compounds
block_tags=[]
for (x,y,z), state in sorted(blocks.items(), key=lambda it:(it[0][1],it[0][2],it[0][0])):
    block_tags.append(tag_compound_payload([tag_int_array('pos',[x,y,z]),tag_int('state',state)]))

root_entries=[
    tag_int('DataVersion',3465),
    tag_int_array('size',[SIZE_X,SIZE_Y,SIZE_Z]),
    tag_list('palette',10,palette_tags),
    tag_list('blocks',10,block_tags),
    tag_list('entities',10,[]),
]
raw=b'\x0a'+nbt_string('')+tag_compound_payload(root_entries)
with open(OUT,'wb') as f:
    f.write(gzip.compress(raw,compresslevel=9,mtime=0))
print('Wrote',OUT)
print('palette states',len(palette),'blocks',len(blocks),'raw bytes',len(raw),'gzip bytes',os.path.getsize(OUT))
# simple report for QA
from collections import Counter
cnt=Counter()
for k,v in palette.items(): cnt[k[0]]+=sum(1 for s in blocks.values() if s==palette[k])
print('Top blocks:',cnt.most_common(20))
# write simple top-down block preview for internal QA
try:
 from PIL import Image
 colors={
  'minecraft:barrier':(255,0,255),'minecraft:gray_concrete':(90,92,95),'minecraft:light_gray_concrete':(155,155,150),
  'minecraft:red_concrete':(150,40,35),'minecraft:white_concrete':(225,220,205),'minecraft:sand':(220,190,120),
  'minecraft:gravel':(125,118,105),'minecraft:coarse_dirt':(120,91,55),'minecraft:cracked_stone_bricks':(95,95,90),
  'minecraft:blackstone':(35,32,33),'minecraft:smooth_sandstone':(210,185,130),'minecraft:stone_bricks':(115,110,100),
  'minecraft:spruce_planks':(115,82,48),'minecraft:dark_oak_planks':(70,47,29),'minecraft:dark_oak_slab':(80,54,32),
  'minecraft:dead_bush':(95,65,30),'minecraft:cactus':(40,95,45),'minecraft:iron_block':(185,185,180),
  'minecraft:polished_blackstone_bricks':(45,45,50),'minecraft:cut_sandstone':(220,195,145),'minecraft:cobblestone':(100,100,95),
  'minecraft:birch_planks':(220,205,155),'minecraft:red_wool':(160,35,30),'minecraft:white_wool':(230,225,210),
 }
 img=Image.new('RGB',(SIZE_X,SIZE_Z),(218,187,122))
 pix=img.load()
 for (x,y,z),st in blocks.items():
  if y>0: continue
  key=list(palette.keys())[st][0]
  if key!='minecraft:barrier': pix[x,z]=colors.get(key,(130,110,80))
 # draw boundary as thin magenta line only for QA
 for i in range(SIZE_X):
  for b in [30,630]:
   pix[i,b]=(255,0,255); pix[b,i]=(255,0,255)
 preview_dir=os.path.join(ROOT,'preview')
 os.makedirs(preview_dir,exist_ok=True)
 img.save(os.path.join(preview_dir,'desert_diner_site_topdown.png'))
except Exception as e:
 print('preview failed',e)
