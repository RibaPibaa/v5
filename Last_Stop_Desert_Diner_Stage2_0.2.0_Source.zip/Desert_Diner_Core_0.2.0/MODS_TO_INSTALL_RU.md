# Last Stop: Desert Diner — моды и зависимости

Целевая платформа: **Minecraft 1.20.1 · Forge 47.4.20 · Java 17**.

В текущей сборке уже есть Farmer's Delight 1.3.4, Hands-On Delight 1.4.1, Diegesis и JEI. Hands-On Delight 1.4.1 — важная часть кухни: он открывает кастрюлю, разделочную доску, сковороду и плиту прямо в мире, а не через обычные меню.

## 1. Базовая кухня — уже установлена

- **Farmer's Delight 1.3.4 (Forge 1.20.1)** — https://www.curseforge.com/minecraft/mc-mods/farmers-delight
- **Diegesis 1.0.0-beta.9 (Forge 1.20.1)** — https://www.curseforge.com/minecraft/mc-mods/diegesis
- **Hands-On Delight 1.4.1 (Forge 1.20.1)** — https://www.curseforge.com/minecraft/mc-mods/hands-on-delight
  - Обязательные основы: Farmer's Delight и Diegesis.
  - Установленная версия 1.4.1 новее версии 1.2.0, в чьём changelog уже были перечислены интеграции с рядом дополнений Farmer's Delight.
- **JEI 15.74.0.234 (Forge 1.20.1)** — https://www.curseforge.com/minecraft/mc-mods/jei

## 2. Дополнения к еде — рекомендуемый набор

Все версии ниже существуют для **Forge 1.20.1**. Добавляй их в `mods` вместе с зависимостями, если они указаны на странице конкретного файла.

| Мод и версия | Что добавляет | Интеграция с Hands-On Delight |
|---|---|---|
| **Delightful 3.8.1** — https://www.curseforge.com/minecraft/mc-mods/delightful/files/8203343 | Бургеры, салаты, сладости, кактусовый стейк и другие блюда | В changelog Hands-On Delight прямо заявлены блюда Delightful и изменённые им рецепты на доске |
| **Cultural Delights 0.16.7 (beta)** — https://www.curseforge.com/minecraft/mc-mods/cultural-delights/files/8126187 | Кукуруза, авокадо, баклажаны, огурцы, бобы, корица и блюда разных кухонь | Рецепты аддона проверяем в игре; для блюд Farmer's Delight используется общая система доски |
| **Brewin' and Chewin' 3.2.1** — https://www.curseforge.com/minecraft/mc-mods/brewin-and-chewin/files/6237884 | Напитки, сыр, ферментация и бочка | Hands-On Delight прямо поддерживает бочку Brewin' and Chewin' как интерактивную станцию |
| **End's Delight 2.6.1+forge.1.20.1 (beta)** — https://www.curseforge.com/minecraft/mc-mods/ends-delight/files/8675193 | Блюда из ресурсов Энда | В Hands-On Delight прямо заявлена поддержка печи End's Delight и блюд аддона |
| **My Nether's Delight 1.10.4-backport.1** — https://www.curseforge.com/minecraft/mc-mods/my-nethers-delight/files/8636385 | Мясо хоглинов, страйдеров и другие блюда Незера | В Hands-On Delight прямо заявлена поддержка печи My Nether's Delight и блюд аддона |
| **Miner's Delight 1.20.1-1.2** — https://modrinth.com/mod/miners-delight | Подземные ингредиенты, блюда и медная кастрюля | HOD поддерживает медную кастрюлю, но версия аддона старая — ставить отдельно и проверять с Farmer's Delight 1.3.4 |
| **Dungeons Delight 1.3.2** — https://www.curseforge.com/minecraft/mc-mods/dungeons-delight/files/9446247 | Блюда из монстров и подземелий | В Hands-On Delight прямо заявлена поддержка кастрюли Dungeons Delight; версия 1.3.2 указывает совместимость с Farmer's Delight 1.3.4+ |
| **Barbeque's Delight 1.0.6** — https://www.curseforge.com/minecraft/mc-mods/barbeques-delight/files/8004548 | Шашлыки, кебабы, приправы и гриль | В Hands-On Delight прямо заявлена сборка шашлыков и bibimbap на доске; у гриля остаётся собственная механика |
| **Chopper's Delight 1.2.3** — https://www.curseforge.com/minecraft/mc-mods/choppers-delight/files/9494599 | Разделочные доски разных пород дерева и декор | Hands-On Delight прямо указывает поддержку разделочных досок Chopper's Delight |
| **Farmer's Respite 2.1.2** — https://www.curseforge.com/minecraft/mc-mods/farmers-respite/files/5543547 | Чай, кофе, какао, сидр, пироги и печенье | Рецепты Farmer's Delight-типа должны использовать общие станции; собственный чайник проверяем отдельно |
| **Corn Delight 1.1.8** — https://modrinth.com/mod/corn-delight | Кукуруза и блюда из неё | Проверяем рецепты на доске и в кастрюле после установки; требуется Mysterious Mountain Lib 1.6.34 |

### Дополнительные кандидаты — не ставить одновременно с первой группой

- **Farmer's Delight: HoE 0.6.1 (Forge 1.20.1, beta)** — https://www.curseforge.com/minecraft/mc-mods/farmers-delight-hoe — центральноевропейские продукты, молоко и сыр. Новая beta-версия; сначала проверяем отдельно.
- **Alex's Mobs Delight 1.1.0** — https://www.curseforge.com/minecraft/mc-mods/alexs-mobs-delight — около сотни блюд, но требует также Alex's Mobs. Добавит много существ в мир, поэтому подключим отдельно, если захочешь.
- **My Nether's Delight Fix 1.12.0** — https://www.curseforge.com/minecraft/mc-mods/my-nethers-delight-fix — не пищевой аддон, а необязательный патч совместимости для Forge 1.20.1 + Farmer's Delight 1.3+. Может исправлять вылеты при размещении блоков над некоторыми плитами аддонов и стартовые ошибки Miner's Delight. Не ставить вслепую: добавляем только если конкретно эти вылеты появятся; удалить, если оригинальные аддоны уже исправили проблему.

**Зависимость Corn Delight:** [Mysterious Mountain Lib 1.6.34 для Forge 1.20.1](https://modrinth.com/mod/mmlib/version/1.6.34-1.20.1). Её тоже положить в `mods`.

## 3. Что пока откладываем

- **Pizza Delight** — https://www.curseforge.com/minecraft/mc-mods/pizza-delight — требует Create. Оставляем на позднюю прогрессию, когда откроется автоматизация.
- **Create и Create: Central Kitchen** — не ставим на этом этапе. Сначала завершаем мир и проверяем кухонные рецепты; цепочку автоматизации подберём отдельно под Forge 1.20.1.

## 4. Как добавлять

1. Полностью закрой Minecraft.
2. В Prism Launcher нажми правой кнопкой по экземпляру → **Папка**.
3. Открой `minecraft/mods`.
4. Перетащи туда скачанные `.jar`-файлы. Не распаковывай их.
5. Добавь обязательные зависимости конкретного мода.
6. Запусти игру и проверь JEI: поиск по названию блюда и просмотр способа приготовления.
7. Для проверки Hands-On Delight положи ингредиенты на соответствующую станцию и закончи приготовление вручную.

Добавляй сначала 3–4 мода, проверяй запуск, затем следующую группу. Если появится ошибка — сохрани `logs/latest.log`; по нему можно найти конкретный несовместимый аддон.

**Важно:** новые культуры и растения чаще всего появляются только в ещё не созданных чанках. Для проверки worldgen дополнений используй новый тестовый мир.

## 5. Create — поздняя прогрессия после выплаты долга 1400C

Create и кухонную автоматизацию оставляем закрытыми до выплаты долга. Когда дойдём до этого этапа, подберём проверенную связку Create + Central Kitchen + зависимости именно для Forge 1.20.1. Не скачивай старые аддоны Create наугад.

## 6. Примечания по совместимости

- Нужны именно файлы **Forge 1.20.1**, не Fabric и не NeoForge.
- Hands-On Delight умеет готовить на доске блюда Farmer's Delight и его аддонов; прямо заявлены также End's Delight, My Nether's Delight, Miner's Delight, Dungeons Delight, Chopper's Delight и Barbeque's Delight. Бочка Brewin' and Chewin' тоже поддерживается как интерактивная станция.
- Общие правила HOD: `farmersdelight:cooking` готовится в кастрюле, `farmersdelight:cutting` — на доске, а рецепты костра работают на сковороде/плите. Если стороннее блюдо собирается обычным crafting-рецептом и не распознаётся на доске, его результат можно добавить в тег `handson_delight:assembled` через datapack или KubeJS.
- Farmer's Respite добавляет собственный чайник; он не превращается автоматически в станцию HOD, поэтому проверяем его отдельно.
- Если рецепт есть в JEI, но он не запускается на ожидаемой станции, это не обязательно означает поломку всего мода: возможно, у рецепта отдельный тип станции.
- Установка новых пищевых модов не означает, что Desert Diner Core уже автоматически учитывает каждое новое блюдо в системе меню. Это отдельная интеграция следующего этапа: нужно регистрировать приготовление каждого блюда, включая интерактивное завершение на станциях.
