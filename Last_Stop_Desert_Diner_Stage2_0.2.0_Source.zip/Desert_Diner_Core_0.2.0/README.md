# Desert Diner Core — source project 0.2.0

**Target:** Minecraft 1.20.1 · Forge 47.4.20+ · Java 17

This is the second source milestone for the Last Stop: Desert Diner mod.

## Included in this source package

- `C Coin` and `C Bar` custom currency items.
- Original 32×32 transparent pixel-art textures for both currency items.
- `M` key opens a custom 3-column menu screen.
- Menu starts as a 3×3 grid: eight dish positions and a final `+` cell. Its available grid space grows as the world learns more food recipes.
- The grid grows downward as the menu fills.
- Food catalog built from loaded recipe outputs.
- Recipe information window with ingredient icons when recipe data exposes ingredients.
- World-level saved data for learned dishes, menu slots, prices, and kiosk state.
- `K` key toggles kiosk open/closed state.
- A fixed desert site template is installed once per new world save: diner, gas station, cracked road, sand drift transitions, invisible 600×600 boundary and distant buffer scenery. The first load may pause while the pad and structures are generated.
- The installer searches for a desert biome, flattens an irregular central pad and blends its edge into the natural terrain.
- Farmer’s Delight cooking pot, cutting board, stove and skillet blocks are placed inside the diner (station interactions still need an in-game check).
- Prices in this prototype are clamped to 1–9C around a 5C baseline.
- Server/client sync for menu data.

## Important compatibility note

The discovery hook in this source version listens to Forge's `PlayerEvent.ItemCraftedEvent` and `PlayerEvent.ItemSmeltedEvent`. It reliably covers the standard crafting/smelting paths that fire those events. Hands-On Delight uses in-world station interactions; those station completion callbacks must be verified against the exact installed Hands-On Delight build and connected through a dedicated adapter. The project does **not** falsely mark an item learned merely because it was found in a chest or received from another player.

The source is supplied for review/building. It has **not** been compiled in this environment because no Gradle distribution or dependency network is available here. Do not treat it as a tested JAR. The included GitHub Actions workflow can compile it after the project is pushed to a repository. The map template is included as a vanilla structure NBT resource. Its generator is reproducible with `python tools/build_map.py`; a schematic top-down preview is stored in `preview/`.

## Build locally

1. Install a JDK 17 distribution.
2. Install Gradle 8.8 (ForgeGradle 6.x build).
3. From this folder run:
   - Windows: `gradle build`
   - macOS/Linux: `gradle build`
4. The JAR will be created in `build/libs/`.

Alternatively, push the folder to GitHub. The included workflow builds the project and uploads `desert-diner-core-0.2.0.jar` as an Actions artifact.

## Install

Copy the built JAR into the Prism instance's `mods/` folder. Install the same JAR on every client and on the server if you later host a dedicated server.

## Current prototype limits

- The menu/catalog UI is the first functional foundation, not the final polished interface.
- Create a new world for the stage-2 map. A save that already contains Desert Diner SavedData from an earlier version is deliberately left unchanged to protect an existing test world.
- Hands-On Delight station-specific recipe-learning integration is pending a playtest with its exact Forge file.
- NPCs, queueing, robberies, shop delivery, debt, day/night and the full gameplay loop are planned for later milestones.
- The kiosk key/state is stored and synced, but the full in-world HUD indicator is a later UI pass.
