package com.laststop.desertdiner.client;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;

public class DishInfoScreen extends Screen {
    private final Recipe<?> recipe;
    private final Screen parent;

    public DishInfoScreen(Recipe<?> recipe, Screen parent) {
        super(Component.literal("Dish Information"));
        this.recipe = recipe;
        this.parent = parent;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        int left = width/2 - 150, top = height/2 - 112;
        g.fill(left, top, left+300, top+224, 0xF016191B);
        g.fill(left, top, left+300, top+2, 0xFFC08A4C);
        ItemStack result = recipe.getResultItem(minecraft.level.registryAccess());
        g.renderItem(result, left+18, top+16);
        g.drawString(font, result.getHoverName(), left+48, top+24, 0xFFE8D4B0, false);
        g.drawString(font, "РЕЦЕПТ / ИНГРЕДИЕНТЫ", left+18, top+54, 0xFFC9A879, false);
        List<Ingredient> ingredients = recipe.getIngredients();
        int shown = 0;
        for (Ingredient ingredient : ingredients) {
            if (ingredient.isEmpty()) continue;
            ItemStack[] options = ingredient.getItems();
            if (options.length == 0) continue;
            int col = shown % 5, row = shown / 5;
            int x = left + 20 + col*52, y = top + 82 + row*48;
            g.fill(x, y, x+42, y+42, 0xFF26292A);
            g.renderItem(options[0], x+12, y+7);
            g.drawCenteredString(font, options[0].getHoverName().getString(), x+21, y+32, 0xFFAAA79E);
            shown++;
            if (shown >= 15) break;
        }
        if (shown == 0) g.drawString(font, "Для этого рецепта нет обычного списка ингредиентов.", left+18, top+90, 0xFF9B9A91, false);
        g.drawString(font, "ESC — назад", left+18, top+202, 0xFF777A76, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }
    @Override
    public boolean isPauseScreen() { return false; }
}
