package com.laststop.desertdiner.client;

import com.laststop.desertdiner.DesertDiner;
import com.laststop.desertdiner.network.NetworkHandler;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.settings.KeyConflictContext;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = DesertDiner.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
class ClientKeyRegistration {
    static final KeyMapping OPEN_MENU = new KeyMapping(
            "key.desertdiner.menu", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, "key.categories.desertdiner");
    static final KeyMapping TOGGLE_KIOSK = new KeyMapping(
            "key.desertdiner.kiosk", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.desertdiner");

    @SubscribeEvent
    static void register(RegisterKeyMappingsEvent event) {
        event.register(OPEN_MENU);
        event.register(TOGGLE_KIOSK);
    }
}

@Mod.EventBusSubscriber(modid = DesertDiner.MODID, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        if (ClientKeyRegistration.OPEN_MENU.consumeClick()) {
            NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RequestSyncPacket());
            mc.setScreen(new MenuScreen());
        }
        if (ClientKeyRegistration.TOGGLE_KIOSK.consumeClick()) {
            NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.ToggleKioskPacket());
            mc.player.displayClientMessage(Component.literal("Запрос изменения статуса киоска отправлен"), true);
        }
    }
}
