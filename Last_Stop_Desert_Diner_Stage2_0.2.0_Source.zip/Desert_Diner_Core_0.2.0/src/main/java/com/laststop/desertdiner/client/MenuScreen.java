package com.laststop.desertdiner.client;

import com.laststop.desertdiner.network.NetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class MenuScreen extends Screen {
    private static final int SLOT = 44;
    private static final int GAP = 7;
    private int left, top, panelWidth, panelHeight, addIndex;

    public MenuScreen() {
        super(Component.literal("Desert Diner Menu"));
    }

    @Override
    protected void init() {
        addIndex = ClientMenuCache.addButtonIndex();
        int rows = Math.max(3, addIndex / 3 + 1);
        panelWidth = 270;
        panelHeight = 74 + rows * (SLOT + GAP);
        left = (width - panelWidth) / 2;
        top = Math.max(12, (height - panelHeight) / 2);
        NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RequestSyncPacket());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.fill(left, top, left + panelWidth, top + panelHeight, 0xF016191B);
        g.fill(left, top, left + panelWidth, top + 2, 0xFFC08A4C);
        g.drawString(font, "DESERT DINER", left + 14, top + 12, 0xFFE8D4B0, false);
        g.drawString(font, "КУЛИНАРНОЕ МЕНЮ", left + 14, top + 27, 0xFF9B9A91, false);
        String kiosk = ClientMenuCache.kioskOpen ? "КИОСК: ОТКРЫТ" : "КИОСК: ЗАКРЫТ";
        g.drawString(font, kiosk, left + panelWidth - font.width(kiosk) - 14, top + 18,
                ClientMenuCache.kioskOpen ? 0xFF8FC28A : 0xFFD18A78, false);

        int startX = left + (panelWidth - (3 * SLOT + 2 * GAP)) / 2;
        int startY = top + 52;
        for (int index = 0; index <= addIndex; index++) {
            int col = index % 3;
            int row = index / 3;
            int x = startX + col * (SLOT + GAP);
            int y = startY + row * (SLOT + GAP);
            boolean hovered = mouseX >= x && mouseX < x + SLOT && mouseY >= y && mouseY < y + SLOT;
            int bg = hovered ? 0xFF3A3832 : 0xFF26292A;
            g.fill(x, y, x + SLOT, y + SLOT, bg);
            g.fill(x, y, x + SLOT, y + 1, hovered ? 0xFFE3B66C : 0xFF56534B);
            g.fill(x, y + SLOT - 1, x + SLOT, y + SLOT, 0xFF101213);

            if (index == addIndex) {
                g.drawCenteredString(font, "+", x + SLOT/2, y + 9, 0xFFE6BB78);
                g.drawCenteredString(font, "ДОБАВИТЬ", x + SLOT/2, y + 27, 0xFFBDB6A7);
            } else {
                String id = ClientMenuCache.slots.get(index);
                if (id == null) {
                    g.drawCenteredString(font, "+", x + SLOT/2, y + 10, 0xFF686A65);
                    g.drawCenteredString(font, "ПУСТО", x + SLOT/2, y + 28, 0xFF77776F);
                } else {
                    Item item = BuiltInRegistries.ITEM.get(ResourceLocation.tryParse(id));
                    ItemStack stack = new ItemStack(item);
                    g.renderItem(stack, x + 13, y + 5);
                    String price = ClientMenuCache.price(id) + "C";
                    g.drawCenteredString(font, price, x + SLOT/2, y + 30, 0xFFE8C27F);
                }
            }
        }
        g.drawString(font, "M — меню    K — открыть/закрыть киоск", left + 14,
                top + panelHeight - 15, 0xFF777A76, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int startX = left + (panelWidth - (3 * SLOT + 2 * GAP)) / 2;
        int startY = top + 52;
        for (int index = 0; index <= addIndex; index++) {
            int x = startX + (index % 3) * (SLOT + GAP);
            int y = startY + (index / 3) * (SLOT + GAP);
            if (mouseX >= x && mouseX < x + SLOT && mouseY >= y && mouseY < y + SLOT) {
                if (index == addIndex || !ClientMenuCache.slots.containsKey(index)) {
                    minecraft.setScreen(new CatalogScreen(index, this));
                } else {
                    minecraft.setScreen(new DishEditScreen(index, ClientMenuCache.slots.get(index), this));
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
