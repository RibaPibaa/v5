package com.laststop.desertdiner.data;

import com.laststop.desertdiner.network.NetworkHandler;
import com.laststop.desertdiner.network.SyncMenuPacket;
import java.util.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

public class DinerSavedData extends SavedData {
    private final Set<String> learned = new LinkedHashSet<>();
    private final Map<Integer, String> menuSlots = new TreeMap<>();
    private final Map<String, Integer> prices = new HashMap<>();
    private boolean kioskOpen = true;
    private boolean mapGenerated = false;
    private boolean loadedFromDisk = false;

    public static DinerSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage()
                .computeIfAbsent(DinerSavedData::load, DinerSavedData::new, "desert_diner");
    }

    public static DinerSavedData load(CompoundTag tag) {
        DinerSavedData data = new DinerSavedData();
        data.loadedFromDisk = true;
        ListTag learnedTag = tag.getList("learned", 8);
        for (int i = 0; i < learnedTag.size(); i++) data.learned.add(learnedTag.getString(i));

        CompoundTag slots = tag.getCompound("menu");
        for (String key : slots.getAllKeys()) {
            try {
                data.menuSlots.put(Integer.parseInt(key), slots.getString(key));
            } catch (NumberFormatException ignored) {}
        }

        CompoundTag priceTag = tag.getCompound("prices");
        for (String key : priceTag.getAllKeys()) data.prices.put(key, priceTag.getInt(key));
        data.kioskOpen = !tag.contains("kiosk_open") || tag.getBoolean("kiosk_open");
        data.mapGenerated = tag.getBoolean("map_generated");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag learnedTag = new ListTag();
        for (String id : learned) learnedTag.add(StringTag.valueOf(id));
        tag.put("learned", learnedTag);

        CompoundTag slots = new CompoundTag();
        menuSlots.forEach((index, id) -> slots.putString(String.valueOf(index), id));
        tag.put("menu", slots);

        CompoundTag priceTag = new CompoundTag();
        prices.forEach(priceTag::putInt);
        tag.put("prices", priceTag);
        tag.putBoolean("kiosk_open", kioskOpen);
        tag.putBoolean("map_generated", mapGenerated);
        return tag;
    }

    public boolean markLearned(String itemId) {
        boolean changed = learned.add(itemId);
        if (changed) setDirty();
        return changed;
    }

    public boolean isLearned(String itemId) { return learned.contains(itemId); }
    public Set<String> learnedCopy() { return new LinkedHashSet<>(learned); }
    public Map<Integer, String> menuCopy() { return new TreeMap<>(menuSlots); }
    public Map<String, Integer> pricesCopy() { return new HashMap<>(prices); }
    public boolean isKioskOpen() { return kioskOpen; }
    public boolean isMapGenerated() { return mapGenerated; }
    public boolean isLegacyWorldWithoutMap() { return loadedFromDisk && !mapGenerated; }

    public void setMapGenerated(boolean generated) {
        if (mapGenerated != generated) {
            mapGenerated = generated;
            setDirty();
        }
    }

    public void setMenuSlot(int slot, String itemId) {
        if (slot < 0 || slot > 255 || !learned.contains(itemId)) return;
        menuSlots.put(slot, itemId);
        setDirty();
    }

    public void removeMenuSlot(int slot) {
        if (menuSlots.remove(slot) != null) setDirty();
    }

    public int getPrice(String itemId) { return prices.getOrDefault(itemId, 5); }

    public void setPrice(String itemId, int price) {
        prices.put(itemId, Math.max(1, Math.min(9, price)));
        setDirty();
    }

    public void toggleKiosk() {
        kioskOpen = !kioskOpen;
        setDirty();
    }

    public void sync(ServerPlayer player) {
        NetworkHandler.CHANNEL.send(
                net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
                new SyncMenuPacket(learnedCopy(), menuCopy(), pricesCopy(), kioskOpen)
        );
    }
}
