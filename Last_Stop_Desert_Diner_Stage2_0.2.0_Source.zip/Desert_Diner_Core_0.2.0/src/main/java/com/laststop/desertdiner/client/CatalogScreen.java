package com.laststop.desertdiner.client;

import com.laststop.desertdiner.network.NetworkHandler;
import java.util.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;

public class CatalogScreen extends Screen {
    private final int targetSlot;
    private final Screen parent;
    private final List<Recipe<?>> foods = new ArrayList<>();
    private int scroll = 0;
    private int left, top;

    public CatalogScreen(int targetSlot, Screen parent) {
        super(Component.literal("Food Catalog"));
        this.targetSlot = targetSlot;
        this.parent = parent;
    }

    @Override
    protected void init() {
        left = width / 2 - 190;
        top = height / 2 - 140;
        Map<String, Recipe<?>> unique = new TreeMap<>();
        if (minecraft.level != null) {
            for (Recipe<?> recipe : minecraft.level.getRecipeManager().getRecipes()) {
                ItemStack result = recipe.getResultItem(minecraft.level.registryAccess());
                if (result.isEmpty() || !result.getItem().isEdible()) continue;
                String id = BuiltInRegistries.ITEM.getKey(result.getItem()).toString();
                unique.putIfAbsent(id, recipe);
            }
        }
        foods.addAll(unique.values());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.fill(left, top, left + 380, top + 280, 0xF016191B);
        g.fill(left, top, left + 380, top + 2, 0xFFC08A4C);
        g.drawString(font, "КАТАЛОГ БЛЮД", left + 14, top + 12, 0xFFE8D4B0, false);
        g.drawString(font, "Выбирай только уже освоенные рецепты", left + 14, top + 28, 0xFF9B9A91, false);

        int visible = 7;
        for (int row = 0; row < visible; row++) {
            int index = row + scroll;
            if (index >= foods.size()) break;
            Recipe<?> recipe = foods.get(index);
            ItemStack result = recipe.getResultItem(minecraft.level.registryAccess());
            String id = BuiltInRegistries.ITEM.getKey(result.getItem()).toString();
            boolean learned = ClientMenuCache.learned.contains(id);
            int y = top + 52 + row * 29;
            boolean hovered = mouseX >= left + 10 && mouseX < left + 370 && mouseY >= y && mouseY < y + 25;
            g.fill(left + 10, y, left + 370, y + 25, hovered ? 0xFF34332E : 0xFF222526);
            g.renderItem(result, left + 16, y + 4);
            String name = result.getHoverName().getString();
            g.drawString(font, name, left + 45, y + 8, learned ? 0xFFE1D8C7 : 0xFF85857E, false);
            String state = learned ? "ИЗУЧЕНО" : "НЕ ИЗУЧЕНО";
            g.drawString(font, state, left + 265, y + 8, learned ? 0xFF8FBE88 : 0xFFB47D70, false);
            g.drawCenteredString(font, "i", left + 354, y + 8, 0xFFE0B879);
        }
        g.drawString(font, "Колесо мыши — прокрутка    ESC — назад", left + 14, top + 263, 0xFF777A76, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        for (int row = 0; row < 7; row++) {
            int index = row + scroll;
            if (index >= foods.size()) break;
            int y = top + 52 + row * 29;
            if (mouseX >= left + 10 && mouseX < left + 370 && mouseY >= y && mouseY < y + 25) {
                Recipe<?> recipe = foods.get(index);
                ItemStack result = recipe.getResultItem(minecraft.level.registryAccess());
                String id = BuiltInRegistries.ITEM.getKey(result.getItem()).toString();
                if (mouseX >= left + 330) {
                    minecraft.setScreen(new DishInfoScreen(recipe, this));
                } else if (ClientMenuCache.learned.contains(id)) {
                    NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.AddMenuSlotPacket(targetSlot, id));
                    minecraft.setScreen(new MenuScreen());
                    NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RequestSyncPacket());
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        scroll = Math.max(0, Math.min(Math.max(0, foods.size() - 7), scroll + (delta < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
