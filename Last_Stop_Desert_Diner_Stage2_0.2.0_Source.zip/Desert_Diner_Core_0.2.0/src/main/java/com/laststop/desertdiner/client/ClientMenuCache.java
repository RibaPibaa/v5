package com.laststop.desertdiner.client;

import java.util.*;

public final class ClientMenuCache {
    public static Set<String> learned = new LinkedHashSet<>();
    public static Map<Integer, String> slots = new TreeMap<>();
    public static Map<String, Integer> prices = new HashMap<>();
    public static boolean kioskOpen = true;

    private ClientMenuCache() {}

    public static void apply(Set<String> learnedData, Map<Integer, String> slotData,
                             Map<String, Integer> priceData, boolean open) {
        learned = new LinkedHashSet<>(learnedData);
        slots = new TreeMap<>(slotData);
        prices = new HashMap<>(priceData);
        kioskOpen = open;
    }

    public static int price(String id) { return prices.getOrDefault(id, 5); }

    public static int addButtonIndex() {
        int maxSlot = slots.keySet().stream().mapToInt(Integer::intValue).max().orElse(-1);
        int maxLearned = learned.size() - 1;
        int max = Math.max(maxSlot, maxLearned);
        return Math.max(8, (((max + 1) / 3) + 1) * 3 - 1);
    }
}
