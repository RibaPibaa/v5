package com.laststop.desertdiner.network;

import com.laststop.desertdiner.client.ClientMenuCache;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class SyncMenuPacket {
    private final Set<String> learned;
    private final Map<Integer, String> slots;
    private final Map<String, Integer> prices;
    private final boolean kioskOpen;

    public SyncMenuPacket(Set<String> learned, Map<Integer, String> slots,
                          Map<String, Integer> prices, boolean kioskOpen) {
        this.learned = new LinkedHashSet<>(learned);
        this.slots = new TreeMap<>(slots);
        this.prices = new HashMap<>(prices);
        this.kioskOpen = kioskOpen;
    }

    public static void encode(SyncMenuPacket p, FriendlyByteBuf b) {
        b.writeVarInt(p.learned.size());
        p.learned.forEach(b::writeUtf);
        b.writeVarInt(p.slots.size());
        p.slots.forEach((slot, id) -> { b.writeVarInt(slot); b.writeUtf(id, 256); });
        b.writeVarInt(p.prices.size());
        p.prices.forEach((id, price) -> { b.writeUtf(id, 256); b.writeVarInt(price); });
        b.writeBoolean(p.kioskOpen);
    }

    public static SyncMenuPacket decode(FriendlyByteBuf b) {
        Set<String> learned = new LinkedHashSet<>();
        int learnedCount = b.readVarInt();
        for (int i = 0; i < learnedCount; i++) learned.add(b.readUtf(256));
        Map<Integer, String> slots = new TreeMap<>();
        int slotCount = b.readVarInt();
        for (int i = 0; i < slotCount; i++) slots.put(b.readVarInt(), b.readUtf(256));
        Map<String, Integer> prices = new HashMap<>();
        int priceCount = b.readVarInt();
        for (int i = 0; i < priceCount; i++) prices.put(b.readUtf(256), b.readVarInt());
        return new SyncMenuPacket(learned, slots, prices, b.readBoolean());
    }

    public static void handle(SyncMenuPacket p, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientMenuCache.apply(p.learned, p.slots, p.prices, p.kioskOpen)));
        c.setPacketHandled(true);
    }
}
