package com.laststop.desertdiner.network;

import com.laststop.desertdiner.DesertDiner;
import com.laststop.desertdiner.data.DinerSavedData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.function.Supplier;

public final class NetworkHandler {
    private static int nextId = 0;
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(DesertDiner.MODID, "main"),
            () -> "1", "1"::equals, "1"::equals);

    private NetworkHandler() {}

    public static void register() {
        CHANNEL.registerMessage(nextId++, RequestSyncPacket.class,
                RequestSyncPacket::encode, RequestSyncPacket::decode, RequestSyncPacket::handle);
        CHANNEL.registerMessage(nextId++, AddMenuSlotPacket.class,
                AddMenuSlotPacket::encode, AddMenuSlotPacket::decode, AddMenuSlotPacket::handle);
        CHANNEL.registerMessage(nextId++, RemoveMenuSlotPacket.class,
                RemoveMenuSlotPacket::encode, RemoveMenuSlotPacket::decode, RemoveMenuSlotPacket::handle);
        CHANNEL.registerMessage(nextId++, SetDishPricePacket.class,
                SetDishPricePacket::encode, SetDishPricePacket::decode, SetDishPricePacket::handle);
        CHANNEL.registerMessage(nextId++, ToggleKioskPacket.class,
                ToggleKioskPacket::encode, ToggleKioskPacket::decode, ToggleKioskPacket::handle);
        CHANNEL.registerMessage(nextId++, SyncMenuPacket.class,
                SyncMenuPacket::encode, SyncMenuPacket::decode, SyncMenuPacket::handle);
    }

    static void sync(ServerPlayer player) {
        DinerSavedData.get(player.serverLevel()).sync(player);
    }

    public static class RequestSyncPacket {
        public static void encode(RequestSyncPacket p, net.minecraft.network.FriendlyByteBuf b) {}
        public static RequestSyncPacket decode(net.minecraft.network.FriendlyByteBuf b) { return new RequestSyncPacket(); }
        public static void handle(RequestSyncPacket p, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer player = c.getSender();
                if (player != null) sync(player);
            });
            c.setPacketHandled(true);
        }
    }

    public static class AddMenuSlotPacket {
        final int slot; final String itemId;
        public AddMenuSlotPacket(int slot, String itemId) { this.slot = slot; this.itemId = itemId; }
        public static void encode(AddMenuSlotPacket p, net.minecraft.network.FriendlyByteBuf b) { b.writeVarInt(p.slot); b.writeUtf(p.itemId, 256); }
        public static AddMenuSlotPacket decode(net.minecraft.network.FriendlyByteBuf b) { return new AddMenuSlotPacket(b.readVarInt(), b.readUtf(256)); }
        public static void handle(AddMenuSlotPacket p, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer player = c.getSender();
                if (player == null) return;
                DinerSavedData data = DinerSavedData.get(player.serverLevel());
                var id = ResourceLocation.tryParse(p.itemId);
                Item item = id == null ? null : ForgeRegistries.ITEMS.getValue(id);
                if (item != null && item != net.minecraft.world.item.Items.AIR && item.isEdible() && data.isLearned(p.itemId)) {
                    data.setMenuSlot(p.slot, p.itemId);
                    player.getServer().getPlayerList().getPlayers().forEach(data::sync);
                }
            });
            c.setPacketHandled(true);
        }
    }

    public static class RemoveMenuSlotPacket {
        final int slot;
        public RemoveMenuSlotPacket(int slot) { this.slot = slot; }
        public static void encode(RemoveMenuSlotPacket p, net.minecraft.network.FriendlyByteBuf b) { b.writeVarInt(p.slot); }
        public static RemoveMenuSlotPacket decode(net.minecraft.network.FriendlyByteBuf b) { return new RemoveMenuSlotPacket(b.readVarInt()); }
        public static void handle(RemoveMenuSlotPacket p, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer player = c.getSender();
                if (player == null) return;
                DinerSavedData data = DinerSavedData.get(player.serverLevel());
                data.removeMenuSlot(p.slot);
                player.getServer().getPlayerList().getPlayers().forEach(data::sync);
            });
            c.setPacketHandled(true);
        }
    }

    public static class SetDishPricePacket {
        final String itemId; final int price;
        public SetDishPricePacket(String itemId, int price) { this.itemId = itemId; this.price = price; }
        public static void encode(SetDishPricePacket p, net.minecraft.network.FriendlyByteBuf b) { b.writeUtf(p.itemId, 256); b.writeVarInt(p.price); }
        public static SetDishPricePacket decode(net.minecraft.network.FriendlyByteBuf b) { return new SetDishPricePacket(b.readUtf(256), b.readVarInt()); }
        public static void handle(SetDishPricePacket p, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer player = c.getSender();
                if (player == null) return;
                DinerSavedData data = DinerSavedData.get(player.serverLevel());
                data.setPrice(p.itemId, p.price);
                player.getServer().getPlayerList().getPlayers().forEach(data::sync);
            });
            c.setPacketHandled(true);
        }
    }

    public static class ToggleKioskPacket {
        public static void encode(ToggleKioskPacket p, net.minecraft.network.FriendlyByteBuf b) {}
        public static ToggleKioskPacket decode(net.minecraft.network.FriendlyByteBuf b) { return new ToggleKioskPacket(); }
        public static void handle(ToggleKioskPacket p, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayer player = c.getSender();
                if (player == null) return;
                DinerSavedData data = DinerSavedData.get(player.serverLevel());
                data.toggleKiosk();
                player.getServer().getPlayerList().getPlayers().forEach(data::sync);
            });
            c.setPacketHandled(true);
        }
    }
}
