package com.laststop.desertdiner.item;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class CurrencyItem extends Item {
    private final int value;

    public CurrencyItem(int value) {
        super(new Item.Properties().stacksTo(64));
        this.value = value;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal(value + "C").withStyle(ChatFormatting.GOLD));
    }

    public int getValue() {
        return value;
    }
}
