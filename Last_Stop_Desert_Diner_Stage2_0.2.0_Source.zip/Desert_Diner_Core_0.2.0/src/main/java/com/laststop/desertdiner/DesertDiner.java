package com.laststop.desertdiner;

import com.laststop.desertdiner.data.DinerSavedData;
import com.laststop.desertdiner.network.NetworkHandler;
import com.laststop.desertdiner.registry.ModItems;
import com.laststop.desertdiner.world.WorldMapInstaller;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

@Mod(DesertDiner.MODID)
public class DesertDiner {
    public static final String MODID = "desertdiner";

    public DesertDiner() {
        var modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        modBus.addListener(ModItems::addCreative);
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void markFoodLearned(ServerPlayer player, ItemStack result) {
        if (result.isEmpty() || !result.getItem().isEdible()) return;
        String itemId = net.minecraft.core.registries.BuiltInRegistries.ITEM
                .getKey(result.getItem()).toString();
        DinerSavedData data = DinerSavedData.get(player.serverLevel());
        if (data.markLearned(itemId)) {
            player.getServer().getPlayerList().getPlayers().forEach(data::sync);
        }
    }

    @SubscribeEvent
    public void onServerStarted(ServerStartedEvent event) {
        WorldMapInstaller.install(event.getServer());
    }

    @SubscribeEvent
    public void onCrafted(PlayerEvent.ItemCraftedEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            markFoodLearned(player, event.getCrafting());
        }
    }

    @SubscribeEvent
    public void onSmelted(PlayerEvent.ItemSmeltedEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            markFoodLearned(player, event.getSmelting());
        }
    }
}
