package com.laststop.desertdiner.world;

import com.laststop.desertdiner.DesertDiner;
import com.laststop.desertdiner.data.DinerSavedData;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import org.slf4j.Logger;

import java.util.Optional;

/** Installs the same authored roadside site once per world save. */
public final class WorldMapInstaller {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int TEMPLATE_HALF_SIZE = 330;
    private static final int FLAT_RADIUS = 100;
    private static final int BLEND_RADIUS = 125;
    private static final int CLEAR_HEADROOM = 22;

    private WorldMapInstaller() {}

    public static void install(MinecraftServer server) {
        ServerLevel level = server.overworld();
        DinerSavedData data = DinerSavedData.get(level);
        if (data.isMapGenerated()) {
            return;
        }
        if (data.isLegacyWorldWithoutMap()) {
            LOGGER.warn("This save already contains Desert Diner data from an earlier version. To avoid overwriting an existing test world, the fixed map will only auto-install in a new world.");
            return;
        }

        ResourceLocation structureId = new ResourceLocation(DesertDiner.MODID, "desert_diner_site");
        StructureTemplateManager manager = server.getStructureManager();
        Optional<StructureTemplate> optionalTemplate = manager.get(structureId);
        if (optionalTemplate.isEmpty()) {
            LOGGER.error("Desert Diner map template {} was not found; leaving this world unchanged.", structureId);
            return;
        }

        BlockPos oldSpawn = level.getSharedSpawnPos();
        BlockPos center = findDesertCenter(level, oldSpawn);
        int centerX = center.getX();
        int centerZ = center.getZ();
        int baseY = level.getHeight(Heightmap.Types.WORLD_SURFACE, centerX, centerZ) - 1;
        baseY = Math.max(level.getMinBuildHeight() + 8, Math.min(level.getMaxBuildHeight() - 48, baseY));

        LOGGER.info("Installing Last Stop: Desert Diner map near {}, {} at Y={}", centerX, centerZ, baseY);
        try {
            flattenCentralSite(level, centerX, centerZ, baseY);

            BlockPos origin = new BlockPos(centerX - TEMPLATE_HALF_SIZE, baseY, centerZ - TEMPLATE_HALF_SIZE);
            StructurePlaceSettings settings = new StructurePlaceSettings().setIgnoreEntities(true);
            boolean placed = optionalTemplate.get().placeInWorld(level, origin, origin, settings, level.getRandom(), 2);
            if (!placed) {
                LOGGER.error("Desert Diner structure placement returned false; the map will be retried on next start.");
                return;
            }

            // The invisible barrier ring in the structure defines the playable 600 x 600 area.
            // Keep the vanilla red world-border wall far away so it never becomes visible.
            level.getWorldBorder().setCenter(centerX, centerZ);
            level.getWorldBorder().setSize(1_000_000.0D);

            // Spawn a few blocks in front of the diner's service porch.
            level.setDefaultSpawnPos(new BlockPos(centerX - 40, baseY + 1, centerZ + 2), 0.0F);
            data.setMapGenerated(true);
            LOGGER.info("Last Stop: Desert Diner map installed successfully. Fixed spawn set to {}, {}.", centerX - 40, centerZ + 2);
        } catch (Exception exception) {
            LOGGER.error("Failed to install the Desert Diner map. The save was not marked as generated; it can retry on next start.", exception);
        }
    }

    private static BlockPos findDesertCenter(ServerLevel level, BlockPos fallback) {
        Pair<BlockPos, Holder<Biome>> found = level.findClosestBiome3d(
                biome -> biome.is(Biomes.DESERT), fallback, 2048, 32, 64);
        if (found != null) {
            return found.getFirst();
        }
        LOGGER.warn("No desert biome found within search radius; the diner site will be built around the existing world spawn.");
        return fallback;
    }

    /**
     * Flattens an irregular oval for the two buildings and road, then blends its edge
     * into the surrounding desert instead of leaving a square platform.
     */
    private static void flattenCentralSite(ServerLevel level, int centerX, int centerZ, int baseY) {
        BlockState sand = Blocks.SAND.defaultBlockState();
        BlockState sandstone = Blocks.SANDSTONE.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();

        for (int dx = -BLEND_RADIUS; dx <= BLEND_RADIUS; dx++) {
            for (int dz = -BLEND_RADIUS; dz <= BLEND_RADIUS; dz++) {
                double normalized = Math.sqrt(
                        (dx * dx) / (double) (BLEND_RADIUS * BLEND_RADIUS)
                        + (dz * dz) / (double) (BLEND_RADIUS * BLEND_RADIUS));
                if (normalized > 1.0D) {
                    continue;
                }

                int worldX = centerX + dx;
                int worldZ = centerZ + dz;
                int naturalTop = level.getHeight(Heightmap.Types.WORLD_SURFACE, worldX, worldZ) - 1;

                double blend = smoothStep((normalized - (FLAT_RADIUS / (double) BLEND_RADIUS))
                        / (1.0D - (FLAT_RADIUS / (double) BLEND_RADIUS)));
                int targetY = (int) Math.round(baseY + (naturalTop - baseY) * blend);
                targetY = Math.max(baseY - 4, Math.min(baseY + 4, targetY));

                int clearTo = Math.max(naturalTop + 1, targetY + CLEAR_HEADROOM);
                for (int y = targetY + 1; y <= clearTo; y++) {
                    BlockPos pos = new BlockPos(worldX, y, worldZ);
                    if (!level.getBlockState(pos).isAir()) {
                        level.setBlock(pos, air, 2);
                    }
                }

                int bottomY = Math.min(targetY - 3, naturalTop - 3);
                for (int y = bottomY; y < targetY; y++) {
                    level.setBlock(new BlockPos(worldX, y, worldZ), sandstone, 2);
                }
                level.setBlock(new BlockPos(worldX, targetY, worldZ), sand, 2);
            }
        }
    }

    private static double smoothStep(double value) {
        double t = Math.max(0.0D, Math.min(1.0D, value));
        return t * t * (3.0D - 2.0D * t);
    }
}
