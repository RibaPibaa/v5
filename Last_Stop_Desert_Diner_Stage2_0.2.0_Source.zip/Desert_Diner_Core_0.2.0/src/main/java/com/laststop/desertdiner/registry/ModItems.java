package com.laststop.desertdiner.registry;

import com.laststop.desertdiner.DesertDiner;
import com.laststop.desertdiner.item.CurrencyItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DesertDiner.MODID);

    public static final RegistryObject<Item> C_COIN =
            ITEMS.register("c_coin", () -> new CurrencyItem(1));
    public static final RegistryObject<Item> C_BAR =
            ITEMS.register("c_bar", () -> new CurrencyItem(10));

    private ModItems() {}

    public static void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(C_COIN.get());
            event.accept(C_BAR.get());
        }
    }
}
