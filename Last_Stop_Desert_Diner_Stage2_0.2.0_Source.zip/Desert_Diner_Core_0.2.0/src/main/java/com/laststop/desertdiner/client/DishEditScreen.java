package com.laststop.desertdiner.client;

import com.laststop.desertdiner.network.NetworkHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;

public class DishEditScreen extends Screen {
    private final int slot;
    private final String itemId;
    private final Screen parent;
    private int price;
    private int left, top;

    public DishEditScreen(int slot, String itemId, Screen parent) {
        super(Component.literal("Edit Dish"));
        this.slot = slot;
        this.itemId = itemId;
        this.parent = parent;
        this.price = ClientMenuCache.price(itemId);
    }

    @Override
    protected void init() {
        left = width/2 - 145;
        top = height/2 - 90;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.fill(left, top, left+290, top+180, 0xF016191B);
        g.fill(left, top, left+290, top+2, 0xFFC08A4C);
        var item = BuiltInRegistries.ITEM.get(ResourceLocation.tryParse(itemId));
        ItemStack stack = new ItemStack(item);
        g.renderItem(stack, left+22, top+22);
        g.drawString(font, stack.getHoverName(), left+58, top+31, 0xFFE8D4B0, false);
        g.drawString(font, "ЦЕНА БЛЮДА", left+22, top+78, 0xFFC9A879, false);
        g.drawCenteredString(font, price + "C", left+145, top+102, 0xFFFFD58C);
        drawButton(g, left+75, top+94, "-", mouseX, mouseY);
        drawButton(g, left+190, top+94, "+", mouseX, mouseY);
        drawButton(g, left+20, top+137, "ЗАМЕНИТЬ", mouseX, mouseY);
        drawButton(g, left+155, top+137, "УДАЛИТЬ", mouseX, mouseY);
        g.drawString(font, "Диапазон прототипа: 1–9C", left+22, top+119, 0xFF85857E, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawButton(GuiGraphics g, int x, int y, String text, int mx, int my) {
        boolean h = mx >= x && mx < x+112 && my >= y && my < y+25;
        g.fill(x, y, x+112, y+25, h ? 0xFF514536 : 0xFF302F2A);
        g.drawCenteredString(font, text, x+56, y+8, 0xFFE6D5B8);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (inside(mx,my,left+75,top+94,112,25) && price > 1) {
            price--; sendPrice(); return true;
        }
        if (inside(mx,my,left+190,top+94,112,25) && price < 9) {
            price++; sendPrice(); return true;
        }
        if (inside(mx,my,left+20,top+137,112,25)) {
            minecraft.setScreen(new CatalogScreen(slot, parent)); return true;
        }
        if (inside(mx,my,left+155,top+137,112,25)) {
            NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.RemoveMenuSlotPacket(slot));
            minecraft.setScreen(new MenuScreen()); return true;
        }
        return super.mouseClicked(mx,my,button);
    }

    private void sendPrice() {
        NetworkHandler.CHANNEL.sendToServer(new NetworkHandler.SetDishPricePacket(itemId, price));
    }
    private boolean inside(double mx,double my,int x,int y,int w,int h) {
        return mx>=x && mx<x+w && my>=y && my<y+h;
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
