package com.ribapibaa.tacticalarena.game;

import com.mojang.logging.LogUtils;
import com.ribapibaa.tacticalarena.world.ArenaLoot;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.fml.ModList;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Discovers usable equipment and combat items from the mods actually loaded by the player/server. */
public final class ArenaItemCatalog {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Set<String> NON_CONTENT_NAMESPACES = Set.of(
            "minecraft", "forge", "tacticalarena", "cloth_config", "creativecore", "curios",
            "geckolib", "playeranimator", "embeddium", "oculus", "parcool", "parcoolplus",
            "parcool_compat", "fieldframe", "architectury", "cloth_config_api"
    );
    private static final List<String> FALLBACK_GUN_IDS = List.of(
            "tacz:ak47", "tacz:glock_17", "tacz:m1911", "tacz:taurus943", "tacz:m700", "tacz:m870"
    );
    private static List<Item> cachedGeneralItems;
    private static List<Item> cachedArmorItems;
    private static List<Item> cachedCurioItems;
    private static List<GunSpec> cachedTaczGuns;
    private static boolean summaryLogged;

    private ArenaItemCatalog() {}

    public static boolean hasTacz() {
        return ModList.get().isLoaded("tacz")
                && BuiltInRegistries.ITEM.getOptional(id("tacz:modern_kinetic_gun")).isPresent();
    }

    public static boolean isGunStack(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !hasTacz()) return false;
        Item gunItem = BuiltInRegistries.ITEM.getOptional(id("tacz:modern_kinetic_gun")).orElse(null);
        return gunItem != null && stack.getItem() == gunItem;
    }

    public static String preferredArmorNamespace() {
        List<Item> candidates = getArmorItems(EquipmentSlot.CHEST);
        return candidates.stream()
                .max(Comparator.comparingInt(ArenaItemCatalog::armorScore))
                .map(item -> BuiltInRegistries.ITEM.getKey(item).getNamespace())
                .orElse("");
    }

    public static String preferredRoleplayNamespace() {
        List<Item> candidates = new ArrayList<>();
        for (Item item : getArmorItems(EquipmentSlot.CHEST)) {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            if (key == null) continue;
            String namespace = key.getNamespace().toLowerCase(Locale.ROOT);
            String path = key.getPath().toLowerCase(Locale.ROOT);
            if (namespace.contains("faz") || namespace.contains("janusz") || namespace.contains("roleplay")
                    || path.contains("business_suit") || path.contains("formal_suit")) {
                candidates.add(item);
            }
        }
        return candidates.stream().max(Comparator.comparingInt(ArenaItemCatalog::armorScore))
                .map(item -> BuiltInRegistries.ITEM.getKey(item).getNamespace()).orElse("");
    }

    public static ItemStack chooseArmor(EquipmentSlot slot, String preferredNamespace) {
        List<Item> candidates = getArmorItems(slot);
        if (!preferredNamespace.isBlank()) {
            List<Item> sameSet = candidates.stream()
                    .filter(item -> BuiltInRegistries.ITEM.getKey(item).getNamespace().equals(preferredNamespace))
                    .toList();
            if (!sameSet.isEmpty()) candidates = new ArrayList<>(sameSet);
        }
        if (candidates.isEmpty()) return ItemStack.EMPTY;
        candidates.sort(Comparator.comparingInt(ArenaItemCatalog::armorScore).reversed());
        int best = armorScore(candidates.get(0));
        List<Item> top = candidates.stream().filter(item -> armorScore(item) >= best - 12).toList();
        Item selected = top.get((int) (Math.random() * top.size()));
        return new ItemStack(selected);
    }

    private static List<Item> getArmorItems(EquipmentSlot slot) {
        List<Item> result = new ArrayList<>();
        for (Item item : allArmorItems()) {
            if (item instanceof ArmorItem armor && armor.getSlot() == slot) result.add(item);
        }
        return result;
    }

    private static List<Item> allArmorItems() {
        if (cachedArmorItems != null) return cachedArmorItems;
        List<Item> result = new ArrayList<>();
        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            if (key == null || !isContentNamespace(key.getNamespace())) continue;
            if (item instanceof ArmorItem) result.add(item);
        }
        cachedArmorItems = List.copyOf(result);
        return cachedArmorItems;
    }

    private static int armorScore(Item item) {
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
        if (key == null) return 0;
        String namespace = key.getNamespace().toLowerCase(Locale.ROOT);
        String path = key.getPath().toLowerCase(Locale.ROOT);
        String full = namespace + ":" + path;
        int score = 20;
        if (namespace.contains("jag") || full.contains("jagtacz")) score += 100;
        if (namespace.contains("tactical") || namespace.contains("lrtactical")) score += 45;
        if (namespace.contains("faz") || namespace.contains("janusz")) score += 35;
        if (path.contains("black")) score += 45;
        if (path.contains("military") || path.contains("tactical") || path.contains("combat")) score += 35;
        if (path.contains("vest") || path.contains("plate") || path.contains("carrier") || path.contains("kevlar")) score += 32;
        if (path.contains("jacket") || path.contains("uniform") || path.contains("bdu")) score += 26;
        if (path.contains("helmet") || path.contains("balaclava") || path.contains("mask")) score += 20;
        return score;
    }

    public static boolean equipFaceMask(ServerPlayer player) {
        for (Item item : getCurioItems("mask", "balaclava", "respirator", "gas_mask", "face_cover")) {
            if (tryEquipCurio(player, new ItemStack(item), List.of("face", "head", "mask"))) return true;
        }
        return false;
    }

    public static boolean equipCurioVest(ServerPlayer player) {
        for (Item item : getCurioItems("vest", "plate_carrier", "chest_rig", "body_armor", "kevlar")) {
            if (tryEquipCurio(player, new ItemStack(item), List.of("vest", "body", "chest", "belt"))) return true;
        }
        return false;
    }

    public static boolean equipCurioJacket(ServerPlayer player) {
        for (Item item : getCurioItems("black_jacket", "military_jacket", "tactical_jacket", "combat_jacket", "uniform", "jacket")) {
            if (tryEquipCurio(player, new ItemStack(item), List.of("body", "chest"))) return true;
        }
        return false;
    }

    public static boolean equipRoleplayClothing(ServerPlayer player) {
        boolean equipped = false;
        for (Item item : getCurioItems("business_suit", "formal_suit", "formal_jacket", "suit_jacket", "jacket", "shirt", "business")) {
            if (tryEquipCurio(player, new ItemStack(item), List.of("body", "chest", "vest"))) {
                equipped = true;
                break;
            }
        }
        for (Item item : getCurioItems("formal_pants", "trousers", "suit_pants", "business_pants")) {
            if (tryEquipCurio(player, new ItemStack(item), List.of("legs", "body"))) {
                equipped = true;
                break;
            }
        }
        return equipped;
    }

    private static List<Item> getCurioItems(String... keywords) {
        List<Item> result = new ArrayList<>();
        for (Item item : allCurioItems()) {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            if (key == null) continue;
            String path = key.getPath().toLowerCase(Locale.ROOT);
            for (String keyword : keywords) {
                if (path.contains(keyword)) {
                    result.add(item);
                    break;
                }
            }
        }
        result.sort(Comparator.comparingInt(ArenaItemCatalog::armorScore).reversed());
        return result;
    }

    private static List<Item> allCurioItems() {
        if (cachedCurioItems != null) return cachedCurioItems;
        List<Item> result = new ArrayList<>();
        if (ModList.get().isLoaded("curios")) {
            for (Item item : BuiltInRegistries.ITEM) {
                ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
                if (key == null || !isContentNamespace(key.getNamespace())) continue;
                if (isCurioItem(item)) result.add(item);
            }
        }
        cachedCurioItems = List.copyOf(result);
        return cachedCurioItems;
    }

    private static boolean implementsCurioInterface(Class<?> type) {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            for (Class<?> iface : current.getInterfaces()) {
                if (iface.getName().equals("top.theillusivec4.curios.api.type.capability.ICurioItem")) return true;
                if (implementsCurioInterface(iface)) return true;
            }
        }
        return false;
    }

    private static boolean isCurioItem(Item item) {
        if (implementsCurioInterface(item.getClass())) return true;
        try {
            Class<?> api = Class.forName("top.theillusivec4.curios.api.CuriosApi");
            Object result = api.getMethod("getCurio", ItemStack.class).invoke(null, new ItemStack(item));
            if (result instanceof Optional<?> optional) return optional.isPresent();
            if (result != null) return (boolean) result.getClass().getMethod("isPresent").invoke(result);
            return false;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    public static void clearArenaCurios(ServerPlayer player) {
        if (!ModList.get().isLoaded("curios")) return;
        try {
            Class<?> api = Class.forName("top.theillusivec4.curios.api.CuriosApi");
            Object optionalObject = api.getMethod("getCuriosInventory", LivingEntity.class).invoke(null, player);
            Object handler;
            if (optionalObject instanceof Optional<?> optional) {
                if (optional.isEmpty()) return;
                handler = optional.get();
            } else {
                if (!(boolean) optionalObject.getClass().getMethod("isPresent").invoke(optionalObject)) return;
                Object resolved = optionalObject.getClass().getMethod("resolve").invoke(optionalObject);
                handler = resolved instanceof Optional<?> resolvedOptional ? resolvedOptional.orElse(null) : resolved;
                if (handler == null) handler = optionalObject.getClass().getMethod("get").invoke(optionalObject);
            }
            Map<?, ?> slots = (Map<?, ?>) handler.getClass().getMethod("getCurios").invoke(handler);
            for (String slot : List.of("face", "mask", "head", "vest", "body", "chest", "belt", "legs")) {
                Object stacksHandler = slots.get(slot);
                if (stacksHandler == null) continue;
                Object dynamicStacks = stacksHandler.getClass().getMethod("getStacks").invoke(stacksHandler);
                int slotCount = (int) dynamicStacks.getClass().getMethod("getSlots").invoke(dynamicStacks);
                Method setStack = dynamicStacks.getClass().getMethod("setStackInSlot", int.class, ItemStack.class);
                for (int index = 0; index < slotCount; index++) setStack.invoke(dynamicStacks, index, ItemStack.EMPTY);
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.debug("Could not clear Tactical Arena Curios slots for {}", player.getGameProfile().getName(), exception);
        }
    }

    private static boolean tryEquipCurio(ServerPlayer player, ItemStack stack, List<String> preferredSlots) {
        try {
            Class<?> api = Class.forName("top.theillusivec4.curios.api.CuriosApi");
            Method getInventory = api.getMethod("getCuriosInventory", LivingEntity.class);
            Object optionalObject = getInventory.invoke(null, player);
            Object handler;
            if (optionalObject instanceof Optional<?> optional) {
                if (optional.isEmpty()) return false;
                handler = optional.get();
            } else {
                Method isPresent = optionalObject.getClass().getMethod("isPresent");
                if (!(boolean) isPresent.invoke(optionalObject)) return false;
                Object resolved = optionalObject.getClass().getMethod("resolve").invoke(optionalObject);
                if (resolved instanceof Optional<?> resolvedOptional) handler = resolvedOptional.orElse(null);
                else handler = resolved;
                if (handler == null) handler = optionalObject.getClass().getMethod("get").invoke(optionalObject);
                if (handler == null) return false;
            }
            Map<?, ?> slots = (Map<?, ?>) handler.getClass().getMethod("getCurios").invoke(handler);
            for (String slot : preferredSlots) {
                Object stacksHandler = slots.get(slot);
                if (stacksHandler == null) continue;
                Object dynamicStacks = stacksHandler.getClass().getMethod("getStacks").invoke(stacksHandler);
                int slotCount = (int) dynamicStacks.getClass().getMethod("getSlots").invoke(dynamicStacks);
                if (slotCount <= 0) continue;
                Method setStack = dynamicStacks.getClass().getMethod("setStackInSlot", int.class, ItemStack.class);
                setStack.invoke(dynamicStacks, 0, stack);
                return true;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.debug("Curios equipment integration is unavailable for {}", stack.getHoverName().getString(), exception);
        }
        return false;
    }

    public static List<ItemStack> createPlayerKit(ArenaMatchManager.Mode mode) {
        List<ItemStack> result = new ArrayList<>();
        List<GunSpec> available = availableGuns(mode);
        if (!available.isEmpty()) {
            if (mode == ArenaMatchManager.Mode.ASSAULT) {
                GunSpec primary = available.get(0);
                addGunAndAmmo(result, primary);
                available.stream().filter(spec -> !spec.primary() && !spec.gunId().equals(primary.gunId()))
                        .findFirst().ifPresent(spec -> addGunAndAmmo(result, spec));
            } else if (mode == ArenaMatchManager.Mode.HITMANIA) {
                GunSpec pistol = available.stream().filter(spec -> !spec.primary()).findFirst().orElse(available.get(0));
                addGunAndAmmo(result, pistol);
            } else {
                GunSpec selected = available.get((int) (Math.random() * available.size()));
                addGunAndAmmo(result, selected);
            }
        }

        addFirstMatching(result, "karambit", "dagger", "combat_knife", "knife", "machete", "baseball_bat");
        if (mode != ArenaMatchManager.Mode.HITMANIA) addFirstMatching(result, "smoke_grenade", "m67_grenade", "rgn_grenade", "flash_grenade", "grenade");
        addFirstMatching(result, "blood_pack", "ibuprofen", "medkit", "first_aid", "bandage", "medical");
        return result;
    }

    private static void addGunAndAmmo(List<ItemStack> output, GunSpec spec) {
        ItemStack gun = createGunStack(spec, 1);
        if (!gun.isEmpty()) output.add(gun);
        ItemStack ammo = createAmmoStack(spec.ammoId(), Math.min(64, spec.magazineSize() * 2));
        if (!ammo.isEmpty()) output.add(ammo);
    }

    private static List<GunSpec> availableGuns(ArenaMatchManager.Mode mode) {
        List<GunSpec> all = discoverTaczGuns();
        List<GunSpec> result = new ArrayList<>();
        if (mode == ArenaMatchManager.Mode.HITMANIA) {
            for (GunSpec spec : all) if (!spec.primary()) result.add(spec);
            if (result.isEmpty()) result.addAll(all);
        } else {
            result.addAll(all);
        }
        result.sort(Comparator.comparing(GunSpec::primary).reversed().thenComparing(GunSpec::gunId));
        return result;
    }

    private static List<GunSpec> discoverTaczGuns() {
        if (cachedTaczGuns != null) return cachedTaczGuns;
        List<GunSpec> result = new ArrayList<>();
        if (!hasTacz()) return result;
        try {
            Class<?> api = Class.forName("com.tacz.guns.api.TimelessAPI");
            Object entriesObject = api.getMethod("getAllCommonGunIndex").invoke(null);
            if (entriesObject instanceof Iterable<?> entries) {
                for (Object object : entries) {
                    if (!(object instanceof Map.Entry<?, ?> entry) || !(entry.getKey() instanceof ResourceLocation gunId)) continue;
                    GunSpec spec = readGunSpec(gunId, entry.getValue());
                    if (spec != null) result.add(spec);
                }
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.debug("Could not enumerate TaCZ common gun registry; trying known default IDs.", exception);
        }
        if (result.isEmpty()) {
            for (String gunId : FALLBACK_GUN_IDS) {
                ResourceLocation key = id(gunId);
                if (key == null) continue;
                try {
                    Class<?> api = Class.forName("com.tacz.guns.api.TimelessAPI");
                    Object optional = api.getMethod("getCommonGunIndex", ResourceLocation.class).invoke(null, key);
                    if (optional instanceof Optional<?> value && value.isPresent()) {
                        GunSpec spec = readGunSpec(key, value.get());
                        if (spec != null) result.add(spec);
                    }
                } catch (ReflectiveOperationException | RuntimeException ignored) {
                }
            }
        }
        if (!result.isEmpty()) cachedTaczGuns = List.copyOf(result);
        return result;
    }

    private static GunSpec readGunSpec(ResourceLocation gunId, Object commonIndex) {
        try {
            Object gunData = commonIndex.getClass().getMethod("getGunData").invoke(commonIndex);
            ResourceLocation ammoId = (ResourceLocation) gunData.getClass().getMethod("getAmmoId").invoke(gunData);
            int magazineSize = (int) gunData.getClass().getMethod("getAmmoAmount").invoke(gunData);
            Object fireModeSet = gunData.getClass().getMethod("getFireModeSet").invoke(gunData);
            String fireMode = null;
            String firstMode = null;
            if (fireModeSet instanceof Iterable<?> modes) {
                for (Object candidate : modes) {
                    if (candidate == null) continue;
                    String name = candidate.toString().toUpperCase(Locale.ROOT);
                    if (firstMode == null) firstMode = name;
                    if (name.equals("AUTO")) {
                        fireMode = "AUTO";
                        break;
                    }
                    if (name.equals("SEMI")) fireMode = "SEMI";
                }
            }
            if (fireMode == null) fireMode = firstMode;
            String type = String.valueOf(commonIndex.getClass().getMethod("getType").invoke(commonIndex)).toLowerCase(Locale.ROOT);
            String path = gunId.getPath().toLowerCase(Locale.ROOT);
            boolean pistol = type.contains("pistol") || type.contains("handgun")
                    || path.contains("pistol") || path.contains("glock") || path.contains("m1911")
                    || path.contains("taurus") || path.contains("revolver");
            if (ammoId == null || magazineSize < 1 || fireMode == null) return null;
            return new GunSpec(gunId.toString(), fireMode, ammoId.toString(), !pistol, magazineSize);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.debug("Could not read TaCZ gun data for {}", gunId, exception);
            return null;
        }
    }

    public static List<ItemStack> getPriorityLoot(ArenaLoot.Table table) {
        List<ItemStack> result = new ArrayList<>();
        for (Item item : allArmorItems()) result.add(new ItemStack(item));
        for (GunSpec spec : availableGunsForTable(table)) {
            ItemStack gun = createGunStack(spec, 1);
            if (!gun.isEmpty()) result.add(gun);
        }
        for (Item item : findKeywordItems("grenade", "smoke", "flash", "karambit", "dagger", "knife", "blood_pack", "ibuprofen", "medkit", "bandage")) {
            result.add(new ItemStack(item));
        }
        return result;
    }

    public static List<ItemStack> getAmmoLoot(ArenaLoot.Table table) {
        List<ItemStack> result = new ArrayList<>();
        for (GunSpec spec : availableGunsForTable(table)) {
            ItemStack ammo = createAmmoStack(spec.ammoId(), 24 + (int) (Math.random() * 25));
            if (!ammo.isEmpty()) result.add(ammo);
        }
        return result;
    }

    public static List<ItemStack> getGeneralModdedLoot() {
        List<ItemStack> result = new ArrayList<>();
        for (Item item : allGeneralItems()) result.add(new ItemStack(item));
        for (GunSpec spec : discoverTaczGuns()) {
            ItemStack gun = createGunStack(spec, 1);
            if (!gun.isEmpty()) result.add(gun);
            ItemStack ammo = createAmmoStack(spec.ammoId(), 12 + (int) (Math.random() * 28));
            if (!ammo.isEmpty()) result.add(ammo);
        }
        return result;
    }

    private static List<GunSpec> availableGunsForTable(ArenaLoot.Table table) {
        List<GunSpec> result = discoverTaczGuns();
        if (table == ArenaLoot.Table.HITMANIA) {
            List<GunSpec> pistols = result.stream().filter(spec -> !spec.primary()).toList();
            if (!pistols.isEmpty()) result = new ArrayList<>(pistols);
        }
        result.sort(Comparator.comparing(GunSpec::primary).reversed().thenComparing(GunSpec::gunId));
        return result;
    }

    private static ItemStack createGunStack(GunSpec spec, int count) {
        if (!hasTacz()) return ItemStack.EMPTY;
        Item gunItem = BuiltInRegistries.ITEM.getOptional(id("tacz:modern_kinetic_gun")).orElse(null);
        if (gunItem == null) return ItemStack.EMPTY;
        ItemStack stack = new ItemStack(gunItem, count);
        try {
            Class<?> gunApi = Class.forName("com.tacz.guns.api.item.IGun");
            if (!gunApi.isInstance(gunItem)) return ItemStack.EMPTY;
            gunApi.getMethod("setGunId", ItemStack.class, ResourceLocation.class)
                    .invoke(gunItem, stack, id(spec.gunId()));
            Class<?> fireModeClass = Class.forName("com.tacz.guns.api.item.gun.FireMode");
            Object fireMode = null;
            Object[] fireModes = fireModeClass.getEnumConstants();
            if (fireModes != null) {
                for (Object candidate : fireModes) {
                    if (candidate != null && candidate.toString().equalsIgnoreCase(spec.fireMode())) {
                        fireMode = candidate;
                        break;
                    }
                }
            }
            if (fireMode == null) return ItemStack.EMPTY;
            gunApi.getMethod("setFireMode", ItemStack.class, fireModeClass).invoke(gunItem, stack, fireMode);
            gunApi.getMethod("setCurrentAmmoCount", ItemStack.class, int.class)
                    .invoke(gunItem, stack, spec.magazineSize());
            gunApi.getMethod("setBulletInBarrel", ItemStack.class, boolean.class)
                    .invoke(gunItem, stack, true);
            return stack;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.warn("Could not initialize TaCZ gun {} through the official IGun API.", spec.gunId(), exception);
            return ItemStack.EMPTY;
        }
    }

    private static ItemStack createAmmoStack(String ammoId, int count) {
        if (!hasTacz() || !isRegisteredAmmo(ammoId)) return ItemStack.EMPTY;
        Item ammoItem = BuiltInRegistries.ITEM.getOptional(id("tacz:ammo")).orElse(null);
        if (ammoItem == null) return ItemStack.EMPTY;
        ItemStack stack = new ItemStack(ammoItem, Math.min(64, Math.max(1, count)));
        try {
            Class<?> ammoApi = Class.forName("com.tacz.guns.api.item.IAmmo");
            if (!ammoApi.isInstance(ammoItem)) return ItemStack.EMPTY;
            ammoApi.getMethod("setAmmoId", ItemStack.class, ResourceLocation.class)
                    .invoke(ammoItem, stack, id(ammoId));
            return stack;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.warn("Could not initialize TaCZ ammo {} through the official IAmmo API.", ammoId, exception);
            return ItemStack.EMPTY;
        }
    }

    private static boolean isRegisteredAmmo(String ammoId) {
        try {
            Class<?> api = Class.forName("com.tacz.guns.api.TimelessAPI");
            Object result = api.getMethod("getCommonAmmoIndex", ResourceLocation.class).invoke(null, id(ammoId));
            return result instanceof Optional<?> optional && optional.isPresent();
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.debug("TaCZ ammo registry lookup failed for {}", ammoId, exception);
            return false;
        }
    }

    private static ResourceLocation id(String value) {
        return ResourceLocation.tryParse(value);
    }

    private static List<Item> allGeneralItems() {
        if (cachedGeneralItems != null) return cachedGeneralItems;
        List<Item> result = new ArrayList<>();
        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            if (key == null || !isContentNamespace(key.getNamespace())) continue;
            if (item instanceof BlockItem || item instanceof SpawnEggItem) continue;
            String path = key.getPath().toLowerCase(Locale.ROOT);
            if (path.contains("debug") || path.contains("creative_tab") || path.contains("spawn_egg")
                    || path.contains("test_item") || path.contains("icon")) continue;
            if (key.getNamespace().equals("tacz")
                    && (path.equals("modern_kinetic_gun") || path.equals("ammo") || path.equals("attachment"))) continue;
            result.add(item);
        }
        cachedGeneralItems = List.copyOf(result);
        return cachedGeneralItems;
    }

    private static boolean isContentNamespace(String namespace) {
        return !NON_CONTENT_NAMESPACES.contains(namespace.toLowerCase(Locale.ROOT));
    }

    private static void addFirstMatching(List<ItemStack> output, String... keywords) {
        List<Item> candidates = findKeywordItems(keywords);
        if (!candidates.isEmpty()) output.add(new ItemStack(candidates.get(0)));
    }

    private static List<Item> findKeywordItems(String... keywords) {
        List<Item> result = new ArrayList<>();
        for (Item item : allGeneralItems()) {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            if (key == null) continue;
            String path = key.getPath().toLowerCase(Locale.ROOT);
            for (String keyword : keywords) {
                if (path.contains(keyword)) {
                    result.add(item);
                    break;
                }
            }
        }
        result.sort(Comparator.comparingInt(ArenaItemCatalog::itemKeywordScore).reversed());
        return result;
    }

    private static int itemKeywordScore(Item item) {
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
        if (key == null) return 0;
        String path = key.getPath().toLowerCase(Locale.ROOT);
        int score = 0;
        if (path.contains("black")) score += 30;
        if (path.contains("tactical") || path.contains("combat") || path.contains("military")) score += 25;
        if (path.contains("grenade") || path.contains("karambit") || path.contains("dagger")) score += 20;
        if (path.contains("medkit") || path.contains("blood") || path.contains("ibuprofen")) score += 18;
        return score;
    }

    public static void logDiscoverySummary() {
        if (summaryLogged) return;
        summaryLogged = true;
        int general = allGeneralItems().size();
        int head = getArmorItems(EquipmentSlot.HEAD).size();
        int chest = getArmorItems(EquipmentSlot.CHEST).size();
        int legs = getArmorItems(EquipmentSlot.LEGS).size();
        int feet = getArmorItems(EquipmentSlot.FEET).size();
        List<GunSpec> guns = discoverTaczGuns();
        int masks = getCurioItems("mask", "balaclava", "respirator", "gas_mask", "face_cover").size();
        int vests = getCurioItems("vest", "plate_carrier", "chest_rig", "body_armor", "kevlar").size();
        LOGGER.info("[Tactical Arena] Mod item discovery: {} usable modded items; armor pieces by slot: head={}, body={}, legs={}, feet={}; Curios masks={}, vests={}; TaCZ guns={}, Curios={}",
                general, head, chest, legs, feet, masks, vests, guns.size(), ModList.get().isLoaded("curios"));
        for (GunSpec gun : guns) {
            LOGGER.info("[Tactical Arena] TaCZ gun: {} | ammo: {} | fire mode: {} | category: {}",
                    gun.gunId(), gun.ammoId(), gun.fireMode(), gun.primary() ? "primary" : "sidearm");
        }
        for (Item item : allArmorItems()) {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            if (key != null && item instanceof ArmorItem armor) {
                LOGGER.info("[Tactical Arena] Wearable registry entry: {} -> {}", key, armor.getSlot().getName());
            }
        }
    }

    private record GunSpec(String gunId, String fireMode, String ammoId, boolean primary, int magazineSize) {}
}
