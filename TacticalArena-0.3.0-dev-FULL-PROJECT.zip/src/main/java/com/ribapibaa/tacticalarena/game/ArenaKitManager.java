package com.ribapibaa.tacticalarena.game;

import com.mojang.logging.LogUtils;
import com.ribapibaa.tacticalarena.config.ArenaConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;

import java.util.List;

public final class ArenaKitManager {
    private static final Logger LOGGER = LogUtils.getLogger();
    private ArenaKitManager() {}

    /** Clears the old inventory, equips real mod armor, and gives the mode's modded weapons before warmup ends. */
    public static void giveKit(ServerPlayer player, ArenaMatchManager.Mode mode) {
        player.getInventory().clearContent();
        clearArenaEquipment(player);

        String preferredNamespace = mode == ArenaMatchManager.Mode.HITMANIA
                ? ArenaItemCatalog.preferredRoleplayNamespace()
                : ArenaItemCatalog.preferredArmorNamespace();
        if (preferredNamespace.isBlank()) preferredNamespace = ArenaItemCatalog.preferredArmorNamespace();

        equipArmor(player, EquipmentSlot.HEAD, preferredNamespace, Items.IRON_HELMET);
        equipArmor(player, EquipmentSlot.CHEST, preferredNamespace, Items.IRON_CHESTPLATE);
        equipArmor(player, EquipmentSlot.LEGS, preferredNamespace, Items.IRON_LEGGINGS);
        equipArmor(player, EquipmentSlot.FEET, preferredNamespace, Items.IRON_BOOTS);

        if (mode == ArenaMatchManager.Mode.HITMANIA) {
            ArenaItemCatalog.equipRoleplayClothing(player);
        } else {
            ArenaItemCatalog.equipCurioVest(player);
            ArenaItemCatalog.equipCurioJacket(player);
        }
        ArenaItemCatalog.equipFaceMask(player);

        boolean primaryWeaponEquipped = false;
        for (ItemStack stack : ArenaItemCatalog.createPlayerKit(mode)) {
            if (stack.isEmpty()) continue;
            if (!primaryWeaponEquipped && ArenaItemCatalog.isGunStack(stack)) {
                player.setItemSlot(EquipmentSlot.MAINHAND, stack.copy());
                primaryWeaponEquipped = true;
            } else {
                player.getInventory().add(stack.copy());
            }
        }

        addConfiguredItems(player, switch (mode) {
            case ASSAULT -> ArenaConfig.ASSAULT_KIT.get();
            case HITMANIA -> ArenaConfig.HITMANIA_KIT.get();
            case BATTLE_ROYALE -> ArenaConfig.BR_STARTER_KIT.get();
        }, mode);

        if (mode == ArenaMatchManager.Mode.HITMANIA) {
            addConfiguredItems(player, ArenaConfig.HITMANIA_CLOTHING.get(), mode);
            addConfiguredItems(player, ArenaConfig.HITMANIA_MEDICAL.get(), mode);
        } else if (mode == ArenaMatchManager.Mode.ASSAULT) {
            addConfiguredItems(player, ArenaConfig.ASSAULT_MEDICAL.get(), mode);
        }

        player.getInventory().setChanged();
        ArenaItemCatalog.logDiscoverySummary();
        LOGGER.info("[Tactical Arena] Equipped {} with {} kit; modded gear is equipped in armor slots before the live phase.",
                player.getGameProfile().getName(), mode);
    }

    public static void clearArenaEquipment(ServerPlayer player) {
        player.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        player.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
        player.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
        player.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
        player.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        ArenaItemCatalog.clearArenaCurios(player);
    }

    private static void equipArmor(ServerPlayer player, EquipmentSlot slot, String preferredNamespace, Item fallback) {
        ItemStack stack = ArenaItemCatalog.chooseArmor(slot, preferredNamespace);
        if (stack.isEmpty()) {
            // Emergency fallback only when no wearable item from the installed content mods is registered for this slot.
            stack = new ItemStack(fallback);
            LOGGER.warn("[Tactical Arena] No modded {} armor was found; using a temporary vanilla fallback.", slot.getName());
        }
        player.setItemSlot(slot, stack);
    }

    private static void addConfiguredItems(ServerPlayer player, List<? extends String> ids, ArenaMatchManager.Mode mode) {
        for (String id : ids) addById(player, id, mode);
    }

    private static void addById(ServerPlayer player, String id, ArenaMatchManager.Mode mode) {
        ResourceLocation key = ResourceLocation.tryParse(id);
        if (key == null) return;
        // Old generated configs contained only vanilla placeholder kits. Do not let those overwrite the modded loadout.
        if (key.getNamespace().equals("minecraft") && ArenaItemCatalog.hasTacz()) return;
        Item item = BuiltInRegistries.ITEM.getOptional(key).orElse(Items.AIR);
        if (item == Items.AIR) return;
        ItemStack stack = new ItemStack(item);
        if (item == Items.COOKED_BEEF) stack.setCount(mode == ArenaMatchManager.Mode.ASSAULT ? 12 : 4);
        if (item == Items.BREAD) stack.setCount(mode == ArenaMatchManager.Mode.BATTLE_ROYALE ? 6 : 4);
        if (item == Items.GOLDEN_APPLE && mode == ArenaMatchManager.Mode.HITMANIA) stack.setCount(2);
        player.getInventory().add(stack);
    }
}
