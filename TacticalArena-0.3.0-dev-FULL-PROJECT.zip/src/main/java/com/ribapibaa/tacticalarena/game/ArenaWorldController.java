package com.ribapibaa.tacticalarena.game;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameRules;

public final class ArenaWorldController {
    private static Boolean previousKeepInventory;
    private static Boolean previousDaylightCycle;
    private static Boolean previousWeatherCycle;
    private static Boolean previousDoFireTick;
    private static Boolean previousMobSpawning;
    private static long previousDayTime;
    private static boolean previousRaining;
    private static boolean previousThundering;
    private static double previousBorderCenterX;
    private static double previousBorderCenterZ;
    private static double previousBorderSize;

    private ArenaWorldController() {}

    public static void prepare(MinecraftServer server, ArenaMatchManager.Mode mode) {
        ServerLevel level = server.overworld();
        if (previousKeepInventory == null) {
            previousKeepInventory = level.getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY);
            previousDaylightCycle = level.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT);
            previousWeatherCycle = level.getGameRules().getBoolean(GameRules.RULE_WEATHER_CYCLE);
            previousDoFireTick = level.getGameRules().getBoolean(GameRules.RULE_DOFIRETICK);
            previousMobSpawning = level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING);
            previousDayTime = level.getDayTime();
            previousRaining = level.isRaining();
            previousThundering = level.isThundering();
            previousBorderCenterX = level.getWorldBorder().getCenterX();
            previousBorderCenterZ = level.getWorldBorder().getCenterZ();
            previousBorderSize = level.getWorldBorder().getSize();
        }
        level.getGameRules().getRule(GameRules.RULE_KEEPINVENTORY)
                .set(mode != ArenaMatchManager.Mode.BATTLE_ROYALE, server);
        if (ArenaConfig.LOCK_WORLD_TIME.get()) {
            level.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(false, server);
            level.setDayTime(mode == ArenaMatchManager.Mode.HITMANIA ? 18000L : 13000L);
        }
        level.getGameRules().getRule(GameRules.RULE_WEATHER_CYCLE).set(false, server);
        level.getGameRules().getRule(GameRules.RULE_DOFIRETICK).set(false, server);
        level.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(false, server);
        if (mode == ArenaMatchManager.Mode.HITMANIA) {
            level.setWeatherParameters(0, 20 * 60 * 60, true, false);
        } else {
            level.setWeatherParameters(20 * 60 * 60, 0, false, false);
        }
        if (mode == ArenaMatchManager.Mode.BATTLE_ROYALE) {
            level.getWorldBorder().setCenter(0.0D, 0.0D);
            level.getWorldBorder().setSize(2200.0D);
            level.getWorldBorder().lerpSizeBetween(2200.0D, 140.0D, ArenaConfig.BR_ZONE_SHRINK_MINUTES.get() * 60L * 20L);
        }
    }

    public static void restore(MinecraftServer server) {
        if (previousKeepInventory == null) return;
        ServerLevel level = server.overworld();
        level.getGameRules().getRule(GameRules.RULE_KEEPINVENTORY).set(previousKeepInventory, server);
        level.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(previousDaylightCycle, server);
        level.getGameRules().getRule(GameRules.RULE_WEATHER_CYCLE).set(previousWeatherCycle, server);
        level.getGameRules().getRule(GameRules.RULE_DOFIRETICK).set(previousDoFireTick, server);
        level.getGameRules().getRule(GameRules.RULE_DOMOBSPAWNING).set(previousMobSpawning, server);
        level.setDayTime(previousDayTime);
        if (previousRaining) level.setWeatherParameters(0, 20 * 60 * 60, true, previousThundering);
        else level.setWeatherParameters(20 * 60 * 60, 0, false, false);
        level.getWorldBorder().setCenter(previousBorderCenterX, previousBorderCenterZ);
        level.getWorldBorder().setSize(previousBorderSize);
        previousKeepInventory = null;
        previousDaylightCycle = null;
        previousWeatherCycle = null;
        previousDoFireTick = null;
        previousMobSpawning = null;
    }
}
