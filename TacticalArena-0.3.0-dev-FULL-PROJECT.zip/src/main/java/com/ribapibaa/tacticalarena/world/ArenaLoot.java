package com.ribapibaa.tacticalarena.world;

import com.mojang.logging.LogUtils;
import com.ribapibaa.tacticalarena.config.ArenaConfig;
import com.ribapibaa.tacticalarena.game.ArenaItemCatalog;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class ArenaLoot {
    public enum Table { ASSAULT, HITMANIA, DOCKYARD, BUNKER }
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<BlockPos, Table> TABLES = new HashMap<>();
    private static final Random RANDOM = new Random();
    private static boolean loggedLootSummary;

    private ArenaLoot() {}

    public static void clearTables() {
        TABLES.clear();
        loggedLootSummary = false;
    }

    public static void setTable(BlockPos pos, Table table) {
        TABLES.put(pos.immutable(), table);
    }

    public static void populateAll(ServerLevel level, Set<BlockPos> chests) {
        Map<Table, LootPools> pools = new EnumMap<>(Table.class);
        List<ItemStack> generalPool = ArenaItemCatalog.getGeneralModdedLoot();
        for (BlockPos pos : chests) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof ChestBlockEntity chest) {
                Table table = TABLES.getOrDefault(pos, Table.ASSAULT);
                LootPools lootPools = pools.computeIfAbsent(table, key -> new LootPools(
                        ArenaItemCatalog.getPriorityLoot(key),
                        ArenaItemCatalog.getAmmoLoot(key),
                        generalPool,
                        configuredLoot(key)
                ));
                populate(chest, lootPools);
            }
        }
        if (!loggedLootSummary) {
            loggedLootSummary = true;
            LOGGER.info("[Tactical Arena] Filled {} arena chests using discovered modded loot and TaCZ weapon/ammo entries.", chests.size());
        }
    }

    private static void populate(ChestBlockEntity chest, LootPools pools) {
        List<ItemStack> priority = pools.priority();
        List<ItemStack> ammo = pools.ammo();
        List<ItemStack> general = pools.general();
        List<String> configured = pools.configured();
        chest.clearContent();
        Set<Integer> usedSlots = new HashSet<>();

        // At least one high-value modded item per chest when the installed pack exposes suitable items.
        if (!priority.isEmpty()) putRandom(chest, priority, usedSlots, 1);
        // TaCZ ammunition is its own guaranteed category instead of being diluted by the full item registry.
        if (!ammo.isEmpty()) putRandom(chest, ammo, usedSlots, 1);
        // A third guaranteed mod item makes it impossible for a populated chest to be vanilla-only.
        if (!general.isEmpty()) putRandom(chest, general, usedSlots, 1);

        boolean allowVanillaFallback = priority.isEmpty() && ammo.isEmpty() && general.isEmpty();
        int desired = 5 + RANDOM.nextInt(3);
        int remaining = Math.max(0, desired - usedSlots.size());
        for (int i = 0; i < remaining; i++) {
            if (!general.isEmpty()) {
                putRandom(chest, general, usedSlots, 1);
            } else if (!configured.isEmpty()) {
                putConfigured(chest, configured, usedSlots, allowVanillaFallback);
            }
        }

        // User-configured mod item IDs remain supported. Old vanilla placeholder lists are ignored whenever
        // the dynamic mod pool is available; they are used only as a last-resort fallback.
        if (general.isEmpty() && priority.isEmpty() && ammo.isEmpty() && !configured.isEmpty()) {
            for (int i = 0; i < 4; i++) putConfigured(chest, configured, usedSlots, allowVanillaFallback);
        }
        chest.setChanged();
    }

    private static List<String> configuredLoot(Table table) {
        return switch (table) {
            case ASSAULT -> copy(ArenaConfig.ASSAULT_LOOT.get());
            case HITMANIA -> copy(ArenaConfig.HITMANIA_LOOT.get());
            case DOCKYARD -> copy(ArenaConfig.DOCKYARD_LOOT.get());
            case BUNKER -> copy(ArenaConfig.BUNKER_LOOT.get());
        };
    }

    private static List<String> copy(List<? extends String> values) {
        return new ArrayList<>(values);
    }

    private static void putRandom(ChestBlockEntity chest, List<ItemStack> pool, Set<Integer> usedSlots, int amount) {
        if (pool.isEmpty()) return;
        for (int n = 0; n < amount; n++) {
            int slot = findFreeSlot(chest, usedSlots);
            if (slot < 0) return;
            ItemStack selected = pool.get(RANDOM.nextInt(pool.size())).copy();
            if (selected.isEmpty()) continue;
            if (selected.getMaxStackSize() > 1 && selected.getCount() == 1) {
                selected.setCount(1 + RANDOM.nextInt(Math.min(8, selected.getMaxStackSize())));
            }
            chest.setItem(slot, selected);
            usedSlots.add(slot);
        }
    }

    private static void putConfigured(ChestBlockEntity chest, List<String> pool, Set<Integer> usedSlots, boolean allowVanillaFallback) {
        if (pool.isEmpty()) return;
        int slot = findFreeSlot(chest, usedSlots);
        if (slot < 0) return;
        String id = pool.get(RANDOM.nextInt(pool.size()));
        net.minecraft.resources.ResourceLocation key = net.minecraft.resources.ResourceLocation.tryParse(id);
        if (key == null) return;
        if (!allowVanillaFallback && key.getNamespace().equals("minecraft")) return;
        net.minecraft.world.item.Item item = net.minecraft.core.registries.BuiltInRegistries.ITEM.getOptional(key)
                .orElse(net.minecraft.world.item.Items.AIR);
        if (item == net.minecraft.world.item.Items.AIR) return;
        chest.setItem(slot, new ItemStack(item));
        usedSlots.add(slot);
    }

    private record LootPools(List<ItemStack> priority, List<ItemStack> ammo,
                             List<ItemStack> general, List<String> configured) {}

    private static int findFreeSlot(ChestBlockEntity chest, Set<Integer> usedSlots) {
        if (usedSlots.size() >= chest.getContainerSize()) return -1;
        for (int attempt = 0; attempt < chest.getContainerSize() * 2; attempt++) {
            int slot = RANDOM.nextInt(chest.getContainerSize());
            if (!usedSlots.contains(slot)) return slot;
        }
        for (int slot = 0; slot < chest.getContainerSize(); slot++) if (!usedSlots.contains(slot)) return slot;
        return -1;
    }
}
