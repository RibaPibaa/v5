package com.ribapibaa.tacticalarena.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Captures the generated arena's baseline and restores every generated block between matches. */
public final class ArenaWorldManager {
    private static final Map<BlockPos, BlockState> BASE_STATES = new HashMap<>();
    private static final Map<BlockPos, BlockState> BROKEN_BLOCKS = new HashMap<>();
    private static final Map<BlockPos, java.util.List<ItemStack>> BASE_CONTAINER_CONTENTS = new HashMap<>();
    private static final Set<BlockPos> CHEST_POSITIONS = new HashSet<>();

    private ArenaWorldManager() {}

    public static void captureBreak(BlockPos pos, BlockState state) {
        BROKEN_BLOCKS.putIfAbsent(pos.immutable(), state);
    }

    public static void captureSnapshot(ServerLevel level, Set<BlockPos> chests, Set<BlockPos> generatedBlocks) {
        BASE_STATES.clear();
        BROKEN_BLOCKS.clear();
        CHEST_POSITIONS.clear();
        BASE_CONTAINER_CONTENTS.clear();
        for (BlockPos pos : generatedBlocks) {
            BlockPos immutable = pos.immutable();
            BASE_STATES.put(immutable, level.getBlockState(immutable));
            BlockEntity blockEntity = level.getBlockEntity(immutable);
            if (blockEntity instanceof Container container) {
                java.util.List<ItemStack> contents = new java.util.ArrayList<>();
                for (int slot = 0; slot < container.getContainerSize(); slot++) {
                    contents.add(container.getItem(slot).copy());
                }
                BASE_CONTAINER_CONTENTS.put(immutable, contents);
            }
        }
        for (BlockPos pos : chests) CHEST_POSITIONS.add(pos.immutable());
    }

    public static void restore(ServerLevel level) {
        // Restore the entire generated structure set, not just the few blocks that were explicitly broken.
        for (Map.Entry<BlockPos, BlockState> entry : BASE_STATES.entrySet()) {
            level.setBlock(entry.getKey(), entry.getValue(), 2);
        }
        // Keep compatibility with any destructible positions that were not part of the tracked generator output.
        for (Map.Entry<BlockPos, BlockState> entry : BROKEN_BLOCKS.entrySet()) {
            if (!BASE_STATES.containsKey(entry.getKey())) {
                level.setBlock(entry.getKey(), entry.getValue(), 2);
            }
        }
        BROKEN_BLOCKS.clear();
        for (Map.Entry<BlockPos, java.util.List<ItemStack>> entry : BASE_CONTAINER_CONTENTS.entrySet()) {
            BlockEntity blockEntity = level.getBlockEntity(entry.getKey());
            if (blockEntity instanceof Container container) {
                container.clearContent();
                java.util.List<ItemStack> contents = entry.getValue();
                for (int slot = 0; slot < Math.min(container.getContainerSize(), contents.size()); slot++) {
                    container.setItem(slot, contents.get(slot).copy());
                }
                blockEntity.setChanged();
            }
        }

        // Every round gets freshly rolled modded equipment, ammunition and supplies.
        ArenaLoot.populateAll(level, CHEST_POSITIONS);

        // Remove dropped gear and modded corpse/ragdoll entities from all combat regions.
        for (AABB bounds : ArenaMapGenerator.allBounds()) {
            for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, bounds)) item.discard();
            for (Entity entity : level.getEntitiesOfClass(Entity.class, bounds, ArenaWorldManager::isVisceralBody)) {
                entity.discard();
            }
        }
    }

    private static boolean isVisceralBody(Entity entity) {
        ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (id == null || !id.getNamespace().equals("visceral")) return false;
        String path = id.getPath();
        return path.contains("corpse") || path.contains("body") || path.contains("ragdoll");
    }
}
