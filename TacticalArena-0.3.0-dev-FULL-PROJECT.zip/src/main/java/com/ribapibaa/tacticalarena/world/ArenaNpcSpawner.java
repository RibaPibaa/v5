package com.ribapibaa.tacticalarena.world;

import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** MCA Reborn integration. Civilian MCA villagers are explicitly forced to adult age. */
public final class ArenaNpcSpawner {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final List<BlockPos> SPAWN_POINTS = new ArrayList<>();
    private static final Random RANDOM = new Random();
    private static int nameCounter;
    private static boolean loggedEntityChoice;

    private ArenaNpcSpawner() {}

    public static void resetSpawnPoints() {
        SPAWN_POINTS.clear();
        nameCounter = 0;
    }

    public static void registerSpawn(int x, int y, int z) {
        SPAWN_POINTS.add(new BlockPos(x, y, z));
    }

    public static void populate(ServerLevel level, boolean battleRoyale) {
        for (net.minecraft.world.phys.AABB bounds : ArenaMapGenerator.allBounds()) {
            for (Entity entity : level.getEntitiesOfClass(Entity.class, bounds, ArenaNpcSpawner::isArenaCivilian)) {
                entity.discard();
            }
        }
        List<BlockPos> points = new ArrayList<>(SPAWN_POINTS);
        if (battleRoyale && !points.isEmpty()) {
            List<BlockPos> reduced = new ArrayList<>();
            for (int i = 0; i < points.size(); i++) if (i % 3 == 0) reduced.add(points.get(i));
            points = reduced;
        }
        for (BlockPos pos : points) spawnOne(level, pos);
    }

    private static void spawnOne(ServerLevel level, BlockPos requested) {
        BlockPos pos = findSafePosition(level, requested);
        if (pos == null) return;

        EntityType<?> type = findMcaType();
        Entity entity = type.create(level);
        if (entity == null) entity = EntityType.VILLAGER.create(level);
        if (entity == null) return;

        forceAdult(entity);
        if (!isAdult(entity)) {
            entity.discard();
            entity = EntityType.VILLAGER.create(level);
            if (entity == null) return;
            forceAdult(entity);
        }

        entity.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5,
                RANDOM.nextFloat() * 360.0F, 0.0F);
        entity.setCustomName(Component.literal(randomName()));
        entity.setCustomNameVisible(false);
        entity.getPersistentData().putBoolean("tacticalarena_civilian", true);
        entity.addTag("tacticalarena_civilian");
        if (entity instanceof Mob mob) {
            mob.setNoAi(false);
            mob.setPersistenceRequired();
        }
        level.addFreshEntity(entity);
    }

    private static boolean isArenaCivilian(Entity entity) {
        if (entity.getPersistentData().getBoolean("tacticalarena_civilian")
                || entity.getTags().contains("tacticalarena_civilian")) return true;
        ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        return id != null && id.getNamespace().equals("mca")
                && (id.getPath().equals("male_villager") || id.getPath().equals("female_villager"));
    }

    private static BlockPos findSafePosition(ServerLevel level, BlockPos requested) {
        for (int offset = 0; offset <= 3; offset++) {
            for (int direction : offset == 0 ? new int[]{0} : new int[]{1, -1}) {
                BlockPos feet = requested.offset(0, offset * direction, 0);
                BlockPos head = feet.above();
                BlockPos floor = feet.below();
                if (level.getBlockState(floor).isSolidRender(level, floor)
                        && level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                        && level.getBlockState(head).getCollisionShape(level, head).isEmpty()
                        && level.getFluidState(feet).isEmpty()
                        && level.getFluidState(head).isEmpty()) {
                    return feet;
                }
            }
        }
        return null;
    }

    private static EntityType<?> findMcaType() {
        String[] ids = RANDOM.nextBoolean()
                ? new String[]{"mca:female_villager", "mca:male_villager"}
                : new String[]{"mca:male_villager", "mca:female_villager"};
        for (String id : ids) {
            ResourceLocation key = ResourceLocation.tryParse(id);
            if (key != null) {
                EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.getOptional(key).orElse(null);
                if (type != null) {
                    logEntityChoice(key.toString());
                    return type;
                }
            }
        }
        for (EntityType<?> candidate : BuiltInRegistries.ENTITY_TYPE) {
            ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(candidate);
            if (key != null && key.getNamespace().equals("mca")
                    && (key.getPath().equals("male_villager") || key.getPath().equals("female_villager"))) {
                logEntityChoice(key.toString());
                return candidate;
            }
        }
        logEntityChoice("minecraft:villager (adult fallback)");
        return EntityType.VILLAGER;
    }

    /** MCA uses its own AgeState API; vanilla AgeableMob is handled as a fallback. */
    private static void forceAdult(Entity entity) {
        try {
            for (Method method : entity.getClass().getMethods()) {
                if (!method.getName().equals("setAgeState") || method.getParameterCount() != 1) continue;
                Class<?> stateClass = method.getParameterTypes()[0];
                if (!stateClass.isEnum()) continue;
                Object adult = null;
                for (Object constant : stateClass.getEnumConstants()) {
                    if (constant.toString().equalsIgnoreCase("ADULT")) {
                        adult = constant;
                        break;
                    }
                }
                if (adult != null) method.invoke(entity, adult);
                break;
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            LOGGER.debug("Could not set MCA adult state through its API; trying vanilla age API", exception);
        }
        if (entity instanceof AgeableMob ageable) ageable.setAge(0);
    }

    private static boolean isAdult(Entity entity) {
        try {
            for (Method method : entity.getClass().getMethods()) {
                if (!method.getName().equals("getAgeState") || method.getParameterCount() != 0) continue;
                Object state = method.invoke(entity);
                if (state != null) return state.toString().equalsIgnoreCase("ADULT");
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
        return !(entity instanceof AgeableMob ageable) || !ageable.isBaby();
    }

    private static void logEntityChoice(String id) {
        if (loggedEntityChoice) return;
        loggedEntityChoice = true;
        LOGGER.info("[Tactical Arena] Civilian NPC entity: {}. All spawned ageable villagers are forced to adult.", id);
    }

    private static String randomName() {
        String[] names = {"Alex", "Mason", "Noah", "Ethan", "Liam", "Mia", "Emma", "Olivia", "Sofia", "Nora", "Daniel", "Lucas", "Eva", "Mila"};
        return names[RANDOM.nextInt(names.length)] + " " + (++nameCounter);
    }
}
