package com.ribapibaa.tacticalarena.world;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import com.ribapibaa.tacticalarena.game.ArenaMatchManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Procedural arena regions. Login builds only the lobby; combat maps are deferred until match preparation. */
public final class ArenaMapGenerator {
    public static final BlockPos ASSAULT = new BlockPos(-520, 80, -300);
    public static final BlockPos HITMANIA = new BlockPos(520, 80, -300);
    public static final BlockPos DOCKYARD = new BlockPos(0, 80, 620);
    public static final BlockPos BUNKER = new BlockPos(0, 35, 0);
    public static final BlockPos LOBBY = new BlockPos(0, 80, 1900);
    private static final int RADIUS = 105;
    private static final Set<BlockPos> CHESTS = new HashSet<>();
    private static final Set<BlockPos> GENERATED_BLOCKS = new HashSet<>();
    private static final List<BlockPos> GATE_BLOCKS = new ArrayList<>();
    private static final Random RANDOM = new Random(20261113L);
    private static boolean generated;
    private static boolean lobbyGenerated;
    private static BlockPos hitmaniaSelected = HITMANIA;
    private static final List<Vec3> USED_BR_SPAWNS = new ArrayList<>();

    private ArenaMapGenerator() {}

    public static boolean isGenerated() {
        return generated;
    }

    /** Builds only the small spawn area during login; the expensive combat maps wait until a match is requested. */
    public static void ensureLobbyGenerated(ServerLevel level) {
        if (lobbyGenerated || level.getBlockState(LOBBY.below()).is(Blocks.BEDROCK)) {
            lobbyGenerated = true;
            return;
        }
        generateLobby(level, LOBBY);
        set(level, LOBBY.getX(), LOBBY.getY() - 1, LOBBY.getZ(), Blocks.BEDROCK.defaultBlockState());
        lobbyGenerated = true;
    }

    public static void generateAll(ServerLevel level) {
        RANDOM.setSeed(20261113L);
        clearLegacyCombatStructures(level);
        CHESTS.clear();
        GATE_BLOCKS.clear();
        ArenaLoot.clearTables();
        ArenaNpcSpawner.resetSpawnPoints();
        generateVillage(level, ASSAULT);
        generateCity(level, HITMANIA);
        generateDockyard(level, DOCKYARD);
        generateBunker(level, BUNKER);
        ensureLobbyGenerated(level);
        generatePassages(level);
        ArenaLoot.populateAll(level, CHESTS);
        ArenaNpcSpawner.populate(level, false);
        ArenaWorldManager.captureSnapshot(level, CHESTS, GENERATED_BLOCKS);
        generated = true;
    }

    public static void prepareMatch(ArenaMatchManager.Mode mode) {
        hitmaniaSelected = RANDOM.nextBoolean() ? ASSAULT : HITMANIA;
        USED_BR_SPAWNS.clear();
    }

    public static void setBattleRoyaleAccess(ServerLevel level, boolean open) {
        for (BlockPos pos : GATE_BLOCKS) level.setBlock(pos, open ? Blocks.AIR.defaultBlockState() : Blocks.IRON_BARS.defaultBlockState(), 3);
    }

    public static Vec3 randomBattleRoyaleSpawn(ServerLevel level, int playerIndex) {
        BlockPos[] centers = {ASSAULT, HITMANIA, DOCKYARD};
        for (int attempt = 0; attempt < 150; attempt++) {
            BlockPos center = centers[RANDOM.nextInt(centers.length)];
            double angle = RANDOM.nextDouble() * Math.PI * 2.0;
            double radius = 18 + RANDOM.nextDouble() * 70;
            int x = center.getX() + (int) Math.round(Math.cos(angle) * radius);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * radius);
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos feet = new BlockPos(x, y, z);
            if (!isCombatArenaPosition(feet)) continue;
            if (!level.getBlockState(feet.below()).isSolidRender(level, feet.below())) continue;
            if (level.getBlockState(feet).is(Blocks.FIRE) || level.getBlockState(feet).is(Blocks.SOUL_FIRE)) continue;
            if (!level.getFluidState(feet).isEmpty() || !level.getFluidState(feet.above()).isEmpty()) continue;
            if (!level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()) continue;
            if (!level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()) continue;
            Vec3 candidate = new Vec3(x + 0.5, y, z + 0.5);
            boolean tooClose = USED_BR_SPAWNS.stream().anyMatch(existing -> existing.distanceTo(candidate) < 120.0D);
            if (tooClose) continue;
            USED_BR_SPAWNS.add(candidate);
            return candidate;
        }
        BlockPos fallback = centers[playerIndex % centers.length];
        return new Vec3(fallback.getX() + 0.5, fallback.getY() + 1, fallback.getZ() + 0.5);
    }

    public static Vec3 lobbySpawn() { return new Vec3(LOBBY.getX() + 0.5, LOBBY.getY() + 1, LOBBY.getZ() + 10.5); }

    public static Vec3 spawnFor(ArenaMatchManager.Mode mode, int playerIndex, int playerCount) {
        BlockPos center;
        if (mode == ArenaMatchManager.Mode.ASSAULT) center = ASSAULT;
        else if (mode == ArenaMatchManager.Mode.HITMANIA) center = hitmaniaSelected;
        else {
            BlockPos[] choices = {ASSAULT, HITMANIA, DOCKYARD};
            center = choices[RANDOM.nextInt(choices.length)];
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double distance = 22 + RANDOM.nextDouble() * 55;
            return new Vec3(center.getX() + Math.cos(angle) * distance, center.getY() + 2, center.getZ() + Math.sin(angle) * distance);
        }
        double offset = playerIndex == 0 ? -4.0 : 4.0;
        // The village square and city plaza occupy the center; deploy on the clear road beyond them.
        return new Vec3(center.getX() + offset, center.getY() + 1, center.getZ() + 19);
    }

    public static boolean isArenaPosition(BlockPos pos) {
        return inside(pos, ASSAULT, RADIUS) || inside(pos, HITMANIA, RADIUS) || inside(pos, DOCKYARD, RADIUS)
                || inside(pos, BUNKER, 45) || inside(pos, LOBBY, 58) || nearPassage(pos);
    }

    public static boolean isCombatArenaPosition(BlockPos pos) {
        return inside(pos, ASSAULT, RADIUS) || inside(pos, HITMANIA, RADIUS) || inside(pos, DOCKYARD, RADIUS) || inside(pos, BUNKER, 45) || nearPassage(pos);
    }

    public static boolean isLobbyPosition(BlockPos pos) {
        return inside(pos, LOBBY, 58);
    }

    private static boolean nearPassage(BlockPos pos) {
        if (pos.getY() < 65 || pos.getY() > 82) return false;
        int ax = ASSAULT.getX() + 100, az = ASSAULT.getZ();
        int hx = HITMANIA.getX() - 100, hz = HITMANIA.getZ();
        int dx = DOCKYARD.getX(), dz = DOCKYARD.getZ() - 100;
        return distanceToSegment(pos.getX(), pos.getZ(), ax, az, hx, hz) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), HITMANIA.getX(), HITMANIA.getZ() + 100, DOCKYARD.getX() + 70, DOCKYARD.getZ() - 70) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), DOCKYARD.getX() - 70, DOCKYARD.getZ() - 70, ASSAULT.getX(), ASSAULT.getZ() + 100) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), BUNKER.getX(), BUNKER.getZ(), ax, az) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), BUNKER.getX(), BUNKER.getZ(), hx, hz) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), BUNKER.getX(), BUNKER.getZ(), dx, dz) < 7;
    }

    private static double distanceToSegment(double px, double pz, double ax, double az, double bx, double bz) {
        double dx = bx - ax, dz = bz - az;
        double length = dx * dx + dz * dz;
        if (length == 0) return Math.hypot(px - ax, pz - az);
        double t = Math.max(0, Math.min(1, ((px - ax) * dx + (pz - az) * dz) / length));
        return Math.hypot(px - (ax + t * dx), pz - (az + t * dz));
    }

    public static List<net.minecraft.world.phys.AABB> allBounds() {
        return List.of(bounds(ASSAULT, RADIUS, 80), bounds(HITMANIA, RADIUS, 80), bounds(DOCKYARD, RADIUS, 80),
                bounds(BUNKER, 45, 45), bounds(LOBBY, 58, 48), new net.minecraft.world.phys.AABB(-430, 65, -310, 430, 82, -290),
                new net.minecraft.world.phys.AABB(-10, 65, -410, 530, 82, 550), new net.minecraft.world.phys.AABB(-530, 65, -410, 10, 82, 550),
                new net.minecraft.world.phys.AABB(-430, 65, -310, 10, 82, 10), new net.minecraft.world.phys.AABB(-10, 65, -310, 430, 82, 10),
                new net.minecraft.world.phys.AABB(-10, 65, -10, 10, 82, 550));
    }

    private static boolean inside(BlockPos pos, BlockPos center, int radius) {
        long dx = pos.getX() - center.getX(); long dz = pos.getZ() - center.getZ();
        return dx * dx + dz * dz <= (long) radius * radius && Math.abs(pos.getY() - center.getY()) <= 90;
    }

    private static net.minecraft.world.phys.AABB bounds(BlockPos center, int radius, int yRadius) {
        return new net.minecraft.world.phys.AABB(center.getX() - radius, center.getY() - yRadius, center.getZ() - radius,
                center.getX() + radius, center.getY() + yRadius, center.getZ() + radius);
    }

    private static void clearLegacyCombatStructures(ServerLevel level) {
        int surface = ArenaConfig.ARENA_Y.get();
        clearCircularAboveSurface(level, ASSAULT, RADIUS + 2, surface, surface + 24);
        clearCircularAboveSurface(level, HITMANIA, RADIUS + 2, surface, surface + 45);
        clearCircularAboveSurface(level, DOCKYARD, RADIUS + 2, surface, surface + 36);
        for (int x = BUNKER.getX() - 44; x <= BUNKER.getX() + 44; x++) {
            for (int y = 18; y <= 48; y++) {
                for (int z = BUNKER.getZ() - 44; z <= BUNKER.getZ() + 44; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!level.getBlockState(pos).isAir()) level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2);
                }
            }
        }
    }

    private static void clearCircularAboveSurface(ServerLevel level, BlockPos center, int radius, int minY, int maxY) {
        int radiusSquared = radius * radius;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radiusSquared) continue;
                for (int y = minY; y <= maxY; y++) {
                    BlockPos pos = new BlockPos(center.getX() + dx, y, center.getZ() + dz);
                    if (!level.getBlockState(pos).isAir()) level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2);
                }
            }
        }
    }

    private static void generateVillage(ServerLevel level, BlockPos c) {
        circularGround(level, c, RADIUS + 2, Blocks.COARSE_DIRT.defaultBlockState());
        circularWall(level, c, RADIUS, Blocks.MOSSY_STONE_BRICKS.defaultBlockState());

        // A small village layout: houses face the roads, but each plot receives a different footprint and roof.
        int[][] plots = {
                {-58, -54}, {-28, -57}, {28, -57}, {58, -28},
                {58, 28}, {28, 57}, {-28, 57}, {-58, 28},
                {-58, 0}, {58, 0}, {0, -58}, {0, 58}
        };
        for (int i = 0; i < plots.length; i++) {
            int x = c.getX() + plots[i][0];
            int z = c.getZ() + plots[i][1];
            int width = 10 + RANDOM.nextInt(5);
            int depth = 9 + RANDOM.nextInt(5);
            int floors = RANDOM.nextInt(4) == 0 ? 2 : 1;
            buildVillageHouse(level, x - width / 2, c.getY(), z - depth / 2,
                    width, depth, floors, i % 6);
        }

        // Main roads and narrow lanes connecting front doors to the village square.
        box(level, c.getX() - 5, c.getY(), c.getZ() - 96,
                c.getX() + 5, c.getY(), c.getZ() + 96, Blocks.GRAVEL.defaultBlockState());
        box(level, c.getX() - 96, c.getY(), c.getZ() - 5,
                c.getX() + 96, c.getY(), c.getZ() + 5, Blocks.GRAVEL.defaultBlockState());
        for (int i = 0; i < 14; i++) {
            int x = c.getX() + RANDOM.nextInt(140) - 70;
            int z = c.getZ() + RANDOM.nextInt(140) - 70;
            if (Math.abs(x - c.getX()) < 16 && Math.abs(z - c.getZ()) < 16) continue;
            box(level, x, c.getY(), z, x + 3, c.getY(), z + 3, Blocks.COBBLESTONE.defaultBlockState());
            if (RANDOM.nextBoolean()) set(level, x + 1, c.getY() + 1, z + 1, Blocks.FLOWER_POT.defaultBlockState());
        }
        buildVillageSquare(level, c);
        placeChest(level, c.getX() - 36, c.getY() + 1, c.getZ() + 36, ArenaLoot.Table.ASSAULT);
        placeChest(level, c.getX() + 42, c.getY() + 1, c.getZ() - 40, ArenaLoot.Table.ASSAULT);
    }

    private static void buildVillageHouse(ServerLevel level, int x, int y, int z,
                                          int w, int d, int floors, int style) {
        int floorHeight = 4;
        int h = floors * floorHeight + 1;
        BlockState wall = switch (style % 6) {
            case 0 -> Blocks.BRICKS.defaultBlockState();
            case 1 -> Blocks.OAK_PLANKS.defaultBlockState();
            case 2 -> Blocks.MOSSY_COBBLESTONE.defaultBlockState();
            case 3 -> Blocks.WHITE_TERRACOTTA.defaultBlockState();
            case 4 -> Blocks.STONE_BRICKS.defaultBlockState();
            default -> Blocks.SPRUCE_PLANKS.defaultBlockState();
        };
        BlockState roof = switch (style % 4) {
            case 0 -> Blocks.DARK_OAK_PLANKS.defaultBlockState();
            case 1 -> Blocks.SPRUCE_PLANKS.defaultBlockState();
            case 2 -> Blocks.DEEPSLATE_TILES.defaultBlockState();
            default -> Blocks.BRICKS.defaultBlockState();
        };
        BlockState floor = style % 2 == 0 ? Blocks.OAK_PLANKS.defaultBlockState() : Blocks.SPRUCE_PLANKS.defaultBlockState();

        // Outer shell and hollow interior; unlike the prototype, houses have multiple architectural details.
        box(level, x, y, z, x + w, y + h, z + d, wall);
        box(level, x + 1, y + 1, z + 1, x + w - 1, y + h - 1, z + d - 1, Blocks.AIR.defaultBlockState());
        box(level, x + 1, y + 1, z + 1, x + w - 1, y + 1, z + d - 1, floor);
        if (floors > 1) {
            box(level, x + 1, y + floorHeight + 1, z + 1,
                    x + w - 1, y + floorHeight + 1, z + d - 1, Blocks.SPRUCE_PLANKS.defaultBlockState());
            // A stairwell and landing make the upper floor reachable.
            for (int step = 0; step < 4; step++) {
                set(level, x + w - 3, y + 2 + step, z + 2 + step, Blocks.SPRUCE_STAIRS.defaultBlockState());
            }
        }

        // Front door and windows on both long sides.
        int doorX = x + w / 2;
        placeDoor(level, doorX, y + 1, z + d, Direction.SOUTH);
        for (int floorIndex = 0; floorIndex < floors; floorIndex++) {
            int windowY = y + 2 + floorIndex * floorHeight;
            for (int wx = x + 3; wx < x + w - 2; wx += 4) {
                set(level, wx, windowY, z, Blocks.GLASS_PANE.defaultBlockState());
                set(level, wx, windowY, z + d, Blocks.GLASS_PANE.defaultBlockState());
            }
            set(level, x, windowY, z + d / 2, Blocks.GLASS_PANE.defaultBlockState());
            set(level, x + w, windowY, z + d / 2, Blocks.GLASS_PANE.defaultBlockState());
        }

        // A small porch, support posts and steps give the frontage a readable entrance.
        box(level, x + w / 2 - 3, y + 1, z + d + 1,
                x + w / 2 + 3, y + 1, z + d + 4, Blocks.SPRUCE_SLAB.defaultBlockState());
        set(level, x + w / 2 - 3, y + 2, z + d + 1, Blocks.SPRUCE_FENCE.defaultBlockState());
        set(level, x + w / 2 + 3, y + 2, z + d + 1, Blocks.SPRUCE_FENCE.defaultBlockState());
        box(level, x + w / 2 - 2, y, z + d + 4,
                x + w / 2 + 2, y, z + d + 5, Blocks.COBBLESTONE.defaultBlockState());

        // Individual roof profiles: gable, hip, flat parapet and an offset extension.
        if (style % 4 == 0 || style % 4 == 1) {
            int rise = Math.max(2, Math.min(5, w / 3));
            for (int layer = 0; layer <= rise; layer++) {
                int left = x + layer;
                int right = x + w - layer;
                box(level, left, y + h + layer, z - 1,
                        right, y + h + layer, z + d + 1, roof);
            }
        } else if (style % 4 == 2) {
            box(level, x - 1, y + h + 1, z - 1, x + w + 1, y + h + 1, z + d + 1, roof);
            box(level, x - 1, y + h + 2, z - 1, x + w + 1, y + h + 2, z - 1, Blocks.STONE_BRICK_WALL.defaultBlockState());
            box(level, x - 1, y + h + 2, z + d + 1, x + w + 1, y + h + 2, z + d + 1, Blocks.STONE_BRICK_WALL.defaultBlockState());
        } else {
            for (int layer = 0; layer < 3; layer++) {
                box(level, x - 1 + layer, y + h + 1 + layer, z - 1 + layer,
                        x + w + 1 - layer, y + h + 1 + layer, z + d + 1 - layer, roof);
            }
        }

        // Interior furnishing varies with the house style.
        set(level, x + 2, y + 2, z + 2, Blocks.BOOKSHELF.defaultBlockState());
        set(level, x + w - 2, y + 2, z + 2, Blocks.BARREL.defaultBlockState());
        set(level, x + 2, y + 2, z + d - 2, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(level, x + w - 2, y + 2, z + d - 2, Blocks.FURNACE.defaultBlockState());
        set(level, x + w / 2, y + 4, z + d / 2, Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        if (style % 3 == 0) {
            set(level, x + 3, y + 2, z + d / 2, Blocks.BARREL.defaultBlockState());
        } else if (style % 3 == 1) {
            box(level, x + w / 2 - 1, y + 2, z + d / 2 - 1,
                    x + w / 2 + 1, y + 2, z + d / 2 + 1, Blocks.OAK_PLANKS.defaultBlockState());
            set(level, x + w / 2 - 2, y + 2, z + d / 2, Blocks.OAK_STAIRS.defaultBlockState());
            set(level, x + w / 2 + 2, y + 2, z + d / 2, Blocks.OAK_STAIRS.defaultBlockState());
        }

        // Chimney and a small garden/woodpile, positioned differently per house.
        int chimneyX = style % 2 == 0 ? x + w - 2 : x + 2;
        box(level, chimneyX, y + h + 1, z + 2, chimneyX + 1, y + h + 5, z + 3, Blocks.BRICKS.defaultBlockState());
        set(level, chimneyX, y + h + 6, z + 2, Blocks.CAMPFIRE.defaultBlockState());
        box(level, x - 2, y + 1, z + d + 7, x + 2, y + 1, z + d + 8, Blocks.OAK_LOG.defaultBlockState());
        set(level, x - 3, y + 1, z + d + 6, Blocks.FLOWER_POT.defaultBlockState());

        ArenaNpcSpawner.registerSpawn(x + 3, y + 2, z + 3);
        placeChest(level, x + 1, y + 2, z + 1, ArenaLoot.Table.ASSAULT);
    }

    private static void buildVillageSquare(ServerLevel level, BlockPos c) {
        int x = c.getX(), y = c.getY(), z = c.getZ();
        box(level, x - 12, y, z - 12, x + 12, y, z + 12, Blocks.STONE_BRICKS.defaultBlockState());
        box(level, x - 4, y + 1, z - 4, x + 4, y + 2, z + 4, Blocks.MOSSY_STONE_BRICKS.defaultBlockState());
        box(level, x - 3, y + 3, z - 3, x + 3, y + 3, z + 3, Blocks.WATER.defaultBlockState());
        for (int dx : new int[]{-9, 9}) {
            for (int dz : new int[]{-9, 9}) {
                box(level, x + dx, y + 1, z + dz, x + dx, y + 3, z + dz, Blocks.OAK_LOG.defaultBlockState());
                set(level, x + dx, y + 4, z + dz, Blocks.LANTERN.defaultBlockState());
            }
        }
        set(level, x - 7, y + 1, z, Blocks.SPRUCE_STAIRS.defaultBlockState());
        set(level, x + 7, y + 1, z, Blocks.SPRUCE_STAIRS.defaultBlockState());
    }

    private static void placeDoor(ServerLevel level, int x, int y, int z, Direction facing) {
        BlockState lower = Blocks.DARK_OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER)
                .setValue(DoorBlock.HINGE, DoorHingeSide.LEFT)
                .setValue(DoorBlock.OPEN, false);
        write(level, new BlockPos(x, y, z), lower);
        write(level, new BlockPos(x, y + 1, z), lower.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
    }

    private static void generateCity(ServerLevel level, BlockPos c) {
        circularGround(level, c, RADIUS + 2, Blocks.GRAY_CONCRETE.defaultBlockState());
        circularWall(level, c, RADIUS, Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        box(level, c.getX() - 6, c.getY(), c.getZ() - 96,
                c.getX() + 6, c.getY(), c.getZ() + 96, Blocks.BLACK_CONCRETE.defaultBlockState());
        box(level, c.getX() - 96, c.getY(), c.getZ() - 6,
                c.getX() + 96, c.getY(), c.getZ() + 6, Blocks.BLACK_CONCRETE.defaultBlockState());

        int[][] plots = {{-58,-58},{-20,-58},{20,-58},{58,-20},{58,24},{20,58},{-20,58},{-58,20}};
        for (int i = 0; i < plots.length; i++) {
            int width = 17 + RANDOM.nextInt(7);
            int depth = 16 + RANDOM.nextInt(8);
            int floors = 2 + RANDOM.nextInt(4);
            int x = c.getX() + plots[i][0] - width / 2;
            int z = c.getZ() + plots[i][1] - depth / 2;
            buildCityBuilding(level, x, c.getY(), z, width, depth, floors, i % 5);
        }
        buildCityPlaza(level, c);
        placeChest(level, c.getX() - 70, c.getY() + 1, c.getZ() + 68, ArenaLoot.Table.HITMANIA);
        placeChest(level, c.getX() + 70, c.getY() + 1, c.getZ() - 68, ArenaLoot.Table.HITMANIA);
    }

    private static void buildCityBuilding(ServerLevel level, int x, int y, int z,
                                          int w, int d, int floors, int style) {
        BlockState wall = switch (style) {
            case 0 -> Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
            case 1 -> Blocks.BRICKS.defaultBlockState();
            case 2 -> Blocks.GRAY_CONCRETE.defaultBlockState();
            case 3 -> Blocks.SMOOTH_STONE.defaultBlockState();
            default -> Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        };
        BlockState accent = switch (style) {
            case 0 -> Blocks.BLACK_CONCRETE.defaultBlockState();
            case 1 -> Blocks.SPRUCE_PLANKS.defaultBlockState();
            case 2 -> Blocks.IRON_BLOCK.defaultBlockState();
            case 3 -> Blocks.WHITE_CONCRETE.defaultBlockState();
            default -> Blocks.POLISHED_ANDESITE.defaultBlockState();
        };
        BlockState glass = style % 2 == 0 ? Blocks.CYAN_STAINED_GLASS_PANE.defaultBlockState()
                : Blocks.LIGHT_GRAY_STAINED_GLASS_PANE.defaultBlockState();
        int floorHeight = 5;
        for (int floorIndex = 0; floorIndex < floors; floorIndex++) {
            int fy = y + floorIndex * floorHeight;
            box(level, x, fy, z, x + w, fy + 4, z + d, wall);
            box(level, x + 1, fy + 1, z + 1, x + w - 1, fy + 3, z + d - 1, Blocks.AIR.defaultBlockState());
            box(level, x + 1, fy + 1, z + 1, x + w - 1, fy + 1, z + d - 1, Blocks.POLISHED_ANDESITE.defaultBlockState());

            // Window rhythm changes by building type rather than repeating the same glass grid.
            int windowStep = style == 1 ? 3 : style == 3 ? 5 : 4;
            for (int wx = x + 3; wx < x + w - 2; wx += windowStep) {
                set(level, wx, fy + 2, z, glass);
                set(level, wx, fy + 2, z + d, glass);
            }
            for (int wz = z + 3; wz < z + d - 2; wz += windowStep) {
                set(level, x, fy + 2, wz, glass);
                set(level, x + w, fy + 2, wz, glass);
            }

            // Vertical facade ribs and floor bands.
            for (int pillarX : new int[]{x, x + w}) {
                for (int pillarZ : new int[]{z, z + d}) {
                    box(level, pillarX, fy, pillarZ, pillarX, fy + 4, pillarZ, accent);
                }
            }
            if (style == 1 && floorIndex > 0) {
                int balconyZ = z + d + 2;
                box(level, x + 3, fy + 1, balconyZ, x + w - 3, fy + 1, balconyZ + 2, Blocks.STONE_BRICKS.defaultBlockState());
                box(level, x + 3, fy + 2, balconyZ + 2, x + w - 3, fy + 3, balconyZ + 2, Blocks.IRON_BARS.defaultBlockState());
            }
            if (style == 4) {
                box(level, x + 2, fy + 2, z + 2, x + w - 2, fy + 2, z + 2, accent);
                box(level, x + 2, fy + 2, z + d - 2, x + w - 2, fy + 2, z + d - 2, accent);
            }
            if (floorIndex == 0) {
                placeDoor(level, x + w / 2, fy + 1, z + d, Direction.SOUTH);
            }
            set(level, x + w / 2, fy + 1, z + d / 2, Blocks.SEA_LANTERN.defaultBlockState());
            ArenaNpcSpawner.registerSpawn(x + 3, fy + 2, z + 3);
            if (floorIndex == 0 && style != 2) placeChest(level, x + 2, fy + 2, z + 2, ArenaLoot.Table.HITMANIA);
            if (floorIndex < floors - 1) {
                for (int stairY = fy + 1; stairY < fy + 5; stairY++) {
                    set(level, x + w - 3, stairY, z + 3 + (stairY - fy - 1), Blocks.SCAFFOLDING.defaultBlockState());
                }
            }
        }

        int roofY = y + floors * floorHeight;
        box(level, x - 1, roofY, z - 1, x + w + 1, roofY, z + d + 1, accent);
        if (style == 0) {
            // Office roof plant room and rooftop machinery.
            box(level, x + w / 2 - 3, roofY + 1, z + d / 2 - 3,
                    x + w / 2 + 3, roofY + 4, z + d / 2 + 3, wall);
            box(level, x + w / 2 - 2, roofY + 2, z + d / 2 - 2,
                    x + w / 2 + 2, roofY + 3, z + d / 2 + 2, Blocks.AIR.defaultBlockState());
            set(level, x + w / 2, roofY + 4, z + d / 2, Blocks.LIGHTNING_ROD.defaultBlockState());
        } else if (style == 2) {
            // Industrial roof vents and loading bay.
            for (int vent = x + 3; vent < x + w - 2; vent += 5) {
                box(level, vent, roofY + 1, z + 3, vent + 1, roofY + 2, z + 5, Blocks.IRON_BLOCK.defaultBlockState());
            }
            box(level, x + w / 2 - 2, y + 1, z + d, x + w / 2 + 2, y + 3, z + d, Blocks.AIR.defaultBlockState());
            box(level, x + w / 2 - 3, y + 1, z + d + 1, x + w / 2 + 3, y + 1, z + d + 4, Blocks.STONE_BRICKS.defaultBlockState());
        } else if (style == 3) {
            // Storefront awning, display windows and a sign band.
            box(level, x + 2, y + 3, z + d + 1, x + w - 2, y + 3, z + d + 4, Blocks.RED_WOOL.defaultBlockState());
            box(level, x + 2, y + 2, z + d, x + w - 2, y + 3, z + d, glass);
            box(level, x + 2, y + 4, z + d, x + w - 2, y + 4, z + d, Blocks.WHITE_CONCRETE.defaultBlockState());
        } else {
            // Apartment rooftop terrace with a low parapet and water tank.
            box(level, x + 2, roofY + 1, z + 2, x + w - 2, roofY + 1, z + d - 2, Blocks.STONE_BRICKS.defaultBlockState());
            box(level, x + 2, roofY + 2, z + 2, x + w - 2, roofY + 2, z + 2, Blocks.IRON_BARS.defaultBlockState());
            box(level, x + 2, roofY + 2, z + d - 2, x + w - 2, roofY + 2, z + d - 2, Blocks.IRON_BARS.defaultBlockState());
            box(level, x + w - 5, roofY + 2, z + 4, x + w - 3, roofY + 5, z + 6, Blocks.IRON_BLOCK.defaultBlockState());
        }
    }

    private static void buildCityPlaza(ServerLevel level, BlockPos c) {
        int x = c.getX(), y = c.getY(), z = c.getZ();
        box(level, x - 13, y, z - 13, x + 13, y, z + 13, Blocks.SMOOTH_STONE.defaultBlockState());
        box(level, x - 5, y + 1, z - 5, x + 5, y + 2, z + 5, Blocks.POLISHED_ANDESITE.defaultBlockState());
        box(level, x - 3, y + 3, z - 3, x + 3, y + 3, z + 3, Blocks.WATER.defaultBlockState());
        for (int dx : new int[]{-10, 10}) {
            for (int dz : new int[]{-10, 10}) {
                box(level, x + dx, y + 1, z + dz, x + dx, y + 3, z + dz, Blocks.IRON_BLOCK.defaultBlockState());
                set(level, x + dx, y + 4, z + dz, Blocks.SEA_LANTERN.defaultBlockState());
            }
        }
        box(level, x - 8, y + 1, z - 1, x - 5, y + 1, z + 1, Blocks.SPRUCE_PLANKS.defaultBlockState());
        box(level, x + 5, y + 1, z - 1, x + 8, y + 1, z + 1, Blocks.SPRUCE_PLANKS.defaultBlockState());
    }

    private static void generateDockyard(ServerLevel level, BlockPos c) {
        circularGround(level, c, RADIUS + 2, Blocks.COARSE_DIRT.defaultBlockState());
        circularWall(level, c, RADIUS, Blocks.IRON_BLOCK.defaultBlockState());

        // Rail lanes and a large, accessible loading warehouse.
        box(level, c.getX() - 90, c.getY(), c.getZ() - 8,
                c.getX() + 90, c.getY(), c.getZ() - 6, Blocks.RAIL.defaultBlockState());
        box(level, c.getX() - 90, c.getY(), c.getZ() + 8,
                c.getX() + 90, c.getY(), c.getZ() + 10, Blocks.RAIL.defaultBlockState());
        buildDockWarehouse(level, c.getX() - 34, c.getY(), c.getZ() - 78, 68, 42);

        BlockState[] containerColors = {
                Blocks.BLUE_CONCRETE.defaultBlockState(), Blocks.GREEN_CONCRETE.defaultBlockState(),
                Blocks.RED_CONCRETE.defaultBlockState(), Blocks.GRAY_CONCRETE.defaultBlockState(),
                Blocks.ORANGE_CONCRETE.defaultBlockState()
        };
        // Organized cargo lanes with varied lengths, heights and occasional stacked containers.
        for (int lane = 0; lane < 3; lane++) {
            for (int index = 0; index < 4; index++) {
                int x = c.getX() - 78 + index * 39 + RANDOM.nextInt(5) - 2;
                int z = c.getZ() - 28 + lane * 46 + RANDOM.nextInt(5) - 2;
                int length = 12 + RANDOM.nextInt(5);
                int depth = 5 + RANDOM.nextInt(3);
                BlockState color = containerColors[RANDOM.nextInt(containerColors.length)];
                buildCargoContainer(level, x, c.getY() + 1, z, length, depth, 5, color, RANDOM.nextBoolean());
                if (RANDOM.nextInt(4) == 0) {
                    buildCargoContainer(level, x + 2, c.getY() + 7, z + 1, length - 3, depth - 1, 4,
                            containerColors[RANDOM.nextInt(containerColors.length)], false);
                }
            }
        }

        // Crane gantries with braces and suspended beams.
        for (int x : new int[]{c.getX() - 72, c.getX() + 62}) {
            box(level, x, c.getY(), c.getZ() - 38, x + 3, c.getY() + 30, c.getZ() - 35, Blocks.IRON_BLOCK.defaultBlockState());
            box(level, x + 28, c.getY(), c.getZ() - 38, x + 31, c.getY() + 30, c.getZ() - 35, Blocks.IRON_BLOCK.defaultBlockState());
            box(level, x, c.getY() + 30, c.getZ() - 38, x + 31, c.getY() + 33, c.getZ() - 35, Blocks.IRON_BLOCK.defaultBlockState());
            for (int brace = 0; brace < 6; brace++) {
                set(level, x + brace * 5, c.getY() + 25 - brace * 3, c.getZ() - 36, Blocks.CHAIN.defaultBlockState());
            }
        }

        placeChest(level, c.getX() - 72, c.getY() + 1, c.getZ() + 48, ArenaLoot.Table.DOCKYARD);
        placeChest(level, c.getX() + 70, c.getY() + 1, c.getZ() + 45, ArenaLoot.Table.DOCKYARD);
        placeChest(level, c.getX() - 55, c.getY() + 1, c.getZ() - 55, ArenaLoot.Table.DOCKYARD);
        placeChest(level, c.getX() + 52, c.getY() + 1, c.getZ() - 52, ArenaLoot.Table.DOCKYARD);
        ArenaNpcSpawner.registerSpawn(c.getX() - 28, c.getY() + 1, c.getZ() + 8);
        ArenaNpcSpawner.registerSpawn(c.getX() + 30, c.getY() + 1, c.getZ() - 12);
        ArenaNpcSpawner.registerSpawn(c.getX() + 10, c.getY() + 1, c.getZ() + 40);
    }

    private static void buildDockWarehouse(ServerLevel level, int x, int y, int z, int w, int d) {
        box(level, x, y, z, x + w, y + 14, z + d, Blocks.IRON_BLOCK.defaultBlockState());
        box(level, x + 1, y + 1, z + 1, x + w - 1, y + 13, z + d - 1, Blocks.AIR.defaultBlockState());
        box(level, x + 1, y + 1, z + 1, x + w - 1, y + 1, z + d - 1, Blocks.POLISHED_ANDESITE.defaultBlockState());
        for (int px = x + 5; px < x + w - 4; px += 10) {
            box(level, px, y + 1, z + 2, px + 1, y + 12, z + 3, Blocks.IRON_BLOCK.defaultBlockState());
            set(level, px, y + 13, z + 2, Blocks.REDSTONE_LAMP.defaultBlockState());
        }
        // Large loading doors are intentionally open and accessible.
        box(level, x + w / 2 - 5, y + 1, z + d, x + w / 2 + 5, y + 7, z + d, Blocks.AIR.defaultBlockState());
        box(level, x + w / 2 - 7, y + 8, z + d, x + w / 2 + 7, y + 9, z + d, Blocks.YELLOW_CONCRETE.defaultBlockState());
        for (int ventX = x + 8; ventX < x + w - 6; ventX += 16) {
            box(level, ventX, y + 15, z + 8, ventX + 4, y + 17, z + 13, Blocks.IRON_BLOCK.defaultBlockState());
        }
        placeChest(level, x + 4, y + 2, z + 4, ArenaLoot.Table.DOCKYARD);
        ArenaNpcSpawner.registerSpawn(x + w / 2 - 4, y + 2, z + d / 2);
    }

    private static void buildCargoContainer(ServerLevel level, int x, int y, int z,
                                            int length, int depth, int height, BlockState color, boolean openDoor) {
        box(level, x, y, z, x + length, y + height, z + depth, color);
        box(level, x + 1, y + 1, z + 1, x + length - 1, y + height - 1, z + depth - 1, Blocks.AIR.defaultBlockState());
        box(level, x + 1, y + 1, z + 1, x + length - 1, y + 1, z + depth - 1, Blocks.IRON_BLOCK.defaultBlockState());
        for (int rib = x + 2; rib < x + length; rib += 3) {
            box(level, rib, y + 1, z, rib, y + height - 1, z, Blocks.IRON_BLOCK.defaultBlockState());
            box(level, rib, y + 1, z + depth, rib, y + height - 1, z + depth, Blocks.IRON_BLOCK.defaultBlockState());
        }
        for (int cornerX : new int[]{x, x + length}) {
            for (int cornerZ : new int[]{z, z + depth}) {
                box(level, cornerX, y, cornerZ, cornerX, y + height, cornerZ, Blocks.IRON_BLOCK.defaultBlockState());
            }
        }
        if (openDoor) {
            box(level, x + length / 2 - 1, y + 1, z + depth,
                    x + length / 2 + 1, y + 3, z + depth, Blocks.AIR.defaultBlockState());
        }
    }

    private static void generateBunker(ServerLevel level, BlockPos c) {
        int y = 22;
        box(level, c.getX() - 42, y, c.getZ() - 42, c.getX() + 42, y + 15, c.getZ() + 42, Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        box(level, c.getX() - 40, y + 1, c.getZ() - 40, c.getX() + 40, y + 14, c.getZ() + 40, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 5, y + 1, c.getZ() - 40, c.getX() + 5, y + 13, c.getZ() + 40, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 38, y + 1, c.getZ() - 5, c.getX() + 38, y + 13, c.getZ() + 5, Blocks.AIR.defaultBlockState());
        for (int i = -30; i <= 30; i += 10) {
            box(level, c.getX() + i - 4, y + 1, c.getZ() - 35, c.getX() + i + 4, y + 11, c.getZ() - 20, Blocks.AIR.defaultBlockState());
            box(level, c.getX() + i - 4, y + 1, c.getZ() + 20, c.getX() + i + 4, y + 11, c.getZ() + 35, Blocks.AIR.defaultBlockState());
        }
        for (int x = c.getX() - 35; x <= c.getX() + 35; x += 10) set(level, x, y + 12, c.getZ(), Blocks.SEA_LANTERN.defaultBlockState());
        placeChest(level, c.getX() - 30, y + 1, c.getZ() - 28, ArenaLoot.Table.BUNKER);
        placeChest(level, c.getX() + 30, y + 1, c.getZ() + 28, ArenaLoot.Table.BUNKER);
    }

    private static void generateLobby(ServerLevel level, BlockPos c) {
        final int y = c.getY();
        final int fieldRadius = 52;
        final int wallRadius = 55;

        // Clear the old manor body/roof and chimney from the previous prototype.
        box(level, c.getX() - 20, y + 1, c.getZ() - 14,
                c.getX() + 20, y + 14, c.getZ() + 14, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 4, y + 15, c.getZ() - 4,
                c.getX() + 4, y + 20, c.getZ() + 4, Blocks.AIR.defaultBlockState());

        // Flat circular field enclosed by a continuous, high white wall.
        for (int dx = -wallRadius; dx <= wallRadius; dx++) {
            for (int dz = -wallRadius; dz <= wallRadius; dz++) {
                int distanceSquared = dx * dx + dz * dz;
                if (distanceSquared > wallRadius * wallRadius) continue;
                int x = c.getX() + dx;
                int z = c.getZ() + dz;
                set(level, x, y, z, Blocks.GRASS_BLOCK.defaultBlockState());
                set(level, x, y + 1, z, Blocks.AIR.defaultBlockState());

                boolean houseArea = Math.abs(dx) <= 9 && Math.abs(dz) <= 8;
                boolean pathRing = distanceSquared >= 12 * 12 && distanceSquared <= 15 * 15;
                boolean crossRoad = Math.abs(dx) <= 2 || Math.abs(dz) <= 2;
                boolean southEntranceRoad = Math.abs(dx) <= 2 && dz >= 6;
                boolean path = pathRing || crossRoad || southEntranceRoad;
                boolean wheatField = distanceSquared >= 17 * 17
                        && distanceSquared <= fieldRadius * fieldRadius
                        && !houseArea && !path;

                if (wheatField) {
                    set(level, x, y, z, Blocks.FARMLAND.defaultBlockState());
                    set(level, x, y + 1, z,
                            Blocks.WHEAT.defaultBlockState().setValue(CropBlock.AGE, 7));
                } else if (path) {
                    set(level, x, y, z, Blocks.DIRT_PATH.defaultBlockState());
                }
            }
        }

        // Tall, completely closed white perimeter. There is deliberately no gate or doorway.
        for (int angle = 0; angle < 360; angle++) {
            double a = Math.toRadians(angle);
            int wallX = c.getX() + (int) Math.round(Math.cos(a) * wallRadius);
            int wallZ = c.getZ() + (int) Math.round(Math.sin(a) * wallRadius);
            for (int thicknessX = -1; thicknessX <= 0; thicknessX++) {
                for (int thicknessZ = -1; thicknessZ <= 0; thicknessZ++) {
                    for (int wallY = y + 1; wallY <= y + 12; wallY++) {
                        set(level, wallX + thicknessX, wallY, wallZ + thicknessZ,
                                Blocks.WHITE_CONCRETE.defaultBlockState());
                    }
                    set(level, wallX + thicknessX, y + 13, wallZ + thicknessZ,
                            Blocks.QUARTZ_BLOCK.defaultBlockState());
                }
            }
        }

        // Small country house: open entrance, warm interior, simple pitched roof.
        int left = c.getX() - 7;
        int right = c.getX() + 7;
        int back = c.getZ() - 6;
        int front = c.getZ() + 6;
        box(level, left, y + 1, back, right, y + 5, front, Blocks.WHITE_TERRACOTTA.defaultBlockState());
        box(level, left + 1, y + 1, back + 1, right - 1, y + 4, front - 1, Blocks.AIR.defaultBlockState());
        box(level, left + 1, y + 1, back + 1, right - 1, y + 1, front - 1, Blocks.OAK_PLANKS.defaultBlockState());

        // Front entrance and two windows on each side.
        box(level, c.getX() - 1, y + 1, front, c.getX() + 1, y + 2, front, Blocks.AIR.defaultBlockState());
        for (int windowZ : new int[]{back + 2, c.getZ(), front - 2}) {
            set(level, left, y + 3, windowZ, Blocks.GLASS_PANE.defaultBlockState());
            set(level, right, y + 3, windowZ, Blocks.GLASS_PANE.defaultBlockState());
        }
        set(level, c.getX() - 4, y + 3, back, Blocks.GLASS_PANE.defaultBlockState());
        set(level, c.getX() + 4, y + 3, back, Blocks.GLASS_PANE.defaultBlockState());
        set(level, c.getX() - 4, y + 3, front, Blocks.GLASS_PANE.defaultBlockState());
        set(level, c.getX() + 4, y + 3, front, Blocks.GLASS_PANE.defaultBlockState());

        // Stepped spruce roof gives the little house a visible pitched silhouette.
        for (int layer = 0; layer <= 3; layer++) {
            int halfWidth = 7 - layer;
            int roofY = y + 6 + layer;
            box(level, c.getX() - halfWidth, roofY, c.getZ() - 6,
                    c.getX() + halfWidth, roofY, c.getZ() + 6,
                    Blocks.SPRUCE_PLANKS.defaultBlockState());
        }
        box(level, c.getX() - 1, y + 9, c.getZ() - 6,
                c.getX() + 1, y + 9, c.getZ() + 6, Blocks.SPRUCE_PLANKS.defaultBlockState());

        // Cozy interior furnishings.
        box(level, c.getX() - 2, y + 2, c.getZ() - 2,
                c.getX() + 2, y + 2, c.getZ() + 2, Blocks.RED_CARPET.defaultBlockState());
        set(level, c.getX() - 4, y + 2, c.getZ() - 4, Blocks.BOOKSHELF.defaultBlockState());
        set(level, c.getX() - 3, y + 2, c.getZ() - 4, Blocks.BOOKSHELF.defaultBlockState());
        set(level, c.getX() + 4, y + 2, c.getZ() - 4, Blocks.BARREL.defaultBlockState());
        set(level, c.getX() + 4, y + 2, c.getZ() - 3, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(level, c.getX() + 4, y + 2, c.getZ() + 3, Blocks.FURNACE.defaultBlockState());
        set(level, c.getX() - 4, y + 2, c.getZ() + 3, Blocks.CHEST.defaultBlockState());
        set(level, c.getX(), y + 2, c.getZ() - 3, Blocks.OAK_FENCE.defaultBlockState());
        set(level, c.getX(), y + 3, c.getZ() - 3, Blocks.OAK_PRESSURE_PLATE.defaultBlockState());
        set(level, c.getX() - 2, y + 2, c.getZ() + 3, Blocks.OAK_STAIRS.defaultBlockState());
        set(level, c.getX() + 2, y + 2, c.getZ() + 3, Blocks.OAK_STAIRS.defaultBlockState());
        set(level, c.getX() - 3, y + 4, c.getZ(), Blocks.LANTERN.defaultBlockState());
        set(level, c.getX() + 3, y + 4, c.getZ(), Blocks.LANTERN.defaultBlockState());
        set(level, c.getX(), y + 4, c.getZ(), Blocks.LANTERN.defaultBlockState());

        // Brick chimney and a lit campfire on top create a visible smoke plume.
        int chimneyX = c.getX() + 5;
        int chimneyZ = c.getZ() - 4;
        box(level, chimneyX - 1, y + 6, chimneyZ - 1, chimneyX + 1, y + 9, chimneyZ + 1,
                Blocks.BRICKS.defaultBlockState());
        box(level, chimneyX, y + 6, chimneyZ, chimneyX, y + 9, chimneyZ,
                Blocks.AIR.defaultBlockState());
        set(level, chimneyX, y + 10, chimneyZ, Blocks.CAMPFIRE.defaultBlockState());

        // Small paths connect the front door to the surrounding country lanes.
        for (int dz = 7; dz <= 53; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
                set(level, c.getX() + dx, y, c.getZ() + dz, Blocks.DIRT_PATH.defaultBlockState());
            }
        }
        for (int dx = -53; dx <= 53; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int px = c.getX() + dx;
                int pz = c.getZ() + dz;
                if ((dx * dx + dz * dz) <= 16 * 16) continue;
                set(level, px, y, pz, Blocks.DIRT_PATH.defaultBlockState());
            }
        }
        // Reassert the spawn path after the crop pass.
        for (int dz = 7; dz <= 53; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
                set(level, c.getX() + dx, y, c.getZ() + dz, Blocks.DIRT_PATH.defaultBlockState());
            }
        }
    }

    private static void generatePassages(ServerLevel level) {
        int aX = ASSAULT.getX() + 100, aZ = ASSAULT.getZ();
        int hX = HITMANIA.getX() - 100, hZ = HITMANIA.getZ();
        int dX = DOCKYARD.getX(), dZ = DOCKYARD.getZ() - 100;
        // Outer triangular passages connect every pair of arenas.
        buildPassage(level, aX, aZ, hX, hZ);
        buildPassage(level, HITMANIA.getX(), HITMANIA.getZ() + 100, DOCKYARD.getX() + 70, DOCKYARD.getZ() - 70);
        buildPassage(level, DOCKYARD.getX() - 70, DOCKYARD.getZ() - 70, ASSAULT.getX(), ASSAULT.getZ() + 100);
        // Three additional gated branches lead from the central bunker to each arena.
        buildPassage(level, BUNKER.getX(), BUNKER.getZ(), aX, aZ);
        buildPassage(level, BUNKER.getX(), BUNKER.getZ(), hX, hZ);
        buildPassage(level, BUNKER.getX(), BUNKER.getZ(), dX, dZ);
        createShaft(level, aX, aZ, 71, 80);
        createShaft(level, hX, hZ, 71, 80);
        createShaft(level, dX, dZ, 71, 80);
        createShaft(level, HITMANIA.getX(), HITMANIA.getZ() + 100, 71, 80);
        createShaft(level, DOCKYARD.getX() + 70, DOCKYARD.getZ() - 70, 71, 80);
        createShaft(level, DOCKYARD.getX() - 70, DOCKYARD.getZ() - 70, 71, 80);
        createShaft(level, ASSAULT.getX(), ASSAULT.getZ() + 100, 71, 80);
        createShaft(level, BUNKER.getX(), BUNKER.getZ(), 38, 80);
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos gate = new BlockPos(BUNKER.getX() + dx, 37, BUNKER.getZ() + dz);
            GATE_BLOCKS.add(gate);
            write(level, gate, Blocks.IRON_BARS.defaultBlockState());
        }
    }

    private static void createShaft(ServerLevel level, int x, int z, int minY, int maxY) {
        for (int y = minY; y <= maxY; y++) {
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                BlockPos pos = new BlockPos(x + dx, y, z + dz);
                if (y == maxY || y == minY) write(level, pos, (dx == 0 && dz == 0) ? Blocks.AIR.defaultBlockState() : (edge ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState()));
                else write(level, pos, edge ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState());
            }
            if (y > minY && y < maxY) set(level, x, y, z, Blocks.SCAFFOLDING.defaultBlockState());
        }
    }

    private static void buildPassage(ServerLevel level, int ax, int az, int bx, int bz) {
        int steps = Math.max(Math.abs(bx - ax), Math.abs(bz - az));
        int gateStep = steps / 2;
        for (int i = 0; i <= steps; i++) {
            double t = steps == 0 ? 0 : (double) i / steps;
            int x = (int) Math.round(ax + (bx - ax) * t);
            int z = (int) Math.round(az + (bz - az) * t);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                for (int y = 71; y <= 75; y++) {
                    BlockPos p = new BlockPos(x + dx, y, z + dz);
                    if (i == gateStep) {
                        GATE_BLOCKS.add(p);
                        write(level, p, Blocks.IRON_BARS.defaultBlockState());
                    } else {
                        write(level, p, edge ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState());
                    }
                }
                write(level, new BlockPos(x + dx, 70, z + dz), Blocks.STONE_BRICKS.defaultBlockState());
                write(level, new BlockPos(x + dx, 76, z + dz), Blocks.STONE_BRICKS.defaultBlockState());
            }
        }
    }

    private static void circularGround(ServerLevel level, BlockPos c, int radius, BlockState state) {
        int y = ArenaConfig.ARENA_Y.get();
        for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
            if (x * x + z * z <= radius * radius) box(level, c.getX() + x, y - 2, c.getZ() + z, c.getX() + x, y, c.getZ() + z, state);
        }
    }

    private static void circularWall(ServerLevel level, BlockPos c, int radius, BlockState state) {
        int y = ArenaConfig.ARENA_Y.get();
        int innerRadius = radius - 2;
        int outerRadius = radius + 1;
        int innerSquared = innerRadius * innerRadius;
        int outerSquared = outerRadius * outerRadius;
        // Filled annulus: no one-block angular gaps, with a four-block-thick wall and a sealed top course.
        for (int dx = -outerRadius; dx <= outerRadius; dx++) {
            for (int dz = -outerRadius; dz <= outerRadius; dz++) {
                int distanceSquared = dx * dx + dz * dz;
                if (distanceSquared < innerSquared || distanceSquared > outerSquared) continue;
                for (int wallY = y + 1; wallY <= y + 13; wallY++) {
                    set(level, c.getX() + dx, wallY, c.getZ() + dz, state);
                }
                set(level, c.getX() + dx, y + 14, c.getZ() + dz, Blocks.POLISHED_ANDESITE.defaultBlockState());
            }
        }
    }

    private static void placeChest(ServerLevel level, int x, int y, int z, ArenaLoot.Table table) {
        BlockPos pos = new BlockPos(x, y, z);
        write(level, pos, Blocks.CHEST.defaultBlockState());
        CHESTS.add(pos);
        ArenaLoot.setTable(pos, table);
    }

    private static void box(ServerLevel level, int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        int minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        int minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
        int minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
        for (int x = minX; x <= maxX; x++) for (int y = minY; y <= maxY; y++) for (int z = minZ; z <= maxZ; z++) {
            write(level, new BlockPos(x, y, z), state);
        }
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        write(level, new BlockPos(x, y, z), state);
    }

    private static void write(ServerLevel level, BlockPos pos, BlockState state) {
        GENERATED_BLOCKS.add(pos.immutable());
        level.setBlock(pos, state, 3);
    }
}
