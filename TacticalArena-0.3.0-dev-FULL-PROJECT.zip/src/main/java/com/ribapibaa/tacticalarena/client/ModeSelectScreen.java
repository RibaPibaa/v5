package com.ribapibaa.tacticalarena.client;

import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ModeSelectScreen extends Screen {
    private int age;

    public ModeSelectScreen() {
        super(Component.literal("TACTICAL ARENA"));
    }

    private int centerY() { return height / 2; }
    private int panelX() { return width / 2 - 176; }
    private int panelY() { return centerY() - 122; }
    private int buttonX() { return width / 2 - 132; }
    private int buttonY(int index) { return centerY() - 38 + index * 36; }

    private void select(String mode) {
        ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.SelectModeC2S(mode));
        minecraft.setScreen(new ReadyScreen());
    }

    @Override
    public void tick() {
        super.tick();
        age++;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        float fade = ArenaUi.fade(age, partialTick);
        ArenaUi.drawBackdrop(graphics, width, height, fade);
        ArenaUi.drawPanel(graphics, panelX(), panelY(), 352, 244, fade);

        graphics.drawCenteredString(font, "TACTICAL ARENA", width / 2, centerY() - 96,
                ArenaUi.withAlpha(0xFFFFFFFF, fade));
        graphics.drawCenteredString(font, "SELECT OPERATION", width / 2, centerY() - 78,
                ArenaUi.withAlpha(0xFF9FB0C0, fade));

        String[] labels = {"ASSAULT", "HITMANIA", "BATTLE ROYALE", "CLOSE"};
        for (int i = 0; i < labels.length; i++) {
            ArenaUi.drawButton(graphics, font, buttonX(), buttonY(i), 264, 28,
                    labels[i], mouseX, mouseY, fade);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        for (int i = 0; i < 4; i++) {
            if (!ArenaUi.contains(buttonX(), buttonY(i), 264, 28, mouseX, mouseY)) continue;
            switch (i) {
                case 0 -> select("ASSAULT");
                case 1 -> select("HITMANIA");
                case 2 -> select("BATTLE_ROYALE");
                default -> onClose();
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
