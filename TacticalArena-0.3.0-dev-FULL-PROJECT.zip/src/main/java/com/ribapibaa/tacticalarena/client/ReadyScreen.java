package com.ribapibaa.tacticalarena.client;

import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ReadyScreen extends Screen {
    private int age;

    public ReadyScreen() {
        super(Component.literal("MATCH LOBBY"));
    }

    private int centerY() { return height / 2; }
    private int panelX() { return width / 2 - 202; }
    private int panelY() { return centerY() - 142; }
    private int buttonX() { return width / 2 - 148; }
    private int buttonY(int index) { return centerY() + 8 + index * 34; }

    @Override
    public void tick() {
        super.tick();
        age++;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        float fade = ArenaUi.fade(age, partialTick);
        ArenaUi.drawBackdrop(graphics, width, height, fade);
        ArenaUi.drawPanel(graphics, panelX(), panelY(), 404, 292, fade);

        graphics.drawCenteredString(font, "MATCH BRIEFING", width / 2, centerY() - 116,
                ArenaUi.withAlpha(0xFFFFFFFF, fade));
        graphics.drawCenteredString(font, "OPERATION: " + ArenaClientState.mode, width / 2, centerY() - 96,
                ArenaUi.withAlpha(0xFFD4DEE8, fade));

        String description = switch (ArenaClientState.mode) {
            case "ASSAULT" -> "10 MINUTES  |  INFINITE RESPAWNS  |  1 POINT PER KILL";
            case "HITMANIA" -> "10 MINUTES  |  CITY OPERATION  |  1 POINT PER KILL";
            case "BATTLE_ROYALE" -> "THREE LIVES  |  SHRINKING ZONE  |  LAST SURVIVOR";
            default -> "PREPARE FOR DEPLOYMENT";
        };
        graphics.drawCenteredString(font, description, width / 2, centerY() - 73,
                ArenaUi.withAlpha(0xFF9EADBB, fade));
        graphics.drawCenteredString(font, "STATUS: " + ArenaClientState.phase, width / 2, centerY() - 47,
                ArenaUi.withAlpha(0xFFB9C6D2, fade));
        graphics.drawCenteredString(font, "READY  " + ArenaClientState.ready + "/2", width / 2, centerY() - 29,
                ArenaUi.withAlpha(0xFF9FE0B7, fade));
        graphics.drawCenteredString(font,
                ArenaClientState.playerOne + "  " + ArenaClientState.scoreOne + "     |     "
                        + ArenaClientState.playerTwo + "  " + ArenaClientState.scoreTwo,
                width / 2, centerY() - 12, ArenaUi.withAlpha(0xFFE2E8EE, fade));

        String[] labels = {"READY / CANCEL READY", "FORCE START  •  1 PLAYER", "STOP MATCH", "BACK"};
        for (int i = 0; i < labels.length; i++) {
            ArenaUi.drawButton(graphics, font, buttonX(), buttonY(i), 296, 27,
                    labels[i], mouseX, mouseY, fade);
        }
        if (!ArenaClientState.phase.equals("LOBBY") && !ArenaClientState.phase.equals("FINISHED")) {
            graphics.drawCenteredString(font, "STARTS IN / TIME: " + ArenaClientState.seconds + "s",
                    width / 2, panelY() + 277, ArenaUi.withAlpha(0xFFFFD27A, fade));
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        for (int i = 0; i < 4; i++) {
            if (!ArenaUi.contains(buttonX(), buttonY(i), 296, 27, mouseX, mouseY)) continue;
            switch (i) {
                case 0 -> ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.ReadyC2S());
                case 1 -> ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.ForceStartC2S());
                case 2 -> ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.StopMatchC2S());
                default -> minecraft.setScreen(new ModeSelectScreen());
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            minecraft.setScreen(new ModeSelectScreen());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
