package com.ribapibaa.tacticalarena.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class DeathCamScreen extends Screen {
    public DeathCamScreen() { super(Component.literal("ELIMINATED")); }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        ArenaUi.drawBackdrop(graphics, width, height, 1.0F);
        graphics.fill(0, 0, width, height, 0x55000000);
        int panelWidth = 330;
        int panelHeight = 112;
        int x = width / 2 - panelWidth / 2;
        int y = height - panelHeight - 24;
        ArenaUi.drawPanel(graphics, x, y, panelWidth, panelHeight, 1.0F);
        graphics.drawCenteredString(font, "YOU ARE DOWN", width / 2, y + 13, 0xFFFFFFFF);
        graphics.drawCenteredString(font, "ELIMINATED BY: " + ArenaClientState.killer,
                width / 2, y + 33, 0xFFE5B7B7);
        graphics.drawCenteredString(font, "DAMAGE DEALT: " + String.format("%.1f", ArenaClientState.damageDealt),
                width / 2, y + 55, 0xFFE4E8EC);
        graphics.drawCenteredString(font, "DAMAGE RECEIVED: " + String.format("%.1f", ArenaClientState.damageTaken),
                width / 2, y + 72, 0xFFE4E8EC);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) { return true; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
