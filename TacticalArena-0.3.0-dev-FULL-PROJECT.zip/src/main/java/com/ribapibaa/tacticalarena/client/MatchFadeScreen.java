package com.ribapibaa.tacticalarena.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MatchFadeScreen extends Screen {
    private enum FadeState { TO_BLACK, HOLD_BLACK, FROM_BLACK }

    private final String mode;
    private FadeState state = FadeState.TO_BLACK;
    private int age;
    private static final int FADE_TO_BLACK_TICKS = 12;
    private static final int FADE_FROM_BLACK_TICKS = 18;
    private static final int HOLD_BLACK_TICKS = 10;

    public MatchFadeScreen(String mode) {
        super(Component.literal("Operation briefing"));
        this.mode = mode;
    }

    /** Called only after the server confirms that players have been deployed and the round is live. */
    public void reveal() {
        if (state == FadeState.FROM_BLACK) return;
        state = FadeState.FROM_BLACK;
        age = 0;
    }

    @Override
    public void tick() {
        age++;
        if (state == FadeState.TO_BLACK && age >= FADE_TO_BLACK_TICKS) {
            state = FadeState.HOLD_BLACK;
            age = 0;
        } else if (state == FadeState.HOLD_BLACK && age >= HOLD_BLACK_TICKS) {
            state = FadeState.FROM_BLACK;
            age = 0;
        } else if (state == FadeState.FROM_BLACK && age >= FADE_FROM_BLACK_TICKS
                && minecraft != null && minecraft.screen == this) {
            minecraft.setScreen(null);
        }
    }

    private float getFadeAlpha(float partialTick) {
        return switch (state) {
            case TO_BLACK -> Math.min(1.0F, (age + partialTick) / FADE_TO_BLACK_TICKS);
            case HOLD_BLACK -> 1.0F;
            case FROM_BLACK -> Math.max(0.0F, 1.0F - (age + partialTick) / FADE_FROM_BLACK_TICKS);
        };
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int alpha = Math.min(255, Math.max(0, (int) (getFadeAlpha(partialTick) * 255.0F)));
        graphics.fill(0, 0, width, height, (alpha << 24));
        String title = switch (mode) {
            case "ASSAULT" -> "ASSAULT — RURAL DISTRICT";
            case "HITMANIA" -> "HITMANIA — NIGHT OPERATION";
            case "BATTLE_ROYALE" -> "BATTLE ROYALE — LAST SURVIVOR";
            default -> mode;
        };
        String subtitle = switch (mode) {
            case "ASSAULT" -> "Eliminate the opponent. Every kill adds one point.";
            case "HITMANIA" -> "A city operation. Every kill adds one point.";
            case "BATTLE_ROYALE" -> "Search, survive and reach the central bunker.";
            default -> "Prepare for deployment.";
        };
        graphics.drawCenteredString(font, title, width / 2, height / 2 - 18, 0xFFFFFFFF);
        graphics.drawCenteredString(font, subtitle, width / 2, height / 2 + 2, 0xFFD5DDE5);
        graphics.drawCenteredString(font, state == FadeState.HOLD_BLACK ? "DEPLOYING OPERATORS" : "TAKE YOUR POSITION",
                width / 2, height / 2 + 22, 0xFFB5C1CC);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
}
