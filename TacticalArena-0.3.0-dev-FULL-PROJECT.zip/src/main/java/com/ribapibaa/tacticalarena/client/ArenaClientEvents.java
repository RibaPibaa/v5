package com.ribapibaa.tacticalarena.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "tacticalarena", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ArenaClientEvents {
    private ArenaClientEvents() {}

    @SubscribeEvent
    public static void onScreenOpening(ScreenEvent.Opening event) {
        if (event.getScreen() instanceof DeathScreen && ArenaClientState.deathCam) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (ArenaClientState.deathCam && ArenaClientState.cameraTargetId >= 0) {
            var target = mc.level.getEntity(ArenaClientState.cameraTargetId);
            if (target != null && mc.getCameraEntity() != target) mc.setCameraEntity(target);
        } else if (!ArenaClientState.deathCam && mc.getCameraEntity() != mc.player && mc.player.isAlive()) {
            mc.setCameraEntity(mc.player);
        }
    }

    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post event) {
        if ((!ArenaClientState.phase.equals("WARMUP") && !ArenaClientState.phase.equals("ACTIVE")) || ArenaClientState.deathCam) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        var g = event.getGuiGraphics();
        int center = mc.getWindow().getGuiScaledWidth() / 2;
        g.fill(center - 120, 8, center + 120, 48, 0x990B1017);
        g.drawCenteredString(mc.font, ArenaClientState.mode + "  |  " + ArenaClientState.phase, center, 14, 0xFFE8EDF2);
        String timer = ArenaClientState.mode.equals("BATTLE_ROYALE") ? "ZONE SHRINKING" : "TIME " + formatTime(ArenaClientState.seconds);
        g.drawCenteredString(mc.font, timer + "   READY " + ArenaClientState.ready + "/2", center, 27, 0xFFB8C5D1);
        g.drawCenteredString(mc.font, ArenaClientState.playerOne + " " + ArenaClientState.scoreOne + "  —  " + ArenaClientState.playerTwo + " " + ArenaClientState.scoreTwo, center, 38, 0xFFE8EDF2);
        String vitals = "HP " + Math.round(mc.player.getHealth()) + "/" + Math.round(mc.player.getMaxHealth())
                + "   ARMOR " + mc.player.getArmorValue();
        g.drawString(mc.font, vitals, 10, mc.getWindow().getGuiScaledHeight() - 28, 0xFFE8EDF2, true);
        String weapon = mc.player.getMainHandItem().isEmpty() ? "UNARMED" : mc.player.getMainHandItem().getHoverName().getString();
        g.drawString(mc.font, weapon, mc.getWindow().getGuiScaledWidth() - mc.font.width(weapon) - 10,
                mc.getWindow().getGuiScaledHeight() - 28, 0xFFE8EDF2, true);
    }

    private static String formatTime(int seconds) {
        return String.format("%02d:%02d", Math.max(0, seconds) / 60, Math.max(0, seconds) % 60);
    }
}
