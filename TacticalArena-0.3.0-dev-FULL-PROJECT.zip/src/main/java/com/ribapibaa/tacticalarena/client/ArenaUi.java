package com.ribapibaa.tacticalarena.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Shared dark, End-Poem-inspired visual style for Tactical Arena screens. */
public final class ArenaUi {
    private ArenaUi() {}

    public static float fade(int age, float partialTick) {
        return Math.min(1.0F, Math.max(0.0F, (age + partialTick) / 12.0F));
    }

    public static void drawBackdrop(GuiGraphics graphics, int width, int height, float fade) {
        graphics.fill(0, 0, width, height, 0xFF020306);
        int steps = Math.max(1, height / 3);
        for (int i = 0; i <= steps; i++) {
            float t = (float) i / steps;
            int red = 3 + Math.round(t * 5.0F);
            int green = 5 + Math.round(t * 7.0F);
            int blue = 9 + Math.round(t * 11.0F);
            int color = 0xFF000000 | (red << 16) | (green << 8) | blue;
            int y = i * height / steps;
            graphics.fill(0, y, width, Math.min(height, y + 3), color);
        }

        // Quiet, sparse points give the background the stillness of Minecraft's End Poem.
        for (int i = 0; i < 64; i++) {
            int x = Math.floorMod(i * 97 + 31, Math.max(1, width));
            int y = Math.floorMod(i * 53 + 17, Math.max(1, height));
            int alpha = Math.round((18 + (i % 4) * 8) * fade);
            int color = (alpha << 24) | 0x008FA7C0;
            graphics.fill(x, y, x + 1, y + 1, color);
        }

        graphics.fill(0, 0, width, 1, withAlpha(0xFF65717E, fade * 0.55F));
        graphics.fill(0, height - 1, width, height, withAlpha(0xFF65717E, fade * 0.35F));
    }

    public static void drawPanel(GuiGraphics graphics, int x, int y, int width, int height, float fade) {
        graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, withAlpha(0xFF667483, fade));
        graphics.fill(x, y, x + width, y + height, withAlpha(0xF0070A0F, fade));
        graphics.fill(x + 2, y + 2, x + width - 2, y + 3, withAlpha(0xFF293440, fade));
        graphics.fill(x + 2, y + height - 3, x + width - 2, y + height - 2, withAlpha(0xFF293440, fade));
    }

    public static void drawButton(GuiGraphics graphics, Font font, int x, int y, int width, int height,
                                  String label, int mouseX, int mouseY, float fade) {
        boolean hovered = contains(x, y, width, height, mouseX, mouseY);
        int border = hovered ? 0xFFB5C5D4 : 0xFF465362;
        int fill = hovered ? 0xFF263544 : 0xFF111820;
        graphics.fill(x, y, x + width, y + height, withAlpha(border, fade));
        graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, withAlpha(fill, fade));
        graphics.fill(x + 2, y + 2, x + 4, y + height - 2,
                withAlpha(hovered ? 0xFFB7D4E8 : 0xFF526D83, fade));
        int textColor = hovered ? 0xFFFFFFFF : 0xFFE0E7EE;
        graphics.drawCenteredString(font, label, x + width / 2, y + (height - 8) / 2,
                withAlpha(textColor, fade));
    }

    public static boolean contains(int x, int y, int width, int height, double mouseX, double mouseY) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    public static int withAlpha(int color, float multiplier) {
        int sourceAlpha = (color >>> 24) & 0xFF;
        int alpha = Math.max(0, Math.min(255, Math.round(sourceAlpha * multiplier)));
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
