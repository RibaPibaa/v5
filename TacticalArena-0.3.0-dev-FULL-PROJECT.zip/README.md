# Tactical Arena 0.3.0-dev — Forge 1.20.1

A two-player tactical arena mod project for Minecraft Java Edition.

## Target environment

- Minecraft 1.20.1
- Forge 47.4.28
- Java 17
- Gradle 8.8

## Build on GitHub

1. Keep `.github/workflows/build.yml` in the repository.
2. Upload `TacticalArena-0.3.0-dev-FULL-PROJECT.zip` to the repository root (or upload the extracted project files directly).
3. Open **Actions → Build Tactical Arena → Run workflow**.
4. The workflow detects an extracted project or unpacks the ZIP automatically.
5. When the workflow succeeds, download `TacticalArena-Forge-1.20.1` from the run's Artifacts section.
6. Put the resulting JAR into `mods` on both clients and the dedicated server.

The workflow builds the mod; third-party mods are not bundled into this JAR.

## First launch and map generation

On first login, the mod creates only the small lobby and moves the player there. The larger combat maps are generated when the first match is prepared after each server start, rather than blocking initial login. The generated regions are far from the origin:

- ASSAULT village: approximately `(-520, 80, -300)`
- HITMANIA city: approximately `(520, 80, -300)`
- DOCKYARD industrial port: approximately `(0, 80, 620)`
- Central underground bunker: approximately `(0, 35, 0)`
- Enclosed farmstead lobby: approximately `(0, 80, 1900)`

Back up the world before the first launch. Map generation places a large number of blocks and can cause a one-time server pause. The `/tacticalarena generate` command can regenerate the layout; use it only when you intend to rebuild those regions.

## Commands

- `/tacticalarena generate` — generate the maps and lobby.
- `/tacticalarena restore` — restore the complete generated map baseline, clear dropped items/corpses and reroll map chests.
- `/tacticalarena diagnose` — write discovered modded armor/item counts and wearable registry IDs to `latest.log`.
- `/tacticalarena status` — show selected mode and match phase.
- `/tacticalarena stop` — stop the current match and return participants to the lobby.

Commands require permission level 2.

## Implemented in this source revision

- Custom one-stack paper selector, automatically supplied to players.
- Dark End-Poem-inspired mode and briefing screens with animated fade-in and custom drawn buttons.
- READY / STOP MATCH controls plus a force-start option for one player.
- Login now generates only the lobby; combat maps are deferred until match preparation.
- New enclosed white-wall lobby with a small enterable house, furnished interior, chimney smoke, country paths and mature wheat fields.
- Server-authoritative match phases: lobby, 4-second ready countdown, 10-second warmup, active match, finish.
- 10-minute default timer for ASSAULT and HITMANIA; Battle Royale has no hard time limit and its border shrinks over a configurable 10-minute period.
- ASSAULT, HITMANIA and BATTLE ROYALE mode state.
- Adventure-mode warmup and player-vs-player damage suppression during warmup.
- Dynamic registry scan of loaded content mods for armor, clothing, melee items, medical supplies, grenades and general modded loot. TaCZ gun/ammo entries are validated against TaCZ common registries and receive their required NBT.
- Player armor is equipped into actual HEAD/CHEST/LEGS/FEET slots during warmup, immediately after teleporting into the arena. The primary TaCZ gun is placed in the player's main hand, with validated ammunition and modded melee/medical/throwable items in inventory. Curios adds separate `face` and `vest` slots for compatible masks and tactical gear.
- Rebuilt combat maps: sealed four-block-thick perimeter walls with no angular gaps; varied village homes with porches, roofs, chimneys, windows and furnished interiors; differentiated city buildings, storefronts, apartments, office/industrial roofs and a central plaza; cargo lanes, warehouse and crane details in the dockyard.
- Old combat-map structures are cleared from reserved arena regions before the new layout is generated.
- Gated triangular passages and gated branches to the central bunker; gates open for Battle Royale.
- MCA civilian NPC lookup (`mca:male_villager` / `mca:female_villager`) with explicit MCA `AgeState.ADULT` forcing and vanilla adult fallback; spawn points are checked for safe floor/headroom.
- Lobby players remain in Adventure mode; PvP, block breaking and block placement are disabled there.
- Reduced civilian count in Battle Royale; civilians are recreated after a match.
- 3-second death camera screen with grey overlay, killer tracking when the killer is in client tracking range, and damage dealt/received summary.
- Automatic respawn after the death camera for non-eliminated players.
- Random safe respawn search 20–23 blocks from the death location.
- 3-second respawn protection; the first attempted melee hit or successful player damage consumes it and is cancelled.
- Kill score and Regeneration V for 5 seconds in ASSAULT and HITMANIA.
- Battle Royale maximum health progression: 20 → 14 → 8 HP, third death eliminates the player.
- Battle Royale world border shrink toward the central bunker.
- `keepInventory` switched by mode and restored after the match.
- Full block-state baseline snapshot of every generated block; after each match, walls, buildings, interiors, doors, props and chests are restored, dropped items/corpses are removed and modded loot is rerolled.
- Time, daylight cycle, weather and world border are controlled during a match and restored afterward.
- GitHub Actions build workflow.

## Configuration

After first launch, edit `config/tacticalarena-server.toml`. The default kits and loot lists are empty on purpose: Tactical Arena now discovers compatible content from the registries of mods that are actually loaded. Optional custom registry IDs can still be added to these lists:

- `kits.assault`
- `kits.hitmania`
- `kits.battleRoyaleStarter`
- `kits.hitmaniaBusinessSuitItems`
- `kits.assaultMedicalItems`
- `kits.hitmaniaMedicalItems`
- `kits.assaultLootItems`
- `kits.hitmaniaLootItems`
- `kits.dockyardLootItems`
- `kits.bunkerLootItems`

Unknown registry IDs are skipped safely. The runtime discovery summary is written to `latest.log`; use `/tacticalarena diagnose` after joining a world to inspect which mod armor items were found.

## Required external mods for the intended pack

Install matching Forge 1.20.1 files separately on both players' clients and on the server where the mod requires it:

- TaCZ / Timeless & Classics Guns: Zero 1.2.0 and the selected TaCZ packs
- Jag TacZ Armor
- LesRaisins Tactical Equipments and DeltaForce Melee Pack
- Januszowo – ubrania and Faz Roleplay Plus
- Curios API 5.9.1, Player Animator 1.0.2-rc1, ParCool 3.4.3 and GeckoLib 4 4.8.4
- Minecraft Comes Alive and MCA: Crime
- Visceral, plus the other selected sound, graphics and optimization mods

Tactical Arena does not redistribute or bundle third-party mods.

## Current integration boundaries / test checklist

This is a substantial gameplay/map rebuild, but it is not a claim that every external-mod item and animation has already been verified in a running client. The following require the actual installed mod JARs and an in-game multiplayer test before being called complete:

- The runtime validates TaCZ gun/ammo IDs through TaCZ's common registries, but the selected guns, ammunition counts and third-person draw/reload animations still need an in-game test with this exact `tacz` pack.
- Exact Faz Roleplay Plus / Januszowo business-suit item IDs and whether their cosmetic rendering is synchronized to the other player; compatible Curios clothing is auto-equipped, while non-Curios clothing may need an explicit registry mapping.
- Exact Visceral corpse/loot behavior with `keepInventory` in ASSAULT/HITMANIA versus corpse loot in BR.
- MCA: Crime threat/plea reactions on the exact MCA entity types and TaCZ gun versions.
- Full cinematic camera transitions, custom victory flyby and polished HUD art.
- The MCA Reborn first-character creation prompt is owned by that external mod; Tactical Arena now moves the player to the lobby without waiting for full map generation, but does not suppress MCA's own prompt.
- Testing all respawn edge cases, simultaneous deaths, disconnects and map reset under a dedicated server.

Do not treat the source as a final production release until GitHub Actions has compiled it and the two-player test checklist has passed. The current build environment could not run Gradle because it has no network access to download Gradle/Forge dependencies. The source therefore still needs a successful GitHub Actions build before it can be treated as a compiled release.
