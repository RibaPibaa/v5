package com.ribapibaa.tacticalarena.client;

import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import net.minecraft.client.Minecraft;

public final class ArenaClientState {
    public static String mode = "ASSAULT";
    public static String phase = "LOBBY";
    public static int seconds;
    public static int ready;
    public static String playerOne = "Player 1";
    public static String playerTwo = "Player 2";
    public static int scoreOne;
    public static int scoreTwo;
    public static boolean deathCam;
    public static int cameraTargetId = -1;
    public static float damageDealt;
    public static float damageTaken;
    public static String killer = "";

    private ArenaClientState() {}

    public static void apply(ArenaNetwork.StateS2C packet) {
        mode = packet.mode;
        phase = packet.phase;
        seconds = packet.seconds;
        ready = packet.ready;
        playerOne = packet.playerOne;
        playerTwo = packet.playerTwo;
        scoreOne = packet.scoreOne;
        scoreTwo = packet.scoreTwo;
        if (Minecraft.getInstance().screen instanceof ModeSelectScreen) Minecraft.getInstance().setScreen(new ReadyScreen());
        if (phase.equals("WARMUP")
                && (Minecraft.getInstance().screen instanceof ReadyScreen || Minecraft.getInstance().screen instanceof ModeSelectScreen)) {
            Minecraft.getInstance().setScreen(new MatchFadeScreen(mode));
        } else if (phase.equals("ACTIVE") && Minecraft.getInstance().screen instanceof MatchFadeScreen) {
            Minecraft.getInstance().setScreen(null);
        }
    }

    public static void setDeathCam(ArenaNetwork.DeathCamS2C packet) {
        deathCam = packet.active;
        cameraTargetId = packet.targetId;
        damageDealt = packet.dealt;
        damageTaken = packet.taken;
        killer = packet.killer;
        Minecraft mc = Minecraft.getInstance();
        if (packet.active) mc.setScreen(new DeathCamScreen());
        else if (mc.screen instanceof DeathCamScreen) mc.setScreen(null);
    }
}
