package com.ribapibaa.tacticalarena.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Optional MCA Reborn integration by registry lookup; vanilla villagers are a safe fallback. */
public final class ArenaNpcSpawner {
    private static final List<BlockPos> SPAWN_POINTS = new ArrayList<>();
    private static final Random RANDOM = new Random();
    private static int nameCounter;

    private ArenaNpcSpawner() {}

    public static void resetSpawnPoints() {
        SPAWN_POINTS.clear();
        nameCounter = 0;
    }

    public static void registerSpawn(int x, int y, int z) {
        SPAWN_POINTS.add(new BlockPos(x, y, z));
    }

    public static void populate(ServerLevel level, boolean battleRoyale) {
        for (net.minecraft.world.phys.AABB bounds : ArenaMapGenerator.allBounds()) {
            for (Entity entity : level.getEntitiesOfClass(Entity.class, bounds, e -> e.getPersistentData().getBoolean("tacticalarena_civilian"))) {
                entity.discard();
            }
        }
        List<BlockPos> points = new ArrayList<>(SPAWN_POINTS);
        if (battleRoyale && points.size() > 0) {
            List<BlockPos> reduced = new ArrayList<>();
            for (int i = 0; i < points.size(); i++) if (i % 3 == 0) reduced.add(points.get(i));
            points = reduced;
        }
        for (BlockPos pos : points) spawnOne(level, pos);
    }

    private static void spawnOne(ServerLevel level, BlockPos pos) {
        EntityType<?> type = findMcaType();
        Entity entity = type.create(level);
        if (entity == null) entity = EntityType.VILLAGER.create(level);
        if (entity == null) return;
        entity.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, RANDOM.nextFloat() * 360.0F, 0.0F);
        entity.setCustomName(Component.literal(randomName()));
        entity.setCustomNameVisible(false);
        entity.getPersistentData().putBoolean("tacticalarena_civilian", true);
        entity.addTag("tacticalarena_civilian");
        if (entity instanceof Mob mob) {
            mob.setNoAi(false);
            mob.setPersistenceRequired();
        }
        level.addFreshEntity(entity);
    }

    private static EntityType<?> findMcaType() {
        String[] ids = RANDOM.nextBoolean()
                ? new String[]{"mca:female_villager", "mca:male_villager", "mca:villager"}
                : new String[]{"mca:male_villager", "mca:female_villager", "mca:villager"};
        for (String id : ids) {
            ResourceLocation key = ResourceLocation.tryParse(id);
            if (key != null) {
                EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.getOptional(key).orElse(null);
                if (type != null) return type;
            }
        }
        for (EntityType<?> candidate : BuiltInRegistries.ENTITY_TYPE) {
            ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(candidate);
            if (key != null && key.getNamespace().equals("mca") && key.getPath().contains("villager")
                    && !key.getPath().contains("zombie")) return candidate;
        }
        return EntityType.VILLAGER;
    }

    private static String randomName() {
        String[] names = {"Alex", "Mason", "Noah", "Ethan", "Liam", "Mia", "Emma", "Olivia", "Sofia", "Nora", "Daniel", "Lucas", "Eva", "Mila"};
        return names[RANDOM.nextInt(names.length)] + " " + (++nameCounter);
    }
}
