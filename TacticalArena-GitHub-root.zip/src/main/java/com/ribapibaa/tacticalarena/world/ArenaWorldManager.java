package com.ribapibaa.tacticalarena.world;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class ArenaWorldManager {
    private static final Map<BlockPos, BlockState> BROKEN_BLOCKS = new HashMap<>();
    private static final Set<BlockPos> CHEST_POSITIONS = new HashSet<>();

    private ArenaWorldManager() {}

    public static void captureBreak(BlockPos pos, BlockState state) {
        BROKEN_BLOCKS.putIfAbsent(pos.immutable(), state);
    }

    public static void captureSnapshot(ServerLevel level, Set<BlockPos> chests) {
        CHEST_POSITIONS.clear();
        for (BlockPos pos : chests) CHEST_POSITIONS.add(pos.immutable());
        BROKEN_BLOCKS.clear();
    }

    public static void restore(ServerLevel level) {
        for (Map.Entry<BlockPos, BlockState> entry : BROKEN_BLOCKS.entrySet()) {
            level.setBlock(entry.getKey(), entry.getValue(), 3);
        }
        BROKEN_BLOCKS.clear();

        // Each round receives a fresh roll from the map-specific loot table.
        ArenaLoot.populateAll(level, CHEST_POSITIONS);

        // Clear dropped loot and equipment from the arena floor, including BR death drops.
        for (AABB bounds : ArenaMapGenerator.allBounds()) {
            for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, bounds)) item.discard();
            for (net.minecraft.world.entity.Entity entity : level.getEntitiesOfClass(net.minecraft.world.entity.Entity.class, bounds,
                    e -> net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getNamespace().equals("visceral")
                            && (net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().contains("corpse")
                            || net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().contains("body")
                            || net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().contains("ragdoll")))) {
                entity.discard();
            }
        }
    }
}
