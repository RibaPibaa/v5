package com.ribapibaa.tacticalarena.world;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;

import java.util.*;

public final class ArenaLoot {
    public enum Table { ASSAULT, HITMANIA, DOCKYARD, BUNKER }
    private static final Map<BlockPos, Table> TABLES = new HashMap<>();
    private static final Random RANDOM = new Random();

    private ArenaLoot() {}

    public static void setTable(BlockPos pos, Table table) { TABLES.put(pos.immutable(), table); }

    public static void populateAll(ServerLevel level, Set<BlockPos> chests) {
        for (BlockPos pos : chests) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof ChestBlockEntity chest) populate(level, pos, chest, TABLES.getOrDefault(pos, Table.ASSAULT));
        }
    }

    private static void populate(ServerLevel level, BlockPos pos, ChestBlockEntity chest, Table table) {
        List<? extends String> pool = switch (table) {
            case ASSAULT -> ArenaConfig.ASSAULT_LOOT.get();
            case HITMANIA -> ArenaConfig.HITMANIA_LOOT.get();
            case DOCKYARD -> ArenaConfig.DOCKYARD_LOOT.get();
            case BUNKER -> ArenaConfig.BUNKER_LOOT.get();
        };
        chest.clearContent();
        int count = 4 + RANDOM.nextInt(4);
        for (int i = 0; i < count; i++) {
            if (pool.isEmpty()) continue;
            String id = pool.get(RANDOM.nextInt(pool.size()));
            ResourceLocation key = ResourceLocation.tryParse(id);
            Item item = key == null ? Items.AIR : BuiltInRegistries.ITEM.getOptional(key).orElse(Items.AIR);
            if (item == Items.AIR) continue;
            int slot = RANDOM.nextInt(chest.getContainerSize());
            int amount = item == Items.ARROW || item == Items.COOKED_BEEF || item == Items.BREAD ? 4 + RANDOM.nextInt(9) : 1;
            chest.setItem(slot, new ItemStack(item, amount));
        }
        chest.setChanged();
    }
}
