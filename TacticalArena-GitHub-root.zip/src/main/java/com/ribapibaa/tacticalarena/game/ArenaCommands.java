package com.ribapibaa.tacticalarena.game;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import com.ribapibaa.tacticalarena.world.ArenaMapGenerator;
import com.ribapibaa.tacticalarena.world.ArenaNpcSpawner;
import com.ribapibaa.tacticalarena.world.ArenaWorldManager;

public class ArenaCommands {
    @SubscribeEvent
    public void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("tacticalarena").requires(source -> source.hasPermission(2))
                .then(Commands.literal("generate").executes(ctx -> {
                    ServerLevel level = ctx.getSource().getServer().overworld();
                    ArenaMapGenerator.generateAll(level);
                    ctx.getSource().sendSuccess(() -> Component.literal("Tactical Arena maps generated. Keep a backup of this world."), true);
                    return 1;
                }))
                .then(Commands.literal("restore").executes(ctx -> {
                    ServerLevel level = ctx.getSource().getServer().overworld();
                    ArenaWorldManager.restore(level);
                    ArenaMapGenerator.setBattleRoyaleAccess(level, false);
                    ArenaNpcSpawner.populate(level, false);
                    ctx.getSource().sendSuccess(() -> Component.literal("Arena destructible blocks and ground items restored."), true);
                    return 1;
                }))
                .then(Commands.literal("stop").executes(ctx -> {
                    ArenaMatchManager.stopMatch(ctx.getSource().getServer());
                    ctx.getSource().sendSuccess(() -> Component.literal("Tactical Arena match stopped."), true);
                    return 1;
                }))
                .then(Commands.literal("status").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal("Mode: " + ArenaMatchManager.getMode() + " | Phase: " + ArenaMatchManager.getPhase()), false);
                    return 1;
                })));
    }
}
