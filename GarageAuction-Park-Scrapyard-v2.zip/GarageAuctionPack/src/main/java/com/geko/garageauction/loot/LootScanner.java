package com.geko.garageauction.loot;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;

import java.util.*;

/** Runtime registry scanner. Non-armour items are sampled uniformly; armour bundles are a rare bonus. */
public final class LootScanner {
    private LootScanner() {}
    public record ScanSummary(int total, Map<String,Integer> byMod) {}
    private static final List<Item> COMMON = new ArrayList<>();
    private static final List<List<Item>> ARMOR_SETS = new ArrayList<>();
    private static boolean scanned;

    public static synchronized ScanSummary scan() {
        COMMON.clear(); ARMOR_SETS.clear();
        Map<String,Integer> counts = new TreeMap<>();
        Map<String, EnumMap<EquipmentSlot, Item>> sets = new HashMap<>();
        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id == null || item == Items.AIR || excluded(id)) continue;
            counts.merge(id.getNamespace(), 1, Integer::sum);
            if (item instanceof ArmorItem armor) {
                String key = id.getNamespace() + ":" + armorSetName(id.getPath());
                sets.computeIfAbsent(key, k -> new EnumMap<>(EquipmentSlot.class)).put(armor.getEquipmentSlot(), item);
            } else COMMON.add(item);
        }
        for (EnumMap<EquipmentSlot, Item> set : sets.values()) {
            if (set.containsKey(EquipmentSlot.HEAD) && set.containsKey(EquipmentSlot.CHEST)
                    && set.containsKey(EquipmentSlot.LEGS) && set.containsKey(EquipmentSlot.FEET))
                ARMOR_SETS.add(new ArrayList<>(set.values()));
        }
        scanned = true;
        return new ScanSummary(COMMON.size() + sets.values().stream().mapToInt(Map::size).sum(), Collections.unmodifiableMap(counts));
    }

    private static boolean excluded(ResourceLocation id) {
        String p = id.getPath().toLowerCase(Locale.ROOT);
        return Set.of("air", "barrier", "command_block", "chain_command_block", "repeating_command_block",
                "structure_block", "jigsaw", "light", "structure_void", "knowledge_book").contains(p)
                || p.contains("spawn_egg") || p.contains("debug") || p.contains("test_item") || p.contains("_spawn");
    }

    private static String armorSetName(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        for (String suffix : List.of("_helmet", "_head", "_mask", "_chestplate", "_chest", "_leggings", "_legs", "_boots", "_feet"))
            if (p.endsWith(suffix)) return p.substring(0, p.length() - suffix.length());
        return p;
    }

    /** Creates a well-stocked container. At most one full armour set is permitted per garage. */
    public static synchronized List<ItemStack> generateContainerLoot(Random random, int targetStacks, boolean allowArmorSet) {
        if (!scanned) scan();
        List<ItemStack> out = new ArrayList<>();
        if (COMMON.isEmpty()) return out;
        // Full suits are deliberately uncommon; if one appears, all four pieces stay together.
        if (allowArmorSet && !ARMOR_SETS.isEmpty() && random.nextFloat() < 0.075f) {
            List<Item> set = ARMOR_SETS.get(random.nextInt(ARMOR_SETS.size()));
            for (Item piece : set) out.add(new ItemStack(piece));
        }
        int count = out.isEmpty() ? Math.max(8, targetStacks) : Math.max(7, targetStacks - out.size());
        for (int i = 0; i < count; i++) {
            Item item = COMMON.get(random.nextInt(COMMON.size())); // equal probability for each registered non-armour item
            ItemStack stack = new ItemStack(item);
            if (stack.getMaxStackSize() > 1 && random.nextFloat() < 0.35f)
                stack.setCount(1 + random.nextInt(Math.min(stack.getMaxStackSize(), 8)));
            out.add(stack);
        }
        return out;
    }

    public static synchronized List<ItemStack> generateGarageLoot(Random random, int targetStacks) {
        return generateContainerLoot(random, targetStacks, true);
    }

    public static ItemStack randomStack(Random random) {
        List<ItemStack> stacks = generateContainerLoot(random, 1, false);
        return stacks.isEmpty() ? ItemStack.EMPTY : stacks.get(0);
    }
}
