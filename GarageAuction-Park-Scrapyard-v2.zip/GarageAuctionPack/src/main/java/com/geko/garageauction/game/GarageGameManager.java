package com.geko.garageauction.game;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.*;

/** Server-side auction and arena state. State is stored in overworld SavedData. */
public final class GarageGameManager {
    private GarageGameManager() {}
    private static final String DATA_NAME = "garageauction_state";
    private static final Map<UUID, Integer> balances = new HashMap<>();
    private static final Map<UUID, List<List<ItemStack>>> storage = new HashMap<>();
    private static final Map<Integer, Auction> auctions = new HashMap<>();
    private static final Map<Integer, Battle> battles = new HashMap<>();
    private static final Map<UUID, Integer> colors = new HashMap<>();
    private static final ChatFormatting[] PALETTE = {ChatFormatting.RED, ChatFormatting.BLUE, ChatFormatting.GREEN, ChatFormatting.YELLOW, ChatFormatting.LIGHT_PURPLE, ChatFormatting.AQUA, ChatFormatting.GOLD, ChatFormatting.DARK_GREEN, ChatFormatting.WHITE, ChatFormatting.DARK_PURPLE};

    private static class Auction {
        final int garage; final Set<UUID> joined = new LinkedHashSet<>();
        UUID bidder; int bid; long endTick; boolean open;
        Auction(int garage) { this.garage=garage; }
    }
    private static class Battle {
        final int arena; final Set<UUID> joined = new LinkedHashSet<>();
        final Map<UUID, Integer> deathOrder = new HashMap<>();
        long startTick; boolean running; int deaths;
        Battle(int arena) { this.arena=arena; }
    }

    public static int balance(ServerPlayer p) { return balances.computeIfAbsent(p.getUUID(), id -> 150 + p.getRandom().nextInt(4351)); }
    public static void joinAuction(ServerPlayer p, int garage) {
        Auction a = auctions.computeIfAbsent(garage, Auction::new);
        if (a.open) { p.sendSystemMessage(Component.literal("Этот гараж уже открыт.")); return; }
        if (!a.joined.add(p.getUUID())) { p.sendSystemMessage(Component.literal("Ты уже зарегистрирован.")); return; }
        p.sendSystemMessage(Component.literal("Регистрация: " + a.joined.size() + "/" + onlineCount(p.getServer())).withStyle(ChatFormatting.GREEN));
        if (a.joined.size() >= onlineCount(p.getServer())) startAuction(p.getServer(), a);
    }
    private static int onlineCount(MinecraftServer s) { return Math.max(1, s.getPlayerList().getPlayers().size()); }
    private static void startAuction(MinecraftServer s, Auction a) {
        a.endTick = s.overworld().getGameTime() + 200;
        broadcast(s, "Аукцион гаража #" + a.garage + " начался! Ставка: /rate100 (можно любую сумму).", ChatFormatting.GOLD);
    }
    public static boolean bid(ServerPlayer p, int amount) {
        if (amount <= 0) return false;
        Auction active = auctions.values().stream().filter(a -> !a.open && a.endTick > 0 && a.joined.contains(p.getUUID())).max(Comparator.comparingLong(a -> a.endTick)).orElse(null);
        if (active == null) { p.sendSystemMessage(Component.literal("Ты не участвуешь в активном аукционе.")); return false; }
        int money = balance(p);
        if (amount <= active.bid || amount > money) { p.sendSystemMessage(Component.literal("Ставка должна быть выше текущей и не превышать баланс.")); return false; }
        active.bid=amount; active.bidder=p.getUUID(); active.endTick=p.serverLevel().getGameTime()+200;
        broadcast(p.getServer(), p.getName().getString()+" ставит $"+amount+" на гараж #"+active.garage+". 10 секунд!", ChatFormatting.YELLOW);
        return true;
    }
    public static void joinArena(ServerPlayer p, int arena) {
        if (balance(p) <= 0) { p.sendSystemMessage(Component.literal("Нет денег — зарегистрируйся на арену.")); }
        Battle b=battles.computeIfAbsent(arena, Battle::new);
        if (b.running) { p.sendSystemMessage(Component.literal("Арена уже занята.")); return; }
        b.joined.add(p.getUUID());
        p.sendSystemMessage(Component.literal("Регистрация на арену: "+b.joined.size()+"/"+onlineCount(p.getServer())));
        if (b.joined.size() >= onlineCount(p.getServer())) prepareBattle(p.getServer(),b);
    }
    private static void prepareBattle(MinecraftServer s, Battle b) {
        b.running=true; b.startTick=s.overworld().getGameTime()+100;
        int i=0; for(UUID id:b.joined) { ServerPlayer p=s.getPlayerList().getPlayer(id); if(p!=null) { p.getInventory().clearContent(); p.setInvulnerable(true); p.teleportTo(s.overworld(), (b.arena*32)+(i++==0?-8:8), s.overworld().getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, b.arena*32, 0)+1, 0, 0, 0); p.sendSystemMessage(Component.literal("Бой начнётся через 5 секунд!")); } }
    }
    @SubscribeEvent public static void onTick(TickEvent.ServerTickEvent e) {
        if(e.phase!=TickEvent.Phase.END) return;
        MinecraftServer s=ServerLifecycleHooks.getCurrentServer(); if(s==null) return;
        long now=s.overworld().getGameTime();
        for(Auction a:auctions.values()) if(!a.open && a.endTick>0 && now>=a.endTick) {
            a.open=true;
            ServerPlayer winner=a.bidder==null?null:s.getPlayerList().getPlayer(a.bidder);
            if(winner!=null) { balances.put(winner.getUUID(), Math.max(0,balance(winner)-a.bid)); broadcast(s,winner.getName().getString()+" выиграл гараж #"+a.garage+" за $"+a.bid+"!",ChatFormatting.GREEN); }
            else broadcast(s,"Аукцион гаража #"+a.garage+" завершён без ставок.",ChatFormatting.GRAY);
        }
        for(Battle b:battles.values()) if(b.running && now>=b.startTick) {
            for(UUID id:b.joined) { ServerPlayer p=s.getPlayerList().getPlayer(id); if(p!=null) { p.setInvulnerable(false); p.sendSystemMessage(Component.literal("БОЙ НАЧАЛСЯ!" ).withStyle(ChatFormatting.RED,ChatFormatting.BOLD)); } }
            b.startTick=Long.MAX_VALUE;
        }
    }
    @SubscribeEvent public static void onDeath(LivingDeathEvent e) {
        if(!(e.getEntity() instanceof ServerPlayer p)) return;
        for(Battle b:battles.values()) if(b.running && b.joined.contains(p.getUUID()) && !b.deathOrder.containsKey(p.getUUID())) {
            b.deathOrder.put(p.getUUID(),++b.deaths); 
            List<ItemStack> copy=new ArrayList<>(); for(ItemStack st:p.getInventory().items) if(!st.isEmpty()) copy.add(st.copy());
            storage.computeIfAbsent(p.getUUID(),x->new ArrayList<>()).add(copy);
            finishIfDone(p.getServer(),b); break;
        }
    }
    private static void finishIfDone(MinecraftServer s, Battle b) {
        int alive=0; ServerPlayer last=null;
        for(UUID id:b.joined) { ServerPlayer p=s.getPlayerList().getPlayer(id); if(p!=null && p.isAlive() && !b.deathOrder.containsKey(id)) { alive++; last=p; } }
        if(alive>1) return;
        if(last!=null) { List<ItemStack> copy=new ArrayList<>(); for(ItemStack st:last.getInventory().items) if(!st.isEmpty()) copy.add(st.copy()); storage.computeIfAbsent(last.getUUID(),x->new ArrayList<>()).add(copy); last.getInventory().clearContent(); }
        for(UUID id:b.joined) { ServerPlayer p=s.getPlayerList().getPlayer(id); if(p!=null) { p.setInvulnerable(false); balances.put(id,150+p.getRandom().nextInt(4351)); p.sendSystemMessage(Component.literal("Бой окончен. Новый баланс выдан.")); } }
        b.running=false; b.joined.clear(); b.deathOrder.clear(); b.deaths=0;
    }
    public static void openStorage(ServerPlayer p) {
        List<List<ItemStack>> pages=storage.getOrDefault(p.getUUID(),List.of());
        if(pages.isEmpty()) { p.sendSystemMessage(Component.literal("Хранилище пока пусто.")); return; }
        List<ItemStack> page=pages.get(pages.size()-1); int moved=0;
        for(ItemStack st:page) if(!p.getInventory().add(st.copy())) p.drop(st.copy(),false); else moved++;
        p.sendSystemMessage(Component.literal("Получено предметов из последнего сохранения: "+moved+". Предыдущие сохранения остаются в хранилище."));
    }
    public static void leaveStorage(ServerPlayer p) { p.sendSystemMessage(Component.literal("Ты вышел из хранилища.")); }
    public static void resetAuctions() { auctions.clear(); }
    public static void resetAll() { auctions.clear(); battles.clear(); }
    private static void broadcast(MinecraftServer s,String msg,ChatFormatting color) { s.getPlayerList().broadcastSystemMessage(Component.literal(msg).withStyle(color),false); }
}
