# Garage Auction — Park & Scrapyard edition

Forge 1.20.1 / Java 17.

Commands:
- `/squarespawn` — circular landscaped park, dense hedge/tree boundary, central grey monument and colourful wooden cottages.
- `/scrapyardspawn` — abandoned scrapyard from the previous layout.
- `/clearstructure` — clears generated blocks around the player (use carefully).
- `/cleargarages` — resets the area and auction state.
- `/garageloot` — reports discovered registered items.

Loot scanner reads the live Forge/Minecraft item registry. Non-armour registered items are sampled uniformly. Chests/barrels are filled more densely with shuffled slots. A complete four-piece armour set is a rare bonus and is limited to one set per garage.

Note: this is a procedural structure/loot iteration, not a finished auction gameplay release. Some modded items with custom NBT/variants need dedicated adapters. Compile with `gradle build` using Gradle 8.8 and Java 17. Test in a disposable world first; structure clearing is area-based.
